import 'dotenv/config';
import * as db from './db';

/**
 * SmartPOS database migration / schema sync script.
 *
 * Run with:  npm run migrate
 *
 * What it does (idempotent — safe to run any time):
 *   1. Connects to MySQL using your MYSQL_* env vars (or defaults).
 *   2. Creates the database + all tables if they are missing.
 *   3. Applies any pending lightweight migrations for older installs
 *      (e.g. adds new columns like `khr_exchange_rate` to existing tables).
 *   4. Seeds demo data ONLY into tables that are empty (never overwrites data).
 */
async function migrate() {
  console.log('🔄 Running SmartPOS database migration...');
  try {
    const { seeded } = await db.initDatabase();
    console.log('✅ Database schema is up to date.');
    if (seeded) {
      console.log('🌱 Demo data was seeded into empty tables.');
    }
    console.log(`📦 Database: ${db.envMysqlConfig().database} @ ${db.envMysqlConfig().host}:${db.envMysqlConfig().port}`);
  } catch (err: any) {
    console.error('❌ Migration failed:', err?.message || err);
    console.error('   Check your MYSQL_HOST / MYSQL_USER / MYSQL_PASSWORD / MYSQL_DATABASE');
    console.error('   values in .env and make sure MySQL is running.');
    process.exit(1);
  }
  process.exit(0);
}

migrate();
