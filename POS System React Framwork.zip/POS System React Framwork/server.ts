import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import * as bcrypt from 'bcryptjs';
import * as speakeasy from 'speakeasy';
import * as QRCode from 'qrcode';
import { OAuth2Client } from 'google-auth-library';
import * as db from './db';
import type { Settings } from './src/types';

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ----------------------------------------------------
// HELPERS
// ----------------------------------------------------

/** Async route wrapper: forwards thrown errors to the JSON error handler. */
const ah = (fn: (req: Request, res: Response) => Promise<any>) => (req: Request, res: Response) => {
  fn(req, res).catch((err: any) => {
    console.error('[API Error]', err?.message || err);
    if (!res.headersSent) {
      res.status(500).json({ error: err?.message || 'Internal server error' });
    }
  });
};

// ----------------------------------------------------
// AUTH HELPERS (session tokens + 2FA challenge store)
// ----------------------------------------------------

/** In-memory store of pending 2FA challenges: pendingToken -> { userId, expires } (5 min TTL). */
const pending2FA = new Map<string, { userId: string; expires: number }>();

/** Valid session tokens issued at login: token -> userId. Sessions die on server restart. */
const validSessions = new Map<string, string>();

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const googleAuthClient = GOOGLE_CLIENT_ID ? new OAuth2Client(GOOGLE_CLIENT_ID) : null;

function issueToken(userId: string): string {
  const token = `smartpos-${crypto.randomBytes(24).toString('hex')}-${userId}`;
  validSessions.set(token, userId);
  return token;
}

/** Protects sensitive routes: requires a valid `Authorization: Bearer <token>` header. */
const requireAuth = (req: Request, res: Response, next: () => void) => {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  const userId = validSessions.get(token);
  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized: session expired or invalid. Please sign in again.' });
  }
  (req as any).authUserId = userId;
  next();
};

async function handle2FAChallenge(user: any) {
  const pendingToken = crypto.randomBytes(16).toString('hex');
  pending2FA.set(pendingToken, { userId: user.id, expires: Date.now() + 5 * 60 * 1000 });
  return { requires2FA: true as const, pendingToken, email: user.email, name: user.name };
}

// ----------------------------------------------------
// TELEGRAM ALARM STATE & HELPER
// ----------------------------------------------------

let telegramConfig = {
  botToken: process.env.TELEGRAM_BOT_TOKEN || '',
  chatId: process.env.TELEGRAM_CHAT_ID || '',
  enableLowStockAlerts: true,
  enableSalesAlerts: true,
  lastAlertSentAt: null as string | null,
};

async function persistTelegramConfig() {
  try {
    await db.updateTelegramConfig(telegramConfig);
  } catch {
    // non-critical
  }
}

async function sendTelegramNotification(text: string) {
  if (!telegramConfig.botToken || !telegramConfig.chatId) {
    return { success: false, reason: 'Bot Token or Chat ID is missing. Please configure Telegram settings.' };
  }
  try {
    const url = `https://api.telegram.org/bot${telegramConfig.botToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: telegramConfig.chatId,
        text,
        parse_mode: 'HTML',
      }),
    });
    const data = await response.json();
    if (data.ok) {
      telegramConfig.lastAlertSentAt = new Date().toISOString();
      persistTelegramConfig();
      return { success: true, message: 'Telegram alarm delivered successfully!' };
    } else {
      return { success: false, reason: data.description || 'Telegram API rejected request' };
    }
  } catch (err: any) {
    return { success: false, reason: err.message || 'Failed to connect to Telegram API' };
  }
}

// ----------------------------------------------------
// MYSQL CONNECTION STATE (loaded from .env + mysql_config table)
// ----------------------------------------------------

let mysqlConfig: any = {
  ...db.envMysqlConfig(),
  ssl: false,
  autoSync: true,
  status: 'Connecting...',
  lastSyncedAt: null as string | null,
};

// Gemini AI Client setup
let aiClient: GoogleGenAI | null = null;
function getAIClient() {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== 'MY_GEMINI_API_KEY') {
      aiClient = new GoogleGenAI({ apiKey: key });
    }
  }
  return aiClient;
}

// ----------------------------------------------------
// REST API ENDPOINTS
// ----------------------------------------------------

// 1. AUTH API (password + Google sign-in, with optional TOTP two-factor authentication)
app.post('/api/auth/login', ah(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const user = await db.getUserByEmail(String(email).toLowerCase().trim());
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const ok = await bcrypt.compare(String(password), user.password || '');
  if (!ok) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  if (user.twoFactorEnabled) {
    return res.json(await handle2FAChallenge(user));
  }

  return res.json({
    token: issueToken(user.id),
    user: db.sanitizeUser(user),
    message: 'Login successful',
  });
}));

app.get('/api/auth/me', ah(async (req, res) => {
  res.json({ user: db.sanitizeUser(await db.getFirstUser()) });
}));

// Google Sign-In: verify the ID token server-side, then link to an existing staff account
app.post('/api/auth/google', ah(async (req, res) => {
  const { token } = req.body || {};
  if (!GOOGLE_CLIENT_ID || !googleAuthClient) {
    return res.status(501).json({
      error: 'Google sign-in is not configured. Add GOOGLE_CLIENT_ID to your .env file and restart the server.',
    });
  }
  if (!token) {
    return res.status(400).json({ error: 'Missing Google ID token' });
  }

  let payload: any;
  try {
    const ticket = await googleAuthClient.verifyIdToken({ idToken: String(token), audience: GOOGLE_CLIENT_ID });
    payload = ticket.getPayload();
  } catch (err: any) {
    console.error('[Auth] Google token verification failed:', err?.message || err);
    return res.status(401).json({ error: 'Google authentication failed: invalid ID token.' });
  }

  const email = String(payload?.email || '').toLowerCase().trim();
  if (!email) {
    return res.status(401).json({ error: 'Google account has no verified email address.' });
  }

  const user = await db.getUserByEmail(email);
  if (!user) {
    return res.status(401).json({
      error: `This Google account (${email}) is not linked to a SmartPOS staff member. Sign in with your staff email or ask an admin to add you.`,
    });
  }

  if (user.twoFactorEnabled) {
    return res.json(await handle2FAChallenge(user));
  }

  return res.json({
    token: issueToken(user.id),
    user: db.sanitizeUser(user),
    message: 'Google sign-in successful',
  });
}));

// ---- TOTP Two-Factor Authentication ----
// Requires a valid session AND the user's own password (prevents account takeover)
app.post('/api/auth/2fa/setup', requireAuth, ah(async (req, res) => {
  const { userId, password } = req.body || {};
  if (!userId || !password) {
    return res.status(400).json({ error: 'User ID and your current password are required.' });
  }
  const user = userId ? await db.getUserById(String(userId)) : null;
  if (!user) return res.status(404).json({ error: 'User not found' });

  const pwOk = await bcrypt.compare(String(password), user.password || '');
  if (!pwOk) return res.status(401).json({ error: 'Incorrect password. Enter your current password to manage 2FA.' });
  if (user.twoFactorEnabled) {
    return res.status(400).json({ error: 'Two-factor authentication is already enabled for this account.' });
  }

  const secret = speakeasy.generateSecret({ name: `SmartPOS (${user.email})`, issuer: 'SmartPOS' });
  await db.setUserTwoFactorSecret(user.id, secret.base32);
  const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url || '');
  return res.json({ secret: secret.base32, otpauthUrl: secret.otpauth_url, qrCodeUrl });
}));

app.post('/api/auth/2fa/enable', requireAuth, ah(async (req, res) => {
  const { userId, password, token } = req.body || {};
  if (!userId || !password) {
    return res.status(400).json({ error: 'User ID and your current password are required.' });
  }
  const user = userId ? await db.getUserById(String(userId)) : null;
  if (!user) return res.status(404).json({ error: 'User not found' });

  const pwOk = await bcrypt.compare(String(password), user.password || '');
  if (!pwOk) return res.status(401).json({ error: 'Incorrect password. Enter your current password to manage 2FA.' });
  if (!user.twoFactorSecret) {
    return res.status(400).json({ error: 'No 2FA secret found. Run the setup again first.' });
  }

  const valid = speakeasy.totp.verify({
    secret: user.twoFactorSecret,
    encoding: 'base32',
    token: String(token || '').trim(),
    window: 1,
  });
  if (!valid) {
    return res.status(400).json({ error: 'Invalid verification code. Check the time on your authenticator device and try again.' });
  }

  await db.setUserTwoFactorEnabled(user.id, true);
  return res.json({ success: true, message: 'Two-factor authentication enabled successfully!' });
}));

app.post('/api/auth/2fa/disable', requireAuth, ah(async (req, res) => {
  const { userId, token } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'User ID is required.' });
  const user = userId ? await db.getUserById(String(userId)) : null;
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (!user.twoFactorEnabled) {
    return res.status(400).json({ error: 'Two-factor authentication is not enabled on this account.' });
  }

  const valid = speakeasy.totp.verify({
    secret: user.twoFactorSecret || '',
    encoding: 'base32',
    token: String(token || '').trim(),
    window: 1,
  });
  if (!valid) {
    return res.status(400).json({ error: 'Invalid verification code.' });
  }

  await db.setUserTwoFactorEnabled(user.id, false);
  await db.setUserTwoFactorSecret(user.id, '');
  return res.json({ success: true, message: 'Two-factor authentication disabled.' });
}));

app.post('/api/auth/logout', ah(async (req, res) => {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (token) validSessions.delete(token);
  res.json({ success: true });
}));

// Completes login by verifying the TOTP code for a pending 2FA challenge
app.post('/api/auth/2fa/verify-login', ah(async (req, res) => {
  const { pendingToken, token } = req.body || {};
  const pending = pending2FA.get(String(pendingToken || ''));
  if (!pending || pending.expires < Date.now()) {
    pending2FA.delete(String(pendingToken || ''));
    return res.status(401).json({ error: 'This login session has expired. Please sign in again.' });
  }

  const user = await db.getUserById(pending.userId);
  if (!user) {
    return res.status(401).json({ error: 'User not found.' });
  }

  const valid = speakeasy.totp.verify({
    secret: user.twoFactorSecret || '',
    encoding: 'base32',
    token: String(token || '').trim(),
    window: 1,
  });
  if (!valid) {
    return res.status(400).json({ error: 'Invalid verification code.' });
  }

  pending2FA.delete(String(pendingToken));
  return res.json({
    token: issueToken(user.id),
    user: db.sanitizeUser(user),
    message: 'Two-factor verification successful',
  });
}));

// 2. DASHBOARD STATS API
app.get('/api/dashboard/stats', ah(async (req, res) => {
  res.json(await db.getDashboardStats());
}));

// 3. PRODUCTS API
app.get('/api/products', ah(async (req, res) => {
  res.json(await db.getProducts());
}));

app.post('/api/products', ah(async (req, res) => {
  const newProduct: any = {
    ...req.body,
    id: `prod-${Date.now()}`,
    margin:
      req.body.sellingPrice > 0
        ? Number((((req.body.sellingPrice - req.body.purchasePrice) / req.body.sellingPrice) * 100).toFixed(1))
        : 0,
    status:
      req.body.stock <= req.body.minStock
        ? req.body.stock === 0
          ? 'Out of Stock'
          : 'Low Stock'
        : 'In Stock',
  };
  await db.insertProduct(newProduct);
  res.status(201).json(newProduct);
}));

app.put('/api/products/:id', ah(async (req, res) => {
  const { id } = req.params;
  const existing = await db.getProductById(id);
  if (!existing) return res.status(404).json({ error: 'Product not found' });

  const margin =
    req.body.sellingPrice > 0 && req.body.purchasePrice !== undefined
      ? Number((((req.body.sellingPrice - req.body.purchasePrice) / req.body.sellingPrice) * 100).toFixed(1))
      : existing.margin;
  const status =
    req.body.stock !== undefined && req.body.minStock !== undefined
      ? req.body.stock <= req.body.minStock
        ? req.body.stock === 0
          ? 'Out of Stock'
          : 'Low Stock'
        : 'In Stock'
      : existing.status;

  await db.updateProduct(id, { ...req.body, margin, status });
  res.json(await db.getProductById(id));
}));

app.delete('/api/products/:id', ah(async (req, res) => {
  await db.deleteProduct(req.params.id);
  res.json({ success: true, id: req.params.id });
}));

// 4. CATEGORIES API
app.get('/api/categories', ah(async (req, res) => {
  res.json(await db.getCategories());
}));

app.post('/api/categories', ah(async (req, res) => {
  const newCat = { ...req.body, id: `cat-${Date.now()}`, itemCount: 0 };
  await db.insertCategory(newCat);
  res.status(201).json(newCat);
}));

app.put('/api/categories/:id', ah(async (req, res) => {
  const { id } = req.params;
  const existing = (await db.getCategories()).find((c) => c.id === id);
  if (!existing) return res.status(404).json({ error: 'Category not found' });
  await db.updateCategory(id, req.body);
  res.json({ ...existing, ...req.body });
}));

app.delete('/api/categories/:id', ah(async (req, res) => {
  await db.deleteCategory(req.params.id);
  res.json({ success: true });
}));

// 5. CUSTOMERS API
app.get('/api/customers', ah(async (req, res) => {
  res.json(await db.getCustomers());
}));

app.post('/api/customers', ah(async (req, res) => {
  const newCust: any = {
    ...req.body,
    id: `cust-${Date.now()}`,
    points: 0,
    tier: 'Bronze',
    totalSpent: 0,
  };
  await db.insertCustomer(newCust);
  res.status(201).json(newCust);
}));

app.put('/api/customers/:id', ah(async (req, res) => {
  const { id } = req.params;
  const existing = (await db.getCustomers()).find((c) => c.id === id);
  if (!existing) return res.status(404).json({ error: 'Customer not found' });
  await db.updateCustomer(id, req.body);
  res.json({ ...existing, ...req.body });
}));

app.delete('/api/customers/:id', ah(async (req, res) => {
  await db.deleteCustomer(req.params.id);
  res.json({ success: true });
}));

// 6. SUPPLIERS API
app.get('/api/suppliers', ah(async (req, res) => {
  res.json(await db.getSuppliers());
}));

app.post('/api/suppliers', ah(async (req, res) => {
  const newSupp: any = { ...req.body, id: `supp-${Date.now()}` };
  await db.insertSupplier(newSupp);
  res.status(201).json(newSupp);
}));

app.put('/api/suppliers/:id', ah(async (req, res) => {
  const { id } = req.params;
  const existing = (await db.getSuppliers()).find((s) => s.id === id);
  if (!existing) return res.status(404).json({ error: 'Supplier not found' });
  await db.updateSupplier(id, req.body);
  res.json({ ...existing, ...req.body });
}));

app.delete('/api/suppliers/:id', ah(async (req, res) => {
  await db.deleteSupplier(req.params.id);
  res.json({ success: true });
}));

// 7. SALES & POS CHECKOUT API
app.get('/api/sales', ah(async (req, res) => {
  res.json(await db.getSales());
}));

app.delete('/api/sales/cleanup-weekly', ah(async (req, res) => {
  const deletedCount = await db.deleteOldSales(7);
  res.json({
    success: true,
    deletedCount,
    message:
      deletedCount > 0
        ? `Auto-deleted ${deletedCount} sales older than 7 days (1 week).`
        : 'No sales records older than 7 days found.',
  });
}));

app.get('/api/sales/backup', ah(async (req, res) => {
  const sales = await db.getSales();
  res.json({
    sales,
    timestamp: new Date().toISOString(),
    totalCount: sales.length,
  });
}));

app.post('/api/sales/restore', ah(async (req, res) => {
  const { sales } = req.body || {};
  if (!Array.isArray(sales)) {
    return res.status(400).json({ error: 'Invalid backup format. Expected sales array.' });
  }
  const addedCount = await db.restoreSales(sales);
  const totalCount = (await db.getSales()).length;
  res.json({
    success: true,
    count: totalCount,
    message: `Successfully restored ${addedCount} sales records (Total history: ${totalCount}).`,
  });
}));

app.post('/api/sales', ah(async (req, res) => {
  const now = new Date();
  const dateStr = now.toISOString().replace(/[-T:]/g, '').slice(0, 8);
  const randSeq = Math.floor(1000 + Math.random() * 9000);
  const invoiceNo = `INV-${dateStr}-${randSeq}`;

  const newSale: any = {
    ...req.body,
    id: `sale-${Date.now()}`,
    invoiceNo,
    date: new Date().toISOString().replace('T', ' ').slice(0, 16),
    status: 'Completed',
  };

  // Low stock triggers collected inside the transaction
  const lowStockTriggers: string[] = [];

  await db.withTransaction(async (conn) => {
    if (Array.isArray(newSale.items)) {
      for (const item of newSale.items) {
        if (!item.product?.id) continue;
        await db.deductSaleStock(item.product.id, item.quantity, conn);
        const prod = await db.getProductById(item.product.id, conn);
        if (prod && prod.stock <= prod.minStock) {
          lowStockTriggers.push(`• <b>${prod.name}</b>: ${prod.stock} ${prod.unit} left (Min: ${prod.minStock})`);
        }
      }
    }

    // Award Points to Customer
    if (newSale.customerId && newSale.customerId !== 'cust-1') {
      await db.applyCustomerPurchase(newSale.customerId, newSale.total, conn);
    }

    await db.insertSale(newSale, conn);
  });

  // Trigger Telegram Sales Alarm
  if (telegramConfig.enableSalesAlerts && telegramConfig.botToken && telegramConfig.chatId && Array.isArray(newSale.items)) {
    const itemsSummary = newSale.items.map((i: any) => `- ${i.product?.name || 'Item'} (x${i.quantity})`).join('\n');
    const msg = `💰 <b>NEW SALE COMPLETED!</b>\n-----------------------------------\n<b>Invoice:</b> <code>${newSale.invoiceNo}</code>\n<b>Total Amount:</b> $${Number(newSale.total || 0).toFixed(2)} (${newSale.paymentMethod})\n<b>Customer:</b> ${newSale.customerName || 'Walk-in'}\n<b>Cashier:</b> ${newSale.cashierName || 'Staff'}\n\n<b>Items Purchased:</b>\n${itemsSummary}`;
    sendTelegramNotification(msg).catch(() => {});
  }

  // Trigger Telegram Low Stock Alarm
  if (telegramConfig.enableLowStockAlerts && lowStockTriggers.length > 0 && telegramConfig.botToken && telegramConfig.chatId) {
    const alertMsg = `⚠️ <b>LOW STOCK ALARM WARNING!</b>\n-----------------------------------\nThe following items reached critical stock thresholds during checkout:\n\n${lowStockTriggers.join('\n')}\n\n<i>Please prepare a purchase order to replenish inventory!</i>`;
    sendTelegramNotification(alertMsg).catch(() => {});
  }

  res.status(201).json(newSale);
}));

app.post('/api/sales/:id/refund', ah(async (req, res) => {
  const { id } = req.params;
  const { reason, refundMethod } = req.body;
  const sale = await db.getSaleById(id);
  if (!sale) return res.status(404).json({ error: 'Sale not found' });

  let returnRecord: any = null;

  await db.withTransaction(async (conn) => {
    await db.updateSaleStatus(id, 'Refunded', conn);

    // Restore Stock
    if (Array.isArray(sale.items)) {
      for (const item of sale.items) {
        if (!item.product?.id) continue;
        await db.addProductStock(item.product.id, item.quantity, conn);
      }
    }

    // Create Sales Return record
    returnRecord = {
      id: `ret-${Date.now()}`,
      returnNo: `RET-${Date.now().toString().slice(-6)}`,
      saleId: sale.id,
      invoiceNo: sale.invoiceNo,
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      customerName: sale.customerName,
      items: sale.items.map((i: any) => ({
        productName: i.product.name,
        quantity: i.quantity,
        refundAmount: i.product.sellingPrice * i.quantity,
      })),
      totalRefund: sale.total,
      reason: reason || 'Customer Refund Request',
      refundMethod: refundMethod || 'Cash',
    };
    await db.insertReturn(returnRecord, conn);
  });

  const updatedSale = await db.getSaleById(id);
  res.json({ success: true, sale: updatedSale, returnRecord });
}));

// 8. PURCHASES API
app.get('/api/purchases', ah(async (req, res) => {
  res.json(await db.getPurchases());
}));

app.post('/api/purchases', ah(async (req, res) => {
  const poNo = `PO-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
  const newPurchase: any = {
    ...req.body,
    id: `pur-${Date.now()}`,
    poNo,
    date: new Date().toISOString().split('T')[0],
    status: 'Received',
  };

  // Add stock to products
  await db.withTransaction(async (conn) => {
    if (Array.isArray(newPurchase.items)) {
      for (const item of newPurchase.items) {
        if (!item.productId) continue;
        await db.addProductStock(item.productId, Number(item.quantity), conn);
      }
    }
    await db.insertPurchase(newPurchase, conn);
  });

  res.status(201).json(newPurchase);
}));

// 9. INVENTORY ADJUSTMENTS API
app.get('/api/inventory/adjustments', ah(async (req, res) => {
  res.json(await db.getStockAdjustments());
}));

app.post('/api/inventory/adjustments', ah(async (req, res) => {
  const { productId, quantity, type, reason, adjustedBy } = req.body;
  const prod = await db.getProductById(productId);
  if (!prod) return res.status(404).json({ error: 'Product not found' });

  const qty = Number(quantity);
  const adjRecord = {
    id: `adj-${Date.now()}`,
    date: new Date().toISOString().replace('T', ' ').slice(0, 16),
    productId,
    productName: prod.name,
    type,
    quantity: qty,
    reason,
    adjustedBy: adjustedBy || 'Admin',
  };

  await db.withTransaction(async (conn) => {
    await db.changeProductStock(productId, qty, conn);
    await db.insertStockAdjustment(adjRecord, conn);
  });

  res.status(201).json(adjRecord);
}));

app.put('/api/inventory/adjustments/:id', ah(async (req, res) => {
  const { id } = req.params;
  const oldAdj = await db.getStockAdjustmentById(id);
  if (!oldAdj) return res.status(404).json({ error: 'Adjustment record not found' });

  const { productId, quantity, type, reason, adjustedBy } = req.body;
  const targetProductId = productId || oldAdj.productId;
  const prod = await db.getProductById(targetProductId);
  if (!prod) return res.status(404).json({ error: 'Product not found' });

  const oldQty = Number(oldAdj.quantity);
  const newQty = quantity !== undefined ? Number(quantity) : oldQty;

  await db.withTransaction(async (conn) => {
    // Revert old quantity, apply new quantity to product stock
    await db.changeProductStock(targetProductId, -oldQty + newQty, conn);
    await db.updateStockAdjustment(id, {
      productId: targetProductId,
      productName: prod.name,
      type: type || oldAdj.type,
      quantity: newQty,
      reason: reason !== undefined ? reason : oldAdj.reason,
      adjustedBy: adjustedBy || oldAdj.adjustedBy,
    }, conn);
  });

  const updated = await db.getStockAdjustmentById(id);
  res.json(updated);
}));

app.delete('/api/inventory/adjustments/:id', ah(async (req, res) => {
  const { id } = req.params;
  const oldAdj = await db.getStockAdjustmentById(id);
  if (!oldAdj) return res.status(404).json({ error: 'Adjustment record not found' });

  await db.withTransaction(async (conn) => {
    // Revert stock change caused by this adjustment
    await db.changeProductStock(oldAdj.productId, -Number(oldAdj.quantity), conn);
    await db.deleteStockAdjustment(id, conn);
  });

  res.json({ success: true, message: 'Stock adjustment record deleted and product stock reverted.' });
}));

// 10. EXPENSES API
app.get('/api/expenses', ah(async (req, res) => {
  res.json(await db.getExpenses());
}));

app.post('/api/expenses', ah(async (req, res) => {
  const newExp: any = {
    ...req.body,
    id: `exp-${Date.now()}`,
    date: req.body.date || new Date().toISOString().split('T')[0],
  };
  await db.insertExpense(newExp);
  res.status(201).json(newExp);
}));

app.delete('/api/expenses/:id', ah(async (req, res) => {
  await db.deleteExpense(req.params.id);
  res.json({ success: true });
}));

// 11. RETURNS API
app.get('/api/returns', ah(async (req, res) => {
  res.json(await db.getReturns());
}));

// 12. USERS & ROLES API
app.get('/api/users', ah(async (req, res) => {
  res.json(await db.getUsers());
}));

app.post('/api/users', requireAuth, ah(async (req, res) => {
  const newUser: any = {
    ...req.body,
    id: `usr-${Date.now()}`,
    createdAt: new Date().toISOString().split('T')[0],
  };
  await db.insertUser(newUser);
  res.status(201).json(db.sanitizeUser(newUser));
}));

app.put('/api/users/:id', requireAuth, ah(async (req, res) => {
  const { id } = req.params;
  const existing = await db.getUserById(id);
  if (!existing) return res.status(404).json({ error: 'User not found' });
  // 2FA state can only change through the dedicated 2FA endpoints (which require a password/code)
  const { twoFactorEnabled, twoFactorSecret, ...safeBody } = req.body || {};
  await db.updateUser(id, safeBody);
  res.json(db.sanitizeUser({ ...existing, ...safeBody }));
}));

app.delete('/api/users/:id', requireAuth, ah(async (req, res) => {
  await db.deleteUser(req.params.id);
  res.json({ success: true });
}));

// 13. SETTINGS API & BACKUP / RESTORE
app.get('/api/settings', ah(async (req, res) => {
  res.json(await db.getSettings());
}));

app.put('/api/settings', ah(async (req, res) => {
  await db.updateSettings(req.body);
  res.json(await db.getSettings());
}));

app.get('/api/settings/backup', ah(async (req, res) => {
  res.json(await db.exportBackup());
}));

app.post('/api/settings/restore', ah(async (req, res) => {
  await db.restoreDatabase(req.body);
  res.json({ success: true, message: 'Database state successfully restored!' });
}));  // 14. LOGO UPLOAD
app.post('/api/settings/upload-logo', express.raw({ type: 'image/*', limit: '5mb' }), ah(async (req, res) => {
  if (!req.body || !Buffer.isBuffer(req.body)) {
    return res.status(400).json({ error: 'No image data received' });
  }

  // Determine file extension from content-type or default to png
  const contentType = req.headers['content-type'] || 'image/png';
  const ext = contentType.split('/')[1] || 'png';
  const filename = `logo.${ext}`;

  // Save to public/ directory (Vite serves it at root)
  const publicDir = path.join(process.cwd(), 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const filePath = path.join(publicDir, filename);
  fs.writeFileSync(filePath, req.body);

  // Also save as logo.png so our /logo.png path always works
  const pngPath = path.join(publicDir, 'logo.png');
  if (filePath !== pngPath) {
    fs.copyFileSync(filePath, pngPath);
  }

  // Update the logo_url in settings DB
  const logoUrl = `/logo.png?_t=${Date.now()}`;
  await db.updateSettings({ logoUrl });

  res.json({ success: true, logoUrl, message: 'Logo uploaded successfully!' });
}));

// 15. REMOVE LOGO
app.post('/api/settings/remove-logo', ah(async (req, res) => {
  const publicDir = path.join(process.cwd(), 'public');
  const logoPng = path.join(publicDir, 'logo.png');

  // Delete the logo file
  try {
    if (fs.existsSync(logoPng)) {
      fs.unlinkSync(logoPng);
    }
  } catch {
    // File may not exist, that's fine
  }

  // Also try to delete any logo.* variants
  try {
    if (fs.existsSync(publicDir)) {
      const files = fs.readdirSync(publicDir);
      for (const file of files) {
        if (file.startsWith('logo.')) {
          fs.unlinkSync(path.join(publicDir, file));
        }
      }
    }
  } catch {
    // Best-effort cleanup
  }

  // Reset logo_url in DB to empty string so the fallback icon kicks in
  await db.updateSettings({ logoUrl: '' });

  res.json({ success: true, message: 'Logo removed! Default icon will be shown.' });
}));

  // TELEGRAM ALARM API
app.get('/api/telegram/config', ah(async (req, res) => {
  res.json(await db.getTelegramConfig());
}));

app.post('/api/telegram/config', ah(async (req, res) => {
  telegramConfig = { ...telegramConfig, ...req.body };
  await persistTelegramConfig();
  res.json({ success: true, config: telegramConfig, message: 'Telegram alarm settings saved!' });
}));

app.post('/api/telegram/test', ah(async (req, res) => {
  const { botToken, chatId } = req.body || {};
  if (botToken) telegramConfig.botToken = botToken;
  if (chatId) telegramConfig.chatId = chatId;

  const settings = (await db.getSettings()) as Settings | null;
  const msg = `🚨 <b>SmartPOS Telegram Alarm Test Notification</b>\n-----------------------------------\n<b>Store:</b> ${settings?.companyName || 'SmartPOS'}\n<b>Timestamp:</b> ${new Date().toLocaleString()}\n<b>Status:</b> Telegram Alarm Bot connected successfully!\n<b>Alerts Enabled:</b> Sales (${telegramConfig.enableSalesAlerts ? 'YES' : 'NO'}), Low Stock (${telegramConfig.enableLowStockAlerts ? 'YES' : 'NO'})`;

  const result = await sendTelegramNotification(msg);
  res.json(result);
}));

// MYSQL DATABASE CONNECTION & SYNC API
app.get('/api/mysql/config', ah(async (req, res) => {
  const { password, ...safeConfig } = mysqlConfig;
  res.json(safeConfig);
}));

app.post('/api/mysql/config', ah(async (req, res) => {
  const body = req.body || {};
  const prev = {
    host: mysqlConfig.host,
    port: mysqlConfig.port,
    user: mysqlConfig.user,
    database: mysqlConfig.database,
  };

  // Keep the existing password when the UI sends an empty one
  if (typeof body.password === 'string' && body.password.length > 0) {
    mysqlConfig.password = body.password;
  }

  mysqlConfig = {
    ...mysqlConfig,
    host: body.host || mysqlConfig.host,
    port: body.port || mysqlConfig.port,
    user: body.user || mysqlConfig.user,
    database: body.database || mysqlConfig.database,
    ssl: body.ssl ?? mysqlConfig.ssl,
    autoSync: body.autoSync ?? mysqlConfig.autoSync,
    status: `Saved: ${body.host || mysqlConfig.host}:${body.port || mysqlConfig.port}/${body.database || mysqlConfig.database}`,
  };

  try {
    await db.saveMysqlConfig({
      host: mysqlConfig.host,
      port: mysqlConfig.port,
      user: mysqlConfig.user,
      database: mysqlConfig.database,
      ssl: mysqlConfig.ssl,
      autoSync: mysqlConfig.autoSync,
    });
  } catch {
    // table may not exist yet
  }

  // If any connection setting changed, (re)connect the app pool to the new target
  const connChanged =
    mysqlConfig.host !== prev.host ||
    Number(mysqlConfig.port) !== Number(prev.port) ||
    mysqlConfig.user !== prev.user ||
    mysqlConfig.database !== prev.database;

  if (connChanged) {
    try {
      const { seeded } = await db.initDatabase(mysqlConfig);
      mysqlConfig.lastSyncedAt = new Date().toISOString();
      mysqlConfig.status = `Connected to ${mysqlConfig.host}:${mysqlConfig.port}/${mysqlConfig.database}${seeded ? ' (demo data seeded)' : ''}`;
    } catch (err: any) {
      mysqlConfig.status = `Connection Failed: ${err?.message || err}`;
    }
  }

  res.json({ success: true, config: mysqlConfig, message: 'MySQL configuration saved!' });
}));

app.post('/api/mysql/test', ah(async (req, res) => {
  const body = req.body || {};
  const cfg = {
    host: body.host || mysqlConfig.host,
    port: body.port || mysqlConfig.port,
    user: body.user || mysqlConfig.user,
    password: typeof body.password === 'string' && body.password.length > 0 ? body.password : mysqlConfig.password,
    database: body.database || mysqlConfig.database,
  };

  try {
    const { version, pingMs } = await db.testMysqlConnection(cfg);
    mysqlConfig.status = `Connected to ${cfg.host}:${cfg.port}/${cfg.database}`;
    res.json({
      success: true,
      message: `Successfully connected to MySQL server at ${cfg.host}:${cfg.port}!`,
      details: {
        database: cfg.database,
        user: cfg.user,
        serverVersion: version,
        sslActive: false,
        pingMs,
      },
    });
  } catch (err: any) {
    mysqlConfig.status = `Connection Failed: ${err?.message || err}`;
    res.status(500).json({
      success: false,
      message: `Connection failed: ${err?.message || err}`,
      details: { database: cfg.database, user: cfg.user },
    });
  }
}));

app.post('/api/mysql/sync', ah(async (req, res) => {
  try {
    const { seeded } = await db.initDatabase(mysqlConfig);
    mysqlConfig.lastSyncedAt = new Date().toISOString();

    const [products, sales, categories] = await Promise.all([
      db.getProducts(),
      db.getSales(),
      db.getCategories(),
    ]);

    mysqlConfig.status = `Synced (${products.length} products, ${sales.length} sales)`;
    res.json({
      success: true,
      message: `Successfully synchronized ${products.length} products, ${categories.length} categories, and ${sales.length} sales to MySQL schema!${seeded ? ' Demo data was seeded on first run.' : ''}`,
      syncedTables: ['categories', 'products', 'customers', 'suppliers', 'sales', 'purchases', 'expenses'],
      timestamp: mysqlConfig.lastSyncedAt,
    });
  } catch (err: any) {
    mysqlConfig.status = `Sync Failed: ${err?.message || err}`;
    res.status(500).json({ success: false, message: `MySQL sync failed: ${err?.message || err}` });
  }
}));

async function generateMySQLDumpScript() {
  const dbName = mysqlConfig.database || 'smartpos_db';
  const [categories, products, sales] = await Promise.all([db.getCategories(), db.getProducts(), db.getSales()]);
  const settings = await db.getSettings();

  const esc = (v: any) => String(v ?? '').replace(/'/g, "''");

  let sql = `-- ========================================================\n`;
  sql += `-- SmartPOS MySQL Database Dump\n`;
  sql += `-- Exported on: ${new Date().toISOString()}\n`;
  sql += `-- Store Name: ${settings?.companyName || 'SmartPOS'}\n`;
  sql += `-- ========================================================\n\n`;
  sql += `CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n`;
  sql += `USE \`${dbName}\`;\n\n`;

  // Categories DDL & DML
  sql += `-- Table: categories\n`;
  sql += `CREATE TABLE IF NOT EXISTS \`categories\` (\n`;
  sql += `  \`id\` VARCHAR(64) PRIMARY KEY,\n`;
  sql += `  \`name\` VARCHAR(128) NOT NULL,\n`;
  sql += `  \`icon\` VARCHAR(64) DEFAULT 'Tag'\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  categories.forEach((c: any) => {
    sql += `INSERT INTO \`categories\` (\`id\`, \`name\`, \`icon\`) VALUES ('${esc(c.id)}', '${esc(c.name)}', '${esc(c.icon || 'Tag')}') ON DUPLICATE KEY UPDATE \`name\`='${esc(c.name)}';\n`;
  });
  sql += `\n`;

  // Products DDL & DML
  sql += `-- Table: products\n`;
  sql += `CREATE TABLE IF NOT EXISTS \`products\` (\n`;
  sql += `  \`id\` VARCHAR(64) PRIMARY KEY,\n`;
  sql += `  \`name\` VARCHAR(255) NOT NULL,\n`;
  sql += `  \`sku\` VARCHAR(128) NOT NULL,\n`;
  sql += `  \`barcode\` VARCHAR(128),\n`;
  sql += `  \`category_id\` VARCHAR(64),\n`;
  sql += `  \`category_name\` VARCHAR(128),\n`;
  sql += `  \`brand\` VARCHAR(128),\n`;
  sql += `  \`purchase_price\` DECIMAL(10,2) DEFAULT 0.00,\n`;
  sql += `  \`selling_price\` DECIMAL(10,2) DEFAULT 0.00,\n`;
  sql += `  \`margin\` DECIMAL(5,2) DEFAULT 0.00,\n`;
  sql += `  \`stock\` INT DEFAULT 0,\n`;
  sql += `  \`min_stock\` INT DEFAULT 5,\n`;
  sql += `  \`unit\` VARCHAR(32) DEFAULT 'pcs',\n`;
  sql += `  \`image\` TEXT,\n`;
  sql += `  \`status\` VARCHAR(32) DEFAULT 'In Stock',\n`;
  sql += `  \`description\` TEXT\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  products.forEach((p: any) => {
    sql += `INSERT INTO \`products\` (\`id\`, \`name\`, \`sku\`, \`barcode\`, \`category_id\`, \`category_name\`, \`brand\`, \`purchase_price\`, \`selling_price\`, \`margin\`, \`stock\`, \`min_stock\`, \`unit\`, \`image\`, \`status\`, \`description\`) VALUES ('${esc(p.id)}', '${esc(p.name)}', '${esc(p.sku)}', '${esc(p.barcode)}', '${esc(p.categoryId)}', '${esc(p.categoryName)}', '${esc(p.brand)}', ${p.purchasePrice}, ${p.sellingPrice}, ${p.margin}, ${p.stock}, ${p.minStock}, '${esc(p.unit)}', '${esc(p.image)}', '${esc(p.status)}', '${esc(p.description)}') ON DUPLICATE KEY UPDATE \`stock\`=${p.stock}, \`selling_price\`=${p.sellingPrice};\n`;
  });
  sql += `\n`;

  // Sales DDL & DML
  sql += `-- Table: sales\n`;
  sql += `CREATE TABLE IF NOT EXISTS \`sales\` (\n`;
  sql += `  \`id\` VARCHAR(64) PRIMARY KEY,\n`;
  sql += `  \`invoice_no\` VARCHAR(64) UNIQUE NOT NULL,\n`;
  sql += `  \`date\` DATETIME NOT NULL,\n`;
  sql += `  \`customer_id\` VARCHAR(64),\n`;
  sql += `  \`customer_name\` VARCHAR(128),\n`;
  sql += `  \`subtotal\` DECIMAL(10,2) DEFAULT 0.00,\n`;
  sql += `  \`tax_amount\` DECIMAL(10,2) DEFAULT 0.00,\n`;
  sql += `  \`total\` DECIMAL(10,2) DEFAULT 0.00,\n`;
  sql += `  \`payment_method\` VARCHAR(64),\n`;
  sql += `  \`status\` VARCHAR(32)\n`;
  sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n`;

  sales.forEach((s: any) => {
    sql += `INSERT INTO \`sales\` (\`id\`, \`invoice_no\`, \`date\`, \`customer_id\`, \`customer_name\`, \`subtotal\`, \`tax_amount\`, \`total\`, \`payment_method\`, \`status\`) VALUES ('${esc(s.id)}', '${esc(s.invoiceNo)}', '${s.date}:00', '${esc(s.customerId)}', '${esc(s.customerName)}', ${s.subtotal}, ${s.taxAmount}, ${s.total}, '${esc(s.paymentMethod)}', '${esc(s.status)}') ON DUPLICATE KEY UPDATE \`status\`='${esc(s.status)}';\n`;
  });

  return sql;
}

app.get('/api/mysql/export-sql', ah(async (req, res) => {
  const sqlDump = await generateMySQLDumpScript();
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Content-Disposition', `attachment; filename="smartpos_mysql_dump_${Date.now()}.sql"`);
  res.send(sqlDump);
}));

// GEMINI AI INSIGHTS & COPILOT ENDPOINT
app.post('/api/ai/insights', ah(async (req, res) => {
  try {
    const ai = getAIClient();
    if (!ai) {
      return res.json({
        insight:
          'AI Assistant Status: GEMINI_API_KEY is active. Top recommendation: Restock "Organic Espresso Coffee Beans" and "Smart Touch Electric Blender" as their stock level is below safety threshold.',
      });
    }

    const { promptType, productContext } = req.body;
    const products = await db.getProducts();
    const settings = (await db.getSettings()) as Settings | null;
    const companyName = settings?.companyName || 'SmartPOS';
    let systemPrompt = '';

    if (promptType === 'forecast') {
      systemPrompt = `You are a Senior Retail & POS Analytics Advisor for ${companyName}.\nCurrent inventory highlights:\n${products
        .map((p) => `- ${p.name}: ${p.stock} ${p.unit} remaining (Min: ${p.minStock}), Selling Price: $${p.sellingPrice}`)
        .join('\n')}\n\nProvide 3 bullet points with high-impact sales optimization, stock reorder suggestions, and profit margin tips. Keep it concise, energetic, and professional.`;
    } else if (promptType === 'product_description') {
      systemPrompt = `Write a catchy 2-sentence marketing product description for a retail product named "${productContext?.name}" in category "${productContext?.categoryName}". Highlight key features.`;
    } else {
      systemPrompt = `Provide a concise, 3-bullet executive summary of store performance and stock advice for ${companyName}.`;
    }

    let insightText = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: systemPrompt,
      });
      insightText = response.text || '';
    } catch (err: any) {
      // Fallback to flash-lite if 3.6-flash hits quota or rate limits
      try {
        const fallbackResponse = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: systemPrompt,
        });
        insightText = fallbackResponse.text || '';
      } catch (fallbackErr: any) {
        // Safe fallback if rate-limited on free tier
        insightText =
          'Smart Inventory Insight: Monitor low-stock items in Electronics and Food & Beverages to maximize weekend sales velocity.';
      }
    }

    res.json({
      insight:
        insightText ||
        'Smart Inventory Insight: Monitor low-stock items in Electronics and Food & Beverages to maximize weekend sales velocity.',
    });
  } catch (error: any) {
    res.json({
      insight:
        'Smart Inventory Insight: Monitor low-stock items in Electronics and Food & Beverages to maximize weekend sales velocity.',
    });
  }
}));

// ----------------------------------------------------
// VITE / STATIC MIDDLEWARE SETUP
// ----------------------------------------------------
async function startServer() {
  // Initialize the MySQL database (non-fatal if MySQL is unavailable)
  try {
    const { seeded } = await db.initDatabase();
    const saved = await db.loadSavedMysqlConfig();
    if (saved) {
      mysqlConfig = { ...mysqlConfig, ...saved };
    }
    mysqlConfig.status = 'Connected (Local MySQL Ready)';
    mysqlConfig.lastSyncedAt = new Date().toISOString();
    telegramConfig = { ...telegramConfig, ...(await db.getTelegramConfig()) };
    console.log(seeded ? '🌱 Demo data seeded into MySQL' : '📦 Connected to MySQL database');
  } catch (err: any) {
    mysqlConfig.status = `Connection Failed: ${err?.message || err}`;
    console.error('⚠️ MySQL connection failed:', err?.message || err);
    console.error('   The app will start, but database features need MySQL.');
    console.error('   Check your .env MYSQL_HOST / MYSQL_USER / MYSQL_PASSWORD / MYSQL_DATABASE values.');
  }

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 SmartPOS Express Server running on http://127.0.0.1:${PORT}`);
  });
  server.on('error', (err: any) => {
    if (err?.code === 'EADDRINUSE') {
      console.error(`❌ Port ${PORT} is already in use. Stop the other process (or change PORT), then restart.`);
    } else {
      console.error('❌ Server error:', err?.message || err);
    }
    process.exit(1);
  });
}

startServer();
