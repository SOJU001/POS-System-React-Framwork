# SmartPOS — Point of Sale & Management System

A full-featured retail POS system: POS terminal, products, inventory, sales, purchases, customers, suppliers, expenses, returns, users, dashboard analytics, Telegram alarms, and AI insights.

## Screenshots & Demo

<!-- Replace the placeholder image URLs with actual screenshots of your running app. -->

| Screen | Preview |
|:---|:---:|
| **Dashboard** — Analytics, charts, real-time KPIs | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Dashboard)` |
| **POS Terminal** — Ring up sales, scan barcodes, manage carts | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=POS+Terminal)` |
| **Products & Inventory** — Manage catalog, stock levels, variants | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Products+%26+Inventory)` |
| **Sales Orders** — Order history, invoices, refunds | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Sales+Orders)` |
| **Purchases** — Purchase orders, supplier tracking | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Purchases)` |
| **Customers** — Customer profiles, loyalty, purchase history | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Customers)` |
| **Reports** — Sales reports, profit analysis, export (PDF/Excel) | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Reports)` |
| **Settings** — System config, MySQL management, 2FA, users | `![](https://via.placeholder.com/600x350/1e293b/94a3b8?text=Settings)` |

> **Tip:** Take screenshots of your running app at http://127.0.0.1:3000 and replace the placeholder URLs above with the paths to those images (e.g., `screenshots/dashboard.png`). Consider adding a **demo GIF** or a **short video walkthrough** to the `public/` folder for a more engaging README.

## Architecture

- **Frontend:** React 19 + Vite + Tailwind CSS (in `src/`)
- **Backend:** Express server (`server.ts`) serving the app + REST API
- **Database:** **MySQL 8+** (local or remote). All data is persisted in MySQL — there is no in-memory or mock storage at runtime. The demo data is auto-seeded into MySQL on the first run.

## Prerequisites

- Node.js 18+ or **Bun**
- MySQL 8+ running locally (XAMPP, WAMP, MySQL Workbench, or standalone)

## Setup

1. Install dependencies:

   `npm install`

   > **Tip:** You can also use **Bun** (the project includes a `bun.lock` file):  
   > `bun install`

   > **Note:** This installs the Node modules into the `node_modules` folder. If you skip it (or `node_modules` is missing after cloning/downloading the project), `npm run dev` will fail with errors like `Cannot find module`. Make sure **Node.js 18+** (or Bun) is installed, then run this step first.

2. Create a `.env` file (copy from `.env.example`) and set your MySQL credentials:

   ```
   MYSQL_HOST=127.0.0.1
   MYSQL_PORT=3306
   MYSQL_USER=root
   MYSQL_PASSWORD=yourpassword
   MYSQL_DATABASE=smartpos_db
   ```

   > The `.env.example` file includes detailed comments explaining every variable. Just copy it and fill in your values.

3. (Optional) Telegram alarm bot:

   ```
   TELEGRAM_BOT_TOKEN=
   TELEGRAM_CHAT_ID=
   ```

4. Run the app:

   `npm run dev`

On startup the server:

- connects to your MySQL server and creates the `smartpos_db` database (if missing) with all tables,
- **seeds the demo data once** (products, categories, customers, sales, ...) only if a table is empty,
- serves the app at http://127.0.0.1:3000.

## Docker (Quick MySQL Setup)

If you don't have MySQL installed locally, use Docker to spin up a MySQL 8 server in seconds:

1. **Install [Docker Desktop](https://www.docker.com/products/docker-desktop/)** (Windows / macOS / Linux).

2. **Start a MySQL 8 container:**

   ```bash
   docker run -d \
     --name smartpos-mysql \
     -e MYSQL_ROOT_PASSWORD=rootpass \
     -e MYSQL_DATABASE=smartpos_db \
     -p 3306:3306 \
     mysql:8.0
   ```

   This creates a database named `smartpos_db` with root password `rootpass`.

3. **Configure your `.env`** to match:

   ```
   MYSQL_HOST=127.0.0.1
   MYSQL_PORT=3306
   MYSQL_USER=root
   MYSQL_PASSWORD=rootpass
   MYSQL_DATABASE=smartpos_db
   ```

4. **Start the app** — `npm run dev` — the server will connect to the Docker container and seed the demo data.

### Useful Docker commands

| Command | What it does |
|:---|:---|
| `docker ps` | Check if the container is running |
| `docker logs smartpos-mysql` | View MySQL startup logs |
| `docker stop smartpos-mysql` | Stop the container |
| `docker start smartpos-mysql` | Start it again (data persists) |
| `docker rm -f smartpos-mysql` | Delete the container (data is lost) |
| `docker exec -it smartpos-mysql mysql -uroot -prootpass smartpos_db` | Open a MySQL shell to inspect data |

> **Tip:** Add `--restart unless-stopped` to the `docker run` command so MySQL starts automatically when Docker launches.
> **Windows note:** Docker Desktop runs MySQL via WSL2. Port 3306 must be available — if you already have XAMPP/WAMP MySQL running, stop it first or change the host port (e.g. `-p 3307:3306` with `MYSQL_PORT=3307` in `.env`).

## Troubleshooting MySQL Connection

### Common errors & fixes

| Error | Likely cause | Fix |
|:---|:---|:---|
| `ER_ACCESS_DENIED_ERROR: Access denied for user 'root'@'localhost'` | Wrong password, or MySQL user doesn't have access from `127.0.0.1` | Double-check your `.env` `MYSQL_PASSWORD`. If using XAMPP with no password, set `MYSQL_PASSWORD=` (empty). |
| `ER_BAD_DB_ERROR: Unknown database 'smartpos_db'` | Database doesn't exist yet | The server auto-creates it on startup. If it fails, run `CREATE DATABASE smartpos_db;` manually in your MySQL client. |
| `connect ECONNREFUSED 127.0.0.1:3306` | MySQL is not running | Start MySQL (via XAMPP, WAMP, `systemctl start mysql`, or MySQL Workbench). Check Task Manager for `mysqld.exe`. |
| `ER_HOST_NOT_PRIVILEGED: Host '...' is not allowed to connect` | MySQL user lacks remote access | For local use, run: `GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' IDENTIFIED BY 'password'; FLUSH PRIVILEGES;` |
| `Handshake inactivity timeout` / `ETIMEDOUT` | Wrong host/port, or MySQL is bound to a different port | Verify `MYSQL_PORT` (default is `3306`). Check MySQL config (`my.cnf` or `my.ini`) for the actual port. |
| `Cannot enqueue Query after fatal error` | Connection was lost mid-operation | Restart the server. If it persists, check for MySQL service crashes or network issues. |
| `ENOENT: connect ENETUNREACH` | MySQL is on a different machine and unreachable | Check network connectivity, firewall rules, and that `bind-address` in MySQL config allows remote connections. |

### Quick checks

1. **Is MySQL running?**
   - Windows (XAMPP): Open the XAMPP Control Panel and check if **MySQL** is green/started.
   - Windows (standalone): Open Command Prompt and run `sc query MySQL80` (or `net start MySQL80`).
   - Linux / macOS: `sudo systemctl status mysql` or `sudo service mysql status`.

2. **Can you connect manually?**
   - Open a terminal and try:
     ```bash
     mysql -u root -p -h 127.0.0.1 -P 3306
     ```
   - If that works, your server config should work too. If it fails, fix the MySQL user/permissions first.

3. **Did you restart the app after editing `.env`?**
   - Stop the server (Ctrl+C) and run `npm run dev` again — the `.env` file is only read at startup.

4. **Check the server logs**
   - When you run `npm run dev`, look for lines starting with `⚠️ MySQL connection failed:` — the error message tells you exactly what's wrong.

### Still stuck?

- Make sure your MySQL version is **8.0 or later** (older versions may have compatibility issues with `mysql2`).
- Try running `npm run migrate` separately — it will show you a detailed error if the connection fails.
- If you recently changed the database password, update both `.env` and run Settings → **Sync MySQL Schema** to reauthenticate.
- For **XAMPP** users: the default MySQL root password is **empty**. Leave `MYSQL_PASSWORD=` blank in `.env`.
- For **WAMP** users: the default MySQL root password is also **empty**. If you set a password via phpMyAdmin, use that same password.

## Database Migration

Your data is stored in MySQL. When you update the app to a newer version, the schema is kept **up to date automatically**:

- Every server start runs lightweight migrations for older installs (for example, it adds the `khr_exchange_rate` column to the `settings` table if it's missing).
- `CREATE TABLE IF NOT EXISTS` + seed-only-if-empty means **your existing data is never overwritten**.
- You can also run the migration manually at any time (safe, idempotent):

  `npm run migrate`

  This connects to MySQL, creates any missing tables, applies pending column migrations, and seeds demo data only into empty tables.

  > If you get a migration error, make sure MySQL is running and your `MYSQL_*` values in `.env` are correct.

## MySQL in Settings

The **Settings → Local & Remote MySQL Database Connection** panel lets you:

- **Test Connection** — performs a real connection/ping to your MySQL server.
- **Sync MySQL Schema** — (re)creates the schema and seeds demo data if a table is empty.
- **Download .sql Export** — dumps current data as a portable SQL script.
- **Backup / Restore** — JSON snapshot backup of all tables.

## Commands

| Command | Description |
| --- | --- |
| `npm run dev` | Start dev server (Express + Vite, port 3000) |
| `npm run build` | Production build (client + bundled server) |
| `npm start` | Run the production build |
| `npm run migrate` | Create/sync MySQL schema, apply pending migrations, seed empty tables |
| `npm run lint` | TypeScript typecheck (`tsc --noEmit`) |

> If you're using **Bun**, replace `npm` with `bun` (e.g. `bun run dev`, `bun run build`).

## Login & Security

Login is now secured:

- **Hashed passwords** — all passwords are stored as bcrypt hashes and verified on sign-in (no more "any password" demo behavior).
- **Two-Factor Authentication (2FA)** — any user can enable TOTP-based 2FA from **Settings → Two-Factor Authentication** (scan the QR code with Google Authenticator / Authy). Once enabled, sign-in requires your password plus a 6-digit code.
- **Session persistence** — after signing in you stay logged in until you log out (session is stored in the browser).

Default passwords for the seeded demo accounts (change them after first login!):

| Role | Email | Default password |
| --- | --- | --- |
| Admin | `admin@smartpos.com` | `Admin@123` |
| Manager | `manager@smartpos.com` | `Manager@123` |
| Cashier | `cashier@smartpos.com` | `Cashier@123` |

> On upgrade, existing installs are migrated automatically: the 2FA columns are added and legacy users without a password are assigned the role-based default above.

### Google Sign-In (optional)

1. Go to the [Google Cloud Console](https://console.cloud.google.com/) → **APIs & Services** → **Credentials** → **Create Credentials** → **OAuth client ID** (type: *Web application*).
2. Under **Authorized JavaScript origins**, add `http://localhost:3000` (and your production URL).
3. Copy the Client ID into **both** of these lines in your `.env`:
   ```
   GOOGLE_CLIENT_ID=your_client_id.apps.googleusercontent.com
   VITE_GOOGLE_CLIENT_ID=your_client_id.apps.googleusercontent.com
   ```
4. Restart the server (`npm run dev`). The **Sign in with Google** button appears on the login page.

Google sign-in only works for **emails that already exist in the users table** — the account's role and name are used from SmartPOS. If an email is not a staff member, sign-in is rejected.
