import { createConnection, createPool } from 'mysql2/promise';
import type { Pool, PoolConnection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import {
  initialSettings,
  initialUsers,
  initialCategories,
  initialProducts,
  initialCustomers,
  initialSuppliers,
  initialSales,
  initialPurchases,
  initialExpenses,
  initialStockAdjustments,
} from './src/data/mockData';
import type {
  User,
  Category,
  Product,
  Customer,
  Supplier,
  Sale,
  Purchase,
  Expense,
  Settings,
  StockAdjustment,
  SaleReturn,
} from './src/types';

// ------------------------------------------------------------
// CONNECTION MANAGEMENT
// ------------------------------------------------------------

export interface MysqlConfig {
  host: string;
  port: number;
  user: string;
  password: string;
  database: string;
  ssl?: boolean;
}

let pool: Pool | null = null;

export function getPool(): Pool {
  if (!pool) {
    throw new Error(
      'MySQL database is not connected. Check your MYSQL_* environment variables, ensure MySQL is running, then use "Sync MySQL Schema" in Settings.'
    );
  }
  return pool;
}

export function envMysqlConfig(): MysqlConfig {
  return {
    host: process.env.MYSQL_HOST || '127.0.0.1',
    port: Number(process.env.MYSQL_PORT) || 3306,
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'smartpos_db',
  };
}

/** Actually connects to MySQL with the given config and pings the server. */
export async function testMysqlConnection(cfg: MysqlConfig): Promise<{ version: string; pingMs: number }> {
  const started = Date.now();
  const conn = await createConnection({
    host: cfg.host,
    port: cfg.port,
    user: cfg.user,
    password: cfg.password,
    connectTimeout: 10000,
  });
  try {
    const [rows] = await conn.query('SELECT VERSION() AS version');
    const version = (rows as RowDataPacket[])[0]?.version as string;
    return { version: version || 'unknown', pingMs: Date.now() - started };
  } finally {
    await conn.end();
  }
}

/** Creates the database + tables and seeds demo data on first run. Swaps the active pool. */
export async function initDatabase(overrides?: Partial<MysqlConfig>): Promise<{ seeded: boolean }> {
  const cfg = { ...envMysqlConfig(), ...overrides };
  const safeDb = cfg.database.replace(/`/g, '``');

  const bootstrap = await createConnection({
    host: cfg.host,
    port: cfg.port,
    user: cfg.user,
    password: cfg.password,
    connectTimeout: 10000,
  });
  try {
    await bootstrap.query(
      `CREATE DATABASE IF NOT EXISTS \`${safeDb}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
  } finally {
    await bootstrap.end();
  }

  if (pool) {
    try {
      await pool.end();
    } catch {
      // ignore shutdown errors
    }
  }

  pool = createPool({
    host: cfg.host,
    port: cfg.port,
    user: cfg.user,
    password: cfg.password,
    database: cfg.database,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    connectTimeout: 10000,
  });

  await createTables();
  const seeded = await seedIfEmpty();
  return { seeded };
}

// ------------------------------------------------------------
// SCHEMA
// ------------------------------------------------------------

const DDL: string[] = [
  `CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(255) NOT NULL,
    company_tagline VARCHAR(255),
    address TEXT,
    phone VARCHAR(64),
    email VARCHAR(128),
    vat_number VARCHAR(64),
    currency VARCHAR(16),
    currency_symbol VARCHAR(8),
    khr_exchange_rate DECIMAL(12,2) DEFAULT 4100.00,
    tax_rate DECIMAL(5,2) DEFAULT 10.00,
    receipt_header TEXT,
    receipt_footer TEXT,
    logo_url TEXT,
    enable_sound TINYINT(1) DEFAULT 1,
    enable_ai_assistant TINYINT(1) DEFAULT 1
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    email VARCHAR(128) NOT NULL,
    role VARCHAR(32),
    username VARCHAR(64),
    password VARCHAR(128),
    pin VARCHAR(16),
    avatar TEXT,
    phone VARCHAR(64),
    status VARCHAR(16) DEFAULT 'Active',
    created_at VARCHAR(32),
    two_factor_secret TEXT,
    two_factor_enabled TINYINT(1) DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    code VARCHAR(32),
    icon VARCHAR(64),
    item_count INT DEFAULT 0,
    description TEXT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS products (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    sku VARCHAR(128),
    barcode VARCHAR(128),
    qr_code TEXT,
    category_id VARCHAR(64),
    category_name VARCHAR(128),
    brand VARCHAR(128),
    purchase_price DECIMAL(12,2) DEFAULT 0.00,
    selling_price DECIMAL(12,2) DEFAULT 0.00,
    margin DECIMAL(6,2) DEFAULT 0.00,
    stock INT DEFAULT 0,
    min_stock INT DEFAULT 5,
    unit VARCHAR(32) DEFAULT 'pcs',
    image TEXT,
    status VARCHAR(32) DEFAULT 'In Stock',
    description TEXT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS customers (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    phone VARCHAR(64),
    email VARCHAR(128),
    address TEXT,
    points INT DEFAULT 0,
    tier VARCHAR(16) DEFAULT 'Bronze',
    total_spent DECIMAL(12,2) DEFAULT 0.00,
    last_purchase_date VARCHAR(32)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS suppliers (
    id VARCHAR(64) PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(128),
    email VARCHAR(128),
    phone VARCHAR(64),
    address TEXT,
    tax_number VARCHAR(64)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS sales (
    id VARCHAR(64) PRIMARY KEY,
    invoice_no VARCHAR(64) NOT NULL,
    date VARCHAR(32) NOT NULL,
    customer_id VARCHAR(64),
    customer_name VARCHAR(128),
    cashier_id VARCHAR(64),
    cashier_name VARCHAR(128),
    items JSON,
    subtotal DECIMAL(12,2) DEFAULT 0.00,
    discount DECIMAL(12,2) DEFAULT 0.00,
    tax DECIMAL(6,2) DEFAULT 0.00,
    tax_amount DECIMAL(12,2) DEFAULT 0.00,
    total DECIMAL(12,2) DEFAULT 0.00,
    payment_method VARCHAR(64),
    payment_details JSON,
    status VARCHAR(32) DEFAULT 'Completed',
    note TEXT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS purchases (
    id VARCHAR(64) PRIMARY KEY,
    po_no VARCHAR(64) NOT NULL,
    supplier_id VARCHAR(64),
    supplier_name VARCHAR(255),
    date VARCHAR(32),
    items JSON,
    total_amount DECIMAL(12,2) DEFAULT 0.00,
    status VARCHAR(32) DEFAULT 'Received',
    payment_status VARCHAR(32) DEFAULT 'Unpaid',
    note TEXT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS expenses (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category_id VARCHAR(64),
    category_name VARCHAR(128),
    amount DECIMAL(12,2) DEFAULT 0.00,
    date VARCHAR(32),
    note TEXT,
    created_by VARCHAR(128)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS stock_adjustments (
    id VARCHAR(64) PRIMARY KEY,
    date VARCHAR(32),
    product_id VARCHAR(64),
    product_name VARCHAR(255),
    type VARCHAR(32),
    quantity INT,
    reason TEXT,
    adjusted_by VARCHAR(128)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS sales_returns (
    id VARCHAR(64) PRIMARY KEY,
    return_no VARCHAR(64),
    sale_id VARCHAR(64),
    invoice_no VARCHAR(64),
    date VARCHAR(32),
    customer_name VARCHAR(128),
    items JSON,
    total_refund DECIMAL(12,2) DEFAULT 0.00,
    reason TEXT,
    refund_method VARCHAR(64)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS telegram_config (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bot_token VARCHAR(255),
    chat_id VARCHAR(128),
    enable_low_stock_alerts TINYINT(1) DEFAULT 1,
    enable_sales_alerts TINYINT(1) DEFAULT 1,
    last_alert_sent_at VARCHAR(64)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS mysql_config (
    id INT PRIMARY KEY AUTO_INCREMENT,
    host VARCHAR(128),
    port INT,
    user VARCHAR(64),
    database_name VARCHAR(128),
    use_ssl TINYINT(1) DEFAULT 0,
    auto_sync TINYINT(1) DEFAULT 1
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
];

async function createTables(): Promise<void> {
  for (let i = 0; i < DDL.length; i++) {
    try {
      await getPool().query(DDL[i]);
    } catch (err: any) {
      console.error(`[db] createTables failed at statement #${i} (${DDL[i].slice(0, 70)}...)`);
      throw err;
    }
  }

  // Migration: add khr_exchange_rate to existing settings tables (older installs)
  try {
    const [rows] = await getPool().query(
      `SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'settings' AND COLUMN_NAME = 'khr_exchange_rate'`
    );
    const hasColumn = Number((rows as RowDataPacket[])[0]?.cnt || 0) > 0;
    if (!hasColumn) {
      await getPool().query(`ALTER TABLE settings ADD COLUMN khr_exchange_rate DECIMAL(12,2) DEFAULT 4100.00`);
      console.log('[db] Added khr_exchange_rate column to settings table');
    }
  } catch (err: any) {
    console.error('[db] Failed to migrate settings.khr_exchange_rate:', err?.message || err);
  }

  // Migration: add 2FA columns to existing users tables (older installs)
  try {
    const [rows] = await getPool().query(
      `SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'two_factor_enabled'`
    );
    const hasColumn = Number((rows as RowDataPacket[])[0]?.cnt || 0) > 0;
    if (!hasColumn) {
      await getPool().query(`ALTER TABLE users ADD COLUMN two_factor_enabled TINYINT(1) DEFAULT 0`);
      console.log('[db] Added two_factor_enabled column to users table');
    }
    const [rows2] = await getPool().query(
      `SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'two_factor_secret'`
    );
    const hasSecret = Number((rows2 as RowDataPacket[])[0]?.cnt || 0) > 0;
    if (!hasSecret) {
      await getPool().query(`ALTER TABLE users ADD COLUMN two_factor_secret TEXT`);
      console.log('[db] Added two_factor_secret column to users table');
    }
  } catch (err: any) {
    console.error('[db] Failed to migrate users 2FA columns:', err?.message || err);
  }

  // Migration: add role_permissions to existing settings tables (older installs)
  try {
    const [rows] = await getPool().query(
      `SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'settings' AND COLUMN_NAME = 'role_permissions'`
    );
    const hasColumn = Number((rows as RowDataPacket[])[0]?.cnt || 0) > 0;
    if (!hasColumn) {
      await getPool().query(`ALTER TABLE settings ADD COLUMN role_permissions JSON`);
      console.log('[db] Added role_permissions column to settings table');
    }
  } catch (err: any) {
    console.error('[db] Failed to migrate settings.role_permissions:', err?.message || err);
  }

  // Migration: backfill hashed default passwords for legacy users that have none
  try {
    await backfillUserPasswords();
  } catch (err: any) {
    console.error('[db] Failed to backfill user passwords:', err?.message || err);
  }
}

// ------------------------------------------------------------
// GENERIC HELPERS
// ------------------------------------------------------------

export async function query<T>(sql: string, params: any[] = [], conn?: PoolConnection): Promise<T[]> {
  const [rows] = await (conn ?? getPool()).execute(sql, params);
  return rows as T[];
}

export async function execute(
  sql: string,
  params: any[] = [],
  conn?: PoolConnection
): Promise<ResultSetHeader> {
  const [result] = await (conn ?? getPool()).execute(sql, params);
  return result as ResultSetHeader;
}

export async function withTransaction<T>(fn: (conn: PoolConnection) => Promise<T>): Promise<T> {
  const conn = await getPool().getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback().catch(() => {});
    throw err;
  } finally {
    conn.release();
  }
}

function numify<T extends Record<string, any>>(row: T, keys: string[]): T {
  const copy: any = { ...row };
  for (const key of keys) {
    if (copy[key] !== null && copy[key] !== undefined) copy[key] = Number(copy[key]);
  }
  return copy;
}

function numifyAll<T extends Record<string, any>>(rows: T[], keys: string[]): T[] {
  return rows.map((r) => numify(r, keys));
}

/** Builds a dynamic UPDATE ... SET ... WHERE id = ? statement from a camelCase -> column map. */
function buildUpdate(table: string, data: Record<string, any>, id: string | number, columnMap: Record<string, string>) {
  const entries = Object.entries(data).filter(
    ([key, value]) => columnMap[key] !== undefined && value !== undefined
  );
  if (!entries.length) return { sql: '', params: [] as unknown[] };
  const sets = entries.map(([key]) => `${columnMap[key]} = ?`);
  const params = entries.map(([, value]) => (typeof value === 'boolean' ? (value ? 1 : 0) : value));
  return { sql: `UPDATE ${table} SET ${sets.join(', ')} WHERE id = ?`, params: [...params, id] };
}

// ------------------------------------------------------------
// SETTINGS
// ------------------------------------------------------------

const SETTINGS_SELECT = `SELECT id, company_name AS companyName, company_tagline AS companyTagline, address, phone, email, vat_number AS vatNumber, currency, currency_symbol AS currencySymbol, khr_exchange_rate AS khrExchangeRate, tax_rate AS taxRate, receipt_header AS receiptHeader, receipt_footer AS receiptFooter, logo_url AS logoUrl, enable_sound AS enableSound, enable_ai_assistant AS enableAIAssistant, role_permissions FROM settings WHERE id = 1`;

const SETTINGS_COLUMNS: Record<string, string> = {
  companyName: 'company_name',
  companyTagline: 'company_tagline',
  address: 'address',
  phone: 'phone',
  email: 'email',
  vatNumber: 'vat_number',
  currency: 'currency',
  currencySymbol: 'currency_symbol',
  khrExchangeRate: 'khr_exchange_rate',
  taxRate: 'tax_rate',
  receiptHeader: 'receipt_header',
  receiptFooter: 'receipt_footer',
  logoUrl: 'logo_url',
  enableSound: 'enable_sound',
  enableAIAssistant: 'enable_ai_assistant',
  rolePermissions: 'role_permissions',
};

export async function getSettings(): Promise<Settings | null> {
  const rows = await query<any>(SETTINGS_SELECT);
  if (!rows.length) return null;
  const row = rows[0];
  return {
    ...row,
    khrExchangeRate: Number(row.khrExchangeRate) || 4100,
    taxRate: Number(row.taxRate),
    enableSound: !!row.enableSound,
    enableAIAssistant: !!row.enableAIAssistant,
    rolePermissions: row.rolePermissions ? JSON.parse(row.rolePermissions) : undefined,
  } as Settings;
}

export async function updateSettings(data: Partial<Settings>): Promise<void> {
  await execute(`INSERT INTO settings (id) VALUES (1) ON DUPLICATE KEY UPDATE id = id`);
  const upd = buildUpdate('settings', data as Record<string, any>, 1, SETTINGS_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

// ------------------------------------------------------------
// TELEGRAM CONFIG
// ------------------------------------------------------------

const TELEGRAM_COLUMNS: Record<string, string> = {
  botToken: 'bot_token',
  chatId: 'chat_id',
  enableLowStockAlerts: 'enable_low_stock_alerts',
  enableSalesAlerts: 'enable_sales_alerts',
  lastAlertSentAt: 'last_alert_sent_at',
};

export interface TelegramConfig {
  botToken: string;
  chatId: string;
  enableLowStockAlerts: boolean;
  enableSalesAlerts: boolean;
  lastAlertSentAt: string | null;
}

export async function getTelegramConfig(): Promise<TelegramConfig> {
  const rows = await query<any>(
    `SELECT bot_token AS botToken, chat_id AS chatId, enable_low_stock_alerts AS enableLowStockAlerts, enable_sales_alerts AS enableSalesAlerts, last_alert_sent_at AS lastAlertSentAt FROM telegram_config WHERE id = 1`
  );
  if (!rows.length) {
    return { botToken: '', chatId: '', enableLowStockAlerts: true, enableSalesAlerts: true, lastAlertSentAt: null };
  }
  const r = rows[0];
  return {
    botToken: r.botToken || '',
    chatId: r.chatId || '',
    enableLowStockAlerts: !!r.enableLowStockAlerts,
    enableSalesAlerts: !!r.enableSalesAlerts,
    lastAlertSentAt: r.lastAlertSentAt || null,
  };
}

export async function updateTelegramConfig(data: Partial<TelegramConfig>): Promise<void> {
  await execute(`INSERT INTO telegram_config (id) VALUES (1) ON DUPLICATE KEY UPDATE id = id`);
  const upd = buildUpdate('telegram_config', data as Record<string, any>, 1, TELEGRAM_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

// ------------------------------------------------------------
// USERS
// ------------------------------------------------------------

const USER_SELECT = `SELECT id, name, email, role, username, password, pin, avatar, phone, status, created_at AS createdAt, two_factor_secret AS twoFactorSecret, two_factor_enabled AS twoFactorEnabled FROM users`;

const USER_COLUMNS: Record<string, string> = {
  name: 'name',
  email: 'email',
  role: 'role',
  username: 'username',
  password: 'password',
  pin: 'pin',
  avatar: 'avatar',
  phone: 'phone',
  status: 'status',
  createdAt: 'created_at',
  twoFactorSecret: 'two_factor_secret',
  twoFactorEnabled: 'two_factor_enabled',
};

const BCRYPT_ROUNDS = 10;

/** Returns the default password assigned to a user based on their role (used for seeded users). */
export function defaultPasswordForRole(role?: string): string {
  if (role === 'Admin') return 'Admin@123';
  if (role === 'Manager') return 'Manager@123';
  return 'Cashier@123';
}

/** True if the value looks like an already-hashed bcrypt password. */
export function isHashedPassword(pw?: string | null): boolean {
  return !!pw && (pw.startsWith('$2a$') || pw.startsWith('$2b$') || pw.startsWith('$2y$'));
}

/** Removes sensitive fields (password hash, TOTP secret) before sending a user to the client. */
export function sanitizeUser<T extends Record<string, any>>(u: T | null | undefined): T | null {
  if (!u) return null;
  const copy: any = { ...u };
  delete copy.password;
  delete copy.twoFactorSecret;
  copy.twoFactorEnabled = !!copy.twoFactorEnabled;
  return copy as T;
}

async function backfillUserPasswords(): Promise<void> {
  const rows = await query<any>(`SELECT id, role FROM users WHERE password IS NULL OR password = ''`);
  for (const row of rows) {
    const hash = await bcrypt.hash(defaultPasswordForRole(row.role), BCRYPT_ROUNDS);
    await execute(`UPDATE users SET password = ? WHERE id = ?`, [hash, row.id]);
  }
  if (rows.length) console.log(`[db] Backfilled default passwords for ${rows.length} legacy user(s)`);
}

export async function getUsers(): Promise<User[]> {
  const rows = await query<any>(`${USER_SELECT} ORDER BY created_at ASC`);
  return rows.map((r) => sanitizeUser({ ...r, twoFactorEnabled: !!r.twoFactorEnabled }) as User);
}

export async function getFirstUser(): Promise<User | null> {
  const rows = await query<User>(`${USER_SELECT} ORDER BY created_at ASC LIMIT 1`);
  return rows[0] ?? null;
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const rows = await query<User>(`${USER_SELECT} WHERE LOWER(email) = ?`, [email.toLowerCase()]);
  return rows[0] ?? null;
}

export async function getUserById(id: string): Promise<User | null> {
  const rows = await query<User>(`${USER_SELECT} WHERE id = ?`, [id]);
  return rows[0] ?? null;
}

export async function insertUser(u: User, conn?: PoolConnection): Promise<void> {
  const rawPassword = u.password && !isHashedPassword(u.password) ? u.password : (u.password || defaultPasswordForRole(u.role));
  const passwordHash = isHashedPassword(rawPassword) ? rawPassword : await bcrypt.hash(rawPassword, BCRYPT_ROUNDS);
  await execute(
    `INSERT INTO users (id, name, email, role, username, password, pin, avatar, phone, status, created_at, two_factor_secret, two_factor_enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      u.id, u.name, u.email, u.role || null, u.username || null, passwordHash,
      u.pin || null, u.avatar || null, u.phone || null, u.status || 'Active', u.createdAt || null,
      u.twoFactorSecret || null, u.twoFactorEnabled ? 1 : 0,
    ],
    conn
  );
}

export async function updateUser(id: string, data: Partial<User>): Promise<void> {
  const copy: any = { ...data };
  if (copy.password !== undefined && copy.password !== null && !isHashedPassword(copy.password)) {
    copy.password = await bcrypt.hash(String(copy.password), BCRYPT_ROUNDS);
  }
  const upd = buildUpdate('users', copy, id, USER_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

export async function setUserTwoFactorSecret(userId: string, secret: string): Promise<void> {
  await execute(`UPDATE users SET two_factor_secret = ? WHERE id = ?`, [secret, userId]);
}

export async function setUserTwoFactorEnabled(userId: string, enabled: boolean): Promise<void> {
  await execute(`UPDATE users SET two_factor_enabled = ? WHERE id = ?`, [enabled ? 1 : 0, userId]);
}

export async function deleteUser(id: string): Promise<void> {
  await execute(`DELETE FROM users WHERE id = ?`, [id]);
}

// ------------------------------------------------------------
// CATEGORIES
// ------------------------------------------------------------

const CATEGORY_SELECT = `SELECT id, name, code, icon, item_count AS itemCount, description FROM categories`;

const CATEGORY_COLUMNS: Record<string, string> = {
  name: 'name',
  code: 'code',
  icon: 'icon',
  itemCount: 'item_count',
  description: 'description',
};

export async function getCategories(): Promise<Category[]> {
  const rows = await query<any>(`${CATEGORY_SELECT} ORDER BY name ASC`);
  return numifyAll(rows, ['itemCount']);
}

export async function insertCategory(c: Category, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO categories (id, name, code, icon, item_count, description) VALUES (?, ?, ?, ?, ?, ?)`,
    [c.id, c.name, c.code || null, c.icon || 'Tag', c.itemCount ?? 0, c.description || null],
    conn
  );
}

export async function updateCategory(id: string, data: Partial<Category>): Promise<void> {
  const upd = buildUpdate('categories', data as Record<string, any>, id, CATEGORY_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

export async function deleteCategory(id: string): Promise<void> {
  await execute(`DELETE FROM categories WHERE id = ?`, [id]);
}

// ------------------------------------------------------------
// PRODUCTS
// ------------------------------------------------------------

const PRODUCT_SELECT = `SELECT id, name, sku, barcode, qr_code AS qrCode, category_id AS categoryId, category_name AS categoryName, brand, purchase_price AS purchasePrice, selling_price AS sellingPrice, margin, stock, min_stock AS minStock, unit, image, status, description FROM products`;

const PRODUCT_COLUMNS: Record<string, string> = {
  name: 'name',
  sku: 'sku',
  barcode: 'barcode',
  qrCode: 'qr_code',
  categoryId: 'category_id',
  categoryName: 'category_name',
  brand: 'brand',
  purchasePrice: 'purchase_price',
  sellingPrice: 'selling_price',
  margin: 'margin',
  stock: 'stock',
  minStock: 'min_stock',
  unit: 'unit',
  image: 'image',
  status: 'status',
  description: 'description',
};

const PRODUCT_NUM_KEYS = ['purchasePrice', 'sellingPrice', 'margin', 'stock', 'minStock'];

export async function getProducts(): Promise<Product[]> {
  const rows = await query<any>(PRODUCT_SELECT);
  return numifyAll(rows, PRODUCT_NUM_KEYS);
}

export async function getProductById(id: string, conn?: PoolConnection): Promise<Product | null> {
  const rows = await query<any>(`${PRODUCT_SELECT} WHERE id = ?`, [id], conn);
  if (!rows.length) return null;
  return numify(rows[0], PRODUCT_NUM_KEYS);
}

export async function insertProduct(p: Product, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO products (id, name, sku, barcode, qr_code, category_id, category_name, brand, purchase_price, selling_price, margin, stock, min_stock, unit, image, status, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      p.id, p.name, p.sku || null, p.barcode || null, p.qrCode || null, p.categoryId || null,
      p.categoryName || null, p.brand || null, p.purchasePrice ?? 0, p.sellingPrice ?? 0,
      p.margin ?? 0, p.stock ?? 0, p.minStock ?? 5, p.unit || 'pcs', p.image || '',
      p.status || 'In Stock', p.description || null,
    ],
    conn
  );
}

export async function updateProduct(id: string, data: Partial<Product>): Promise<void> {
  const upd = buildUpdate('products', data as Record<string, any>, id, PRODUCT_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

export async function deleteProduct(id: string): Promise<void> {
  await execute(`DELETE FROM products WHERE id = ?`, [id]);
}

/** Deducts stock after a sale and recomputes status from min_stock. */
export async function deductSaleStock(productId: string, qty: number, conn?: PoolConnection): Promise<void> {
  await execute(
    `UPDATE products SET stock = GREATEST(0, stock - ?),
       status = CASE
         WHEN GREATEST(0, stock - ?) = 0 THEN 'Out of Stock'
         WHEN GREATEST(0, stock - ?) <= min_stock THEN 'Low Stock'
         ELSE 'In Stock'
       END
     WHERE id = ?`,
    [qty, qty, qty, productId],
    conn
  );
}

/** Adds stock (purchase received / refund) and marks product as in stock. */
export async function addProductStock(productId: string, qty: number, conn?: PoolConnection): Promise<void> {
  await execute(`UPDATE products SET stock = stock + ?, status = 'In Stock' WHERE id = ?`, [qty, productId], conn);
}

/** Adjusts stock by a delta (inventory adjustments), clamping at 0, without touching status. */
export async function changeProductStock(productId: string, delta: number, conn?: PoolConnection): Promise<void> {
  await execute(`UPDATE products SET stock = GREATEST(0, stock + ?) WHERE id = ?`, [delta, productId], conn);
}

// ------------------------------------------------------------
// CUSTOMERS
// ------------------------------------------------------------

const CUSTOMER_SELECT = `SELECT id, name, phone, email, address, points, tier, total_spent AS totalSpent, last_purchase_date AS lastPurchaseDate FROM customers`;

const CUSTOMER_COLUMNS: Record<string, string> = {
  name: 'name',
  phone: 'phone',
  email: 'email',
  address: 'address',
  points: 'points',
  tier: 'tier',
  totalSpent: 'total_spent',
  lastPurchaseDate: 'last_purchase_date',
};

export async function getCustomers(): Promise<Customer[]> {
  const rows = await query<any>(CUSTOMER_SELECT);
  return numifyAll(rows, ['points', 'totalSpent']);
}

export async function insertCustomer(c: Customer, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO customers (id, name, phone, email, address, points, tier, total_spent, last_purchase_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [c.id, c.name, c.phone || null, c.email || null, c.address || null, c.points ?? 0, c.tier || 'Bronze', c.totalSpent ?? 0, c.lastPurchaseDate || null],
    conn
  );
}

export async function updateCustomer(id: string, data: Partial<Customer>): Promise<void> {
  const upd = buildUpdate('customers', data as Record<string, any>, id, CUSTOMER_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

export async function deleteCustomer(id: string): Promise<void> {
  await execute(`DELETE FROM customers WHERE id = ?`, [id]);
}

/** Awards loyalty points + total spent + tier after a completed sale. */
export async function applyCustomerPurchase(customerId: string, total: number, conn?: PoolConnection): Promise<void> {
  const rows = await query<any>(`SELECT total_spent AS totalSpent FROM customers WHERE id = ?`, [customerId], conn);
  if (!rows.length) return;
  const newTotalSpent = Number(rows[0].totalSpent) + total;
  let tier = 'Bronze';
  if (newTotalSpent > 3000) tier = 'VIP';
  else if (newTotalSpent > 1500) tier = 'Gold';
  else if (newTotalSpent > 500) tier = 'Silver';
  await execute(
    `UPDATE customers SET points = points + ?, total_spent = ?, tier = ?, last_purchase_date = ? WHERE id = ?`,
    [Math.floor(total), newTotalSpent, tier, new Date().toISOString().split('T')[0], customerId],
    conn
  );
}

// ------------------------------------------------------------
// SUPPLIERS
// ------------------------------------------------------------

const SUPPLIER_SELECT = `SELECT id, company_name AS companyName, contact_person AS contactPerson, email, phone, address, tax_number AS taxNumber FROM suppliers`;

const SUPPLIER_COLUMNS: Record<string, string> = {
  companyName: 'company_name',
  contactPerson: 'contact_person',
  email: 'email',
  phone: 'phone',
  address: 'address',
  taxNumber: 'tax_number',
};

export async function getSuppliers(): Promise<Supplier[]> {
  return query<Supplier>(SUPPLIER_SELECT);
}

export async function insertSupplier(s: Supplier, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO suppliers (id, company_name, contact_person, email, phone, address, tax_number) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [s.id, s.companyName, s.contactPerson || null, s.email || null, s.phone || null, s.address || null, s.taxNumber || null],
    conn
  );
}

export async function updateSupplier(id: string, data: Partial<Supplier>): Promise<void> {
  const upd = buildUpdate('suppliers', data as Record<string, any>, id, SUPPLIER_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params);
}

export async function deleteSupplier(id: string): Promise<void> {
  await execute(`DELETE FROM suppliers WHERE id = ?`, [id]);
}

// ------------------------------------------------------------
// SALES
// ------------------------------------------------------------

const SALE_SELECT = `SELECT id, invoice_no AS invoiceNo, date, customer_id AS customerId, customer_name AS customerName, cashier_id AS cashierId, cashier_name AS cashierName, items, subtotal, discount, tax, tax_amount AS taxAmount, total, payment_method AS paymentMethod, payment_details AS paymentDetails, status, note FROM sales`;

const SALE_NUM_KEYS = ['subtotal', 'discount', 'tax', 'taxAmount', 'total'];

export async function getSales(): Promise<Sale[]> {
  const rows = await query<any>(`${SALE_SELECT} ORDER BY date DESC`);
  return numifyAll(rows, SALE_NUM_KEYS);
}

export async function getSaleById(id: string, conn?: PoolConnection): Promise<Sale | null> {
  const rows = await query<any>(`${SALE_SELECT} WHERE id = ?`, [id], conn);
  if (!rows.length) return null;
  return numify(rows[0], SALE_NUM_KEYS);
}

export async function insertSale(s: Sale, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO sales (id, invoice_no, date, customer_id, customer_name, cashier_id, cashier_name, items, subtotal, discount, tax, tax_amount, total, payment_method, payment_details, status, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      s.id, s.invoiceNo, s.date, s.customerId || null, s.customerName || null, s.cashierId || null,
      s.cashierName || null, JSON.stringify(s.items || []), s.subtotal ?? 0, s.discount ?? 0,
      s.tax ?? 0, s.taxAmount ?? 0, s.total ?? 0, s.paymentMethod || null,
      JSON.stringify(s.paymentDetails || {}), s.status || 'Completed', s.note || null,
    ],
    conn
  );
}

export async function updateSaleStatus(id: string, status: string, conn?: PoolConnection): Promise<void> {
  await execute(`UPDATE sales SET status = ? WHERE id = ?`, [status, id], conn);
}

export async function deleteOldSales(days: number): Promise<number> {
  const res = await execute(
    `DELETE FROM sales WHERE date IS NOT NULL AND STR_TO_DATE(LEFT(date, 10), '%Y-%m-%d') < DATE_SUB(CURDATE(), INTERVAL ? DAY)`,
    [days]
  );
  return res.affectedRows;
}

export async function restoreSales(sales: Sale[]): Promise<number> {
  const existing = new Set((await query<any>(`SELECT id FROM sales`)).map((r) => r.id));
  let added = 0;
  await withTransaction(async (conn) => {
    for (const s of sales) {
      if (!s || !s.id || existing.has(s.id)) continue;
      await insertSale(s, conn);
      existing.add(s.id);
      added++;
    }
  });
  return added;
}

// ------------------------------------------------------------
// PURCHASES
// ------------------------------------------------------------

const PURCHASE_SELECT = `SELECT id, po_no AS poNo, supplier_id AS supplierId, supplier_name AS supplierName, date, items, total_amount AS totalAmount, status, payment_status AS paymentStatus, note FROM purchases`;

export async function getPurchases(): Promise<Purchase[]> {
  const rows = await query<any>(`${PURCHASE_SELECT} ORDER BY date DESC`);
  return numifyAll(rows, ['totalAmount']);
}

export async function insertPurchase(p: Purchase, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO purchases (id, po_no, supplier_id, supplier_name, date, items, total_amount, status, payment_status, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      p.id, p.poNo, p.supplierId || null, p.supplierName || null, p.date || null,
      JSON.stringify(p.items || []), p.totalAmount ?? 0, p.status || 'Received',
      p.paymentStatus || 'Unpaid', p.note || null,
    ],
    conn
  );
}

// ------------------------------------------------------------
// EXPENSES
// ------------------------------------------------------------

const EXPENSE_SELECT = `SELECT id, title, category_id AS categoryId, category_name AS categoryName, amount, date, note, created_by AS createdBy FROM expenses`;



export async function getExpenses(): Promise<Expense[]> {
  const rows = await query<any>(EXPENSE_SELECT);
  return numifyAll(rows, ['amount']);
}

export async function insertExpense(e: Expense, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO expenses (id, title, category_id, category_name, amount, date, note, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [e.id, e.title, e.categoryId || null, e.categoryName || null, e.amount ?? 0, e.date || null, e.note || null, e.createdBy || null],
    conn
  );
}

export async function deleteExpense(id: string): Promise<void> {
  await execute(`DELETE FROM expenses WHERE id = ?`, [id]);
}

// ------------------------------------------------------------
// STOCK ADJUSTMENTS
// ------------------------------------------------------------

const ADJ_SELECT = `SELECT id, date, product_id AS productId, product_name AS productName, type, quantity, reason, adjusted_by AS adjustedBy FROM stock_adjustments`;

const ADJ_COLUMNS: Record<string, string> = {
  date: 'date',
  productId: 'product_id',
  productName: 'product_name',
  type: 'type',
  quantity: 'quantity',
  reason: 'reason',
  adjustedBy: 'adjusted_by',
};

export async function getStockAdjustments(): Promise<StockAdjustment[]> {
  const rows = await query<any>(ADJ_SELECT);
  return numifyAll(rows, ['quantity']);
}

export async function getStockAdjustmentById(id: string): Promise<StockAdjustment | null> {
  const rows = await query<any>(`${ADJ_SELECT} WHERE id = ?`, [id]);
  if (!rows.length) return null;
  return numify(rows[0], ['quantity']);
}

export async function insertStockAdjustment(a: StockAdjustment, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO stock_adjustments (id, date, product_id, product_name, type, quantity, reason, adjusted_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [a.id, a.date || null, a.productId, a.productName || null, a.type || null, a.quantity ?? 0, a.reason || null, a.adjustedBy || 'Admin'],
    conn
  );
}

export async function updateStockAdjustment(id: string, data: Partial<StockAdjustment>, conn?: PoolConnection): Promise<void> {
  const upd = buildUpdate('stock_adjustments', data as Record<string, any>, id, ADJ_COLUMNS);
  if (upd.sql) await execute(upd.sql, upd.params, conn);
}

export async function deleteStockAdjustment(id: string, conn?: PoolConnection): Promise<void> {
  await execute(`DELETE FROM stock_adjustments WHERE id = ?`, [id], conn);
}

// ------------------------------------------------------------
// SALES RETURNS
// ------------------------------------------------------------

const RETURN_SELECT = `SELECT id, return_no AS returnNo, sale_id AS saleId, invoice_no AS invoiceNo, date, customer_name AS customerName, items, total_refund AS totalRefund, reason, refund_method AS refundMethod FROM sales_returns`;

export async function getReturns(): Promise<SaleReturn[]> {
  const rows = await query<any>(`${RETURN_SELECT} ORDER BY date DESC`);
  return numifyAll(rows, ['totalRefund']);
}

export async function insertReturn(r: SaleReturn, conn?: PoolConnection): Promise<void> {
  await execute(
    `INSERT INTO sales_returns (id, return_no, sale_id, invoice_no, date, customer_name, items, total_refund, reason, refund_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      r.id, r.returnNo || null, r.saleId || null, r.invoiceNo || null, r.date || null,
      r.customerName || null, JSON.stringify(r.items || []), r.totalRefund ?? 0,
      r.reason || null, r.refundMethod || 'Cash',
    ],
    conn
  );
}

// ------------------------------------------------------------
// DASHBOARD STATS
// ------------------------------------------------------------

export interface DashboardStatsRow {
  todaySales: number;
  todayOrders: number;
  revenue: number;
  profit: number;
  expenses: number;
  totalProducts: number;
  totalCustomers: number;
  lowStockCount: number;
  salesGrowth: number;
  orderGrowth: number;
}

export async function getDashboardStats(): Promise<DashboardStatsRow> {
  const todayStr = new Date().toISOString().split('T')[0];
  const rows = await query<any>(
    `SELECT
       COALESCE(SUM(CASE WHEN status = 'Completed' AND date LIKE ? THEN total END), 0) AS todaySales,
       COUNT(CASE WHEN status = 'Completed' AND date LIKE ? THEN 1 END) AS todayOrders,
       COALESCE(SUM(CASE WHEN status = 'Completed' THEN total END), 0) AS revenue,
       (SELECT COALESCE(SUM(amount), 0) FROM expenses) AS expenses,
       (SELECT COUNT(*) FROM products) AS totalProducts,
       (SELECT COUNT(*) FROM customers) AS totalCustomers,
       (SELECT COUNT(*) FROM products WHERE stock <= min_stock) AS lowStockCount
     FROM sales`,
    [`${todayStr}%`, `${todayStr}%`]
  );
  const r = rows[0] || {};
  const revenue = Number(r.revenue) || 0;
  const expenses = Number(r.expenses) || 0;
  return {
    todaySales: Number(r.todaySales) || 0,
    todayOrders: Number(r.todayOrders) || 0,
    revenue,
    profit: Math.max(0, revenue * 0.38 - expenses),
    expenses,
    totalProducts: Number(r.totalProducts) || 0,
    totalCustomers: Number(r.totalCustomers) || 0,
    lowStockCount: Number(r.lowStockCount) || 0,
    salesGrowth: 14.5,
    orderGrowth: 8.2,
  };
}

// ------------------------------------------------------------
// BACKUP & RESTORE
// ------------------------------------------------------------

export async function exportBackup(): Promise<any> {
  const [settings, users, categories, products, customers, suppliers, sales, purchases, expenses] =
    await Promise.all([
      getSettings(),
      getUsers(),
      getCategories(),
      getProducts(),
      getCustomers(),
      getSuppliers(),
      getSales(),
      getPurchases(),
      getExpenses(),
    ]);
  return { settings, users, categories, products, customers, suppliers, sales, purchases, expenses };
}

export async function restoreDatabase(data: any): Promise<void> {
  await withTransaction(async (conn) => {
    if (data.settings) {
      await execute(`DELETE FROM settings`, [], conn);
      await execute(
        `INSERT INTO settings (id, company_name, company_tagline, address, phone, email, vat_number, currency, currency_symbol, khr_exchange_rate, tax_rate, receipt_header, receipt_footer, logo_url, enable_sound, enable_ai_assistant, role_permissions) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          data.settings.companyName || '', data.settings.companyTagline || '', data.settings.address || '',
          data.settings.phone || '', data.settings.email || '', data.settings.vatNumber || '',
          data.settings.currency || '', data.settings.currencySymbol || '', data.settings.khrExchangeRate ?? 4100, data.settings.taxRate ?? 10,
          data.settings.receiptHeader || '', data.settings.receiptFooter || '', data.settings.logoUrl || '',
          data.settings.enableSound ? 1 : 0, data.settings.enableAIAssistant ? 1 : 0,
          data.settings.rolePermissions ? JSON.stringify(data.settings.rolePermissions) : null,
        ],
        conn
      );
    }
    if (Array.isArray(data.products)) {
      await execute(`DELETE FROM products`, [], conn);
      for (const p of data.products) await insertProduct(p, conn);
    }
    if (Array.isArray(data.categories)) {
      await execute(`DELETE FROM categories`, [], conn);
      for (const c of data.categories) await insertCategory(c, conn);
    }
    if (Array.isArray(data.customers)) {
      await execute(`DELETE FROM customers`, [], conn);
      for (const c of data.customers) await insertCustomer(c, conn);
    }
    if (Array.isArray(data.suppliers)) {
      await execute(`DELETE FROM suppliers`, [], conn);
      for (const s of data.suppliers) await insertSupplier(s, conn);
    }
    if (Array.isArray(data.sales)) {
      await execute(`DELETE FROM sales`, [], conn);
      for (const s of data.sales) await insertSale(s, conn);
    }
  });
}

// ------------------------------------------------------------
// SEEDING (migrates the mock/demo data into MySQL on first run)
// ------------------------------------------------------------

async function seedIfEmpty(): Promise<boolean> {
  let seeded = false;

  await withTransaction(async (conn) => {
    const countRows = async (table: string): Promise<number> => {
      const rows = await query<any>(`SELECT COUNT(*) AS cnt FROM ${table}`, [], conn);
      return Number(rows[0]?.cnt) || 0;
    };

    if ((await countRows('settings')) === 0) {
      await execute(
        `INSERT INTO settings (id, company_name, company_tagline, address, phone, email, vat_number, currency, currency_symbol, khr_exchange_rate, tax_rate, receipt_header, receipt_footer, logo_url, enable_sound, enable_ai_assistant, role_permissions) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          initialSettings.companyName, initialSettings.companyTagline, initialSettings.address,
          initialSettings.phone, initialSettings.email, initialSettings.vatNumber,
          initialSettings.currency, initialSettings.currencySymbol, initialSettings.khrExchangeRate,
          initialSettings.taxRate,
          initialSettings.receiptHeader, initialSettings.receiptFooter, initialSettings.logoUrl,
          initialSettings.enableSound ? 1 : 0, initialSettings.enableAIAssistant ? 1 : 0,
          JSON.stringify(initialSettings.rolePermissions),
        ],
        conn
      );
      seeded = true;
    }
    if ((await countRows('users')) === 0) {
      for (const u of initialUsers) await insertUser(u, conn);
      seeded = true;
    }
    if ((await countRows('categories')) === 0) {
      for (const c of initialCategories) await insertCategory(c, conn);
      seeded = true;
    }
    if ((await countRows('products')) === 0) {
      for (const p of initialProducts) await insertProduct(p, conn);
      seeded = true;
    }
    if ((await countRows('customers')) === 0) {
      for (const c of initialCustomers) await insertCustomer(c, conn);
      seeded = true;
    }
    if ((await countRows('suppliers')) === 0) {
      for (const s of initialSuppliers) await insertSupplier(s, conn);
      seeded = true;
    }
    if ((await countRows('sales')) === 0) {
      for (const s of initialSales) await insertSale(s, conn);
      seeded = true;
    }
    if ((await countRows('purchases')) === 0) {
      for (const p of initialPurchases) await insertPurchase(p, conn);
      seeded = true;
    }
    if ((await countRows('expenses')) === 0) {
      for (const e of initialExpenses) await insertExpense(e, conn);
      seeded = true;
    }
    if ((await countRows('stock_adjustments')) === 0) {
      for (const a of initialStockAdjustments) await insertStockAdjustment(a, conn);
      seeded = true;
    }

    await execute(`INSERT INTO telegram_config (id) VALUES (1) ON DUPLICATE KEY UPDATE id = id`, [], conn);
  });

  return seeded;
}

// ------------------------------------------------------------
// MYSQL CONFIG PERSISTENCE
// ------------------------------------------------------------

export interface SavedMysqlConfig {
  host: string;
  port: number;
  user: string;
  database: string;
  ssl: boolean;
  autoSync: boolean;
}

export async function loadSavedMysqlConfig(): Promise<SavedMysqlConfig | null> {
  try {
    const rows = await query<any>(
      `SELECT host, port, user, database_name AS databaseName, use_ssl AS ssl, auto_sync AS autoSync FROM mysql_config WHERE id = 1`
    );
    if (!rows.length) return null;
    const r = rows[0];
    return {
      host: r.host || '127.0.0.1',
      port: Number(r.port) || 3306,
      user: r.user || 'root',
      database: r.databaseName || 'smartpos_db',
      ssl: !!r.ssl,
      autoSync: !!r.autoSync,
    };
  } catch {
    return null;
  }
}

export async function saveMysqlConfig(cfg: SavedMysqlConfig): Promise<void> {
  await execute(`INSERT INTO mysql_config (id) VALUES (1) ON DUPLICATE KEY UPDATE id = id`);
  await execute(
    `UPDATE mysql_config SET host = ?, port = ?, user = ?, database_name = ?, use_ssl = ?, auto_sync = ? WHERE id = 1`,
    [cfg.host, cfg.port, cfg.user, cfg.database, cfg.ssl ? 1 : 0, cfg.autoSync ? 1 : 0]
  );
}
