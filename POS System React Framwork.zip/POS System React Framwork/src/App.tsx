import React, { useState } from 'react';
import { POSProvider, usePOS } from './context/POSContext';
import { LoginScreen } from './components/auth/LoginScreen';
import { Sidebar } from './components/layout/Sidebar';
import { Navbar } from './components/layout/Navbar';

import { POSScreen } from './components/pos/POSScreen';
import { DashboardScreen } from './components/dashboard/DashboardScreen';
import { ProductsScreen } from './components/products/ProductsScreen';
import { CategoriesScreen } from './components/categories/CategoriesScreen';
import { InventoryScreen } from './components/inventory/InventoryScreen';
import { PurchasesScreen } from './components/purchases/PurchasesScreen';
import { SuppliersScreen } from './components/suppliers/SuppliersScreen';
import { CustomersScreen } from './components/customers/CustomersScreen';
import { SalesScreen } from './components/sales/SalesScreen';
import { ReturnsScreen } from './components/returns/ReturnsScreen';
import { ExpensesScreen } from './components/expenses/ExpensesScreen';
import { ReportsScreen } from './components/reports/ReportsScreen';
import { UsersScreen } from './components/users/UsersScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';
import { DevDocsModal } from './components/docs/DevDocsModal';

const AppContent: React.FC = () => {
  const { currentUser, activeTab } = usePOS();
  const [showDevDocs, setShowDevDocs] = useState(false);

  if (!currentUser) {
    return <LoginScreen />;
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'pos':
        return <POSScreen />;
      case 'dashboard':
        return <DashboardScreen />;
      case 'products':
        return <ProductsScreen />;
      case 'categories':
        return <CategoriesScreen />;
      case 'inventory':
        return <InventoryScreen />;
      case 'purchases':
        return <PurchasesScreen />;
      case 'suppliers':
        return <SuppliersScreen />;
      case 'customers':
        return <CustomersScreen />;
      case 'sales':
        return <SalesScreen />;
      case 'returns':
        return <ReturnsScreen />;
      case 'expenses':
        return <ExpensesScreen />;
      case 'reports':
        return <ReportsScreen />;
      case 'users':
        return <UsersScreen />;
      case 'settings':
        return <SettingsScreen />;
      default:
        return <POSScreen />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-slate-900 overflow-hidden font-poppins">
      <Sidebar />

      <div className="flex-1 flex flex-col min-w-0 h-full overflow-y-auto">
        <Navbar onOpenDevDocs={() => setShowDevDocs(true)} />
        <main className="flex-1 overflow-y-auto">{renderTabContent()}</main>
      </div>

      <DevDocsModal isOpen={showDevDocs} onClose={() => setShowDevDocs(false)} />
    </div>
  );
};

export default function App() {
  return (
    <POSProvider>
      <AppContent />
    </POSProvider>
  );
}
