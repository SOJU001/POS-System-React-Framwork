export type UserRole = 'Admin' | 'Manager' | 'Cashier';

/** Configures which tabs each role can see in the sidebar navigation. */
export interface RolePermissions {
  /** Which tabs (sidebar ids) each role is allowed to see */
  navTabs: {
    Manager: string[];
    Cashier: string[];
  };
  /** Whether each role can delete records on each screen */
  canDelete: {
    Manager: boolean;
    Cashier: boolean;
  };
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  username?: string;
  password?: string;
  pin?: string;
  avatar?: string;
  phone?: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
  twoFactorEnabled?: boolean;
  twoFactorSecret?: string;
  googleLinked?: boolean;
}

/** Response from password login or Google login. Either a completed session or a 2FA challenge. */
export type LoginResult =
  | { token: string; user: User; message: string }
  | { requires2FA: true; pendingToken: string; email: string; name: string };

export interface TwoFactorSetup {
  secret: string;
  otpauthUrl: string;
  qrCodeUrl: string;
}

export interface Category {
  id: string;
  name: string;
  code: string;
  icon?: string;
  itemCount?: number;
  description?: string;
}

export interface Brand {
  id: string;
  name: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  qrCode?: string;
  categoryId: string;
  categoryName?: string;
  brand?: string;
  purchasePrice: number;
  sellingPrice: number;
  margin: number; // percentage
  stock: number;
  minStock: number;
  unit: string;
  image: string;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  description?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'VIP';
  totalSpent: number;
  lastPurchaseDate?: string;
}

export interface Supplier {
  id: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  taxNumber?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  discount: number; // percentage or fixed amount
  note?: string;
}

export type PaymentMethodType = 'Cash' | 'ABA Pay' | 'Bank Transfer' | 'Credit Card' | 'Split';

export interface PaymentDetails {
  method: PaymentMethodType;
  currency?: 'USD' | 'KHR';
  amountPaid: number;
  change: number;
  referenceNumber?: string;
  splitDetails?: { method: PaymentMethodType; amount: number }[];
}

export interface Sale {
  id: string;
  invoiceNo: string;
  date: string;
  customerId?: string;
  customerName: string;
  cashierId: string;
  cashierName: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  tax: number;
  taxAmount: number;
  total: number;
  paymentMethod: PaymentMethodType;
  paymentDetails: PaymentDetails;
  status: 'Completed' | 'Refunded' | 'Partially Refunded' | 'Suspended';
  note?: string;
}

export interface SuspendedSale {
  id: string;
  reference: string;
  date: string;
  items: CartItem[];
  customer?: Customer;
  note?: string;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
}

export interface Purchase {
  id: string;
  poNo: string;
  supplierId: string;
  supplierName: string;
  date: string;
  items: PurchaseItem[];
  totalAmount: number;
  status: 'Received' | 'Pending' | 'Cancelled';
  paymentStatus: 'Paid' | 'Unpaid' | 'Partial';
  note?: string;
}

export interface StockAdjustment {
  id: string;
  date: string;
  productId: string;
  productName: string;
  type: 'Damaged' | 'Transfer' | 'Correction' | 'Restock';
  quantity: number; // positive or negative
  reason: string;
  adjustedBy: string;
}

export interface ExpenseCategory {
  id: string;
  name: string;
}

export interface Expense {
  id: string;
  title: string;
  categoryId: string;
  categoryName: string;
  amount: number;
  date: string;
  note?: string;
  createdBy: string;
}

export interface SaleReturn {
  id: string;
  returnNo: string;
  saleId: string;
  invoiceNo: string;
  date: string;
  customerName: string;
  items: { productName: string; quantity: number; refundAmount: number }[];
  totalRefund: number;
  reason: string;
  refundMethod: PaymentMethodType;
}

export interface Settings {
  companyName: string;
  companyTagline: string;
  address: string;
  phone: string;
  email: string;
  vatNumber: string;
  currency: string;
  currencySymbol: string;
  khrExchangeRate: number;
  taxRate: number;
  receiptHeader: string;
  receiptFooter: string;
  logoUrl: string;
  enableSound: boolean;
  enableAIAssistant: boolean;
  rolePermissions?: RolePermissions;
}

export interface DashboardStats {
  todaySales: number;
  todayOrders: number;
  revenue: number;
  profit: number;
  expenses: number;
  totalProducts: number;
  totalCustomers: number;
  lowStockCount: number;
  salesGrowth: number;
  orderGrowth: number;
}
