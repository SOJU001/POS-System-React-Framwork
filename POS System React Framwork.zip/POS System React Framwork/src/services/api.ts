import {
  Product,
  Category,
  Customer,
  Supplier,
  Sale,
  Purchase,
  Expense,
  Settings,
  User,
  LoginResult,
  TwoFactorSetup,
  DashboardStats,
  StockAdjustment,
  SaleReturn,
} from '../types';

const API_BASE = '/api';

/** Attaches the stored session token (Bearer) to requests, when present. */
function authHeaders(): Record<string, string> {
  try {
    const token = localStorage.getItem('smartpos_token');
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}

async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders(),
      ...options?.headers,
    },
    ...options,
  });
  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}));
    throw new Error(errorBody.error || `HTTP error ${res.status}`);
  }
  return res.json();
}

async function uploadFile<T>(url: string, file: File): Promise<T> {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${API_BASE}${url}`, {
    method: 'POST',
    body: file,
    headers: {
      'Content-Type': file.type || 'image/png',
    },
  });
  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}));
    throw new Error(errorBody.error || `HTTP error ${res.status}`);
  }
  return res.json();
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    fetchJSON<LoginResult>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  googleLogin: (googleToken: string) =>
    fetchJSON<LoginResult>('/auth/google', {
      method: 'POST',
      body: JSON.stringify({ token: googleToken }),
    }),

  logout: () => fetchJSON<{ success: boolean }>('/auth/logout', { method: 'POST' }),

  // Two-Factor Authentication (TOTP)
  setup2FA: (userId: string, password: string) =>
    fetchJSON<TwoFactorSetup>('/auth/2fa/setup', {
      method: 'POST',
      body: JSON.stringify({ userId, password }),
    }),
  enable2FA: (userId: string, password: string, token: string) =>
    fetchJSON<{ success: boolean; message: string }>('/auth/2fa/enable', {
      method: 'POST',
      body: JSON.stringify({ userId, password, token }),
    }),
  disable2FA: (userId: string, token: string) =>
    fetchJSON<{ success: boolean; message: string }>('/auth/2fa/disable', {
      method: 'POST',
      body: JSON.stringify({ userId, token }),
    }),
  verifyLogin2FA: (pendingToken: string, token: string) =>
    fetchJSON<{ token: string; user: User; message: string }>('/auth/2fa/verify-login', {
      method: 'POST',
      body: JSON.stringify({ pendingToken, token }),
    }),

  // Dashboard
  getDashboardStats: () => fetchJSON<DashboardStats>('/dashboard/stats'),

  // Products
  getProducts: () => fetchJSON<Product[]>('/products'),
  createProduct: (data: Partial<Product>) =>
    fetchJSON<Product>('/products', { method: 'POST', body: JSON.stringify(data) }),
  updateProduct: (id: string, data: Partial<Product>) =>
    fetchJSON<Product>(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteProduct: (id: string) => fetchJSON<{ success: boolean }>(`/products/${id}`, { method: 'DELETE' }),

  // Categories
  getCategories: () => fetchJSON<Category[]>('/categories'),
  createCategory: (data: Partial<Category>) =>
    fetchJSON<Category>('/categories', { method: 'POST', body: JSON.stringify(data) }),
  updateCategory: (id: string, data: Partial<Category>) =>
    fetchJSON<Category>(`/categories/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteCategory: (id: string) => fetchJSON<{ success: boolean }>(`/categories/${id}`, { method: 'DELETE' }),

  // Customers
  getCustomers: () => fetchJSON<Customer[]>('/customers'),
  createCustomer: (data: Partial<Customer>) =>
    fetchJSON<Customer>('/customers', { method: 'POST', body: JSON.stringify(data) }),
  updateCustomer: (id: string, data: Partial<Customer>) =>
    fetchJSON<Customer>(`/customers/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteCustomer: (id: string) => fetchJSON<{ success: boolean }>(`/customers/${id}`, { method: 'DELETE' }),

  // Suppliers
  getSuppliers: () => fetchJSON<Supplier[]>('/suppliers'),
  createSupplier: (data: Partial<Supplier>) =>
    fetchJSON<Supplier>('/suppliers', { method: 'POST', body: JSON.stringify(data) }),
  updateSupplier: (id: string, data: Partial<Supplier>) =>
    fetchJSON<Supplier>(`/suppliers/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSupplier: (id: string) => fetchJSON<{ success: boolean }>(`/suppliers/${id}`, { method: 'DELETE' }),

  // Sales & POS Checkout
  getSales: () => fetchJSON<Sale[]>('/sales'),
  createSale: (saleData: Partial<Sale>) =>
    fetchJSON<Sale>('/sales', { method: 'POST', body: JSON.stringify(saleData) }),
  refundSale: (id: string, reason: string, refundMethod: string) =>
    fetchJSON<{ success: boolean; sale: Sale; returnRecord: SaleReturn }>(`/sales/${id}/refund`, {
      method: 'POST',
      body: JSON.stringify({ reason, refundMethod }),
    }),
  cleanupWeeklySales: () =>
    fetchJSON<{ success: boolean; deletedCount: number; message: string }>('/sales/cleanup-weekly', {
      method: 'DELETE',
    }),
  backupSales: () => fetchJSON<{ sales: Sale[]; timestamp: string; totalCount: number }>('/sales/backup'),
  restoreSales: (sales: Sale[]) =>
    fetchJSON<{ success: boolean; count: number; message: string }>('/sales/restore', {
      method: 'POST',
      body: JSON.stringify({ sales }),
    }),

  // Purchases
  getPurchases: () => fetchJSON<Purchase[]>('/purchases'),
  createPurchase: (data: Partial<Purchase>) =>
    fetchJSON<Purchase>('/purchases', { method: 'POST', body: JSON.stringify(data) }),

  // Inventory Adjustments
  getStockAdjustments: () => fetchJSON<StockAdjustment[]>('/inventory/adjustments'),
  createStockAdjustment: (data: Partial<StockAdjustment>) =>
    fetchJSON<StockAdjustment>('/inventory/adjustments', { method: 'POST', body: JSON.stringify(data) }),
  updateStockAdjustment: (id: string, data: Partial<StockAdjustment>) =>
    fetchJSON<StockAdjustment>(`/inventory/adjustments/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteStockAdjustment: (id: string) =>
    fetchJSON<{ success: boolean; message: string }>(`/inventory/adjustments/${id}`, { method: 'DELETE' }),

  // Expenses
  getExpenses: () => fetchJSON<Expense[]>('/expenses'),
  createExpense: (data: Partial<Expense>) =>
    fetchJSON<Expense>('/expenses', { method: 'POST', body: JSON.stringify(data) }),
  deleteExpense: (id: string) => fetchJSON<{ success: boolean }>(`/expenses/${id}`, { method: 'DELETE' }),

  // Returns
  getReturns: () => fetchJSON<SaleReturn[]>('/returns'),

  // Users
  getUsers: () => fetchJSON<User[]>('/users'),
  createUser: (data: Partial<User>) => fetchJSON<User>('/users', { method: 'POST', body: JSON.stringify(data) }),
  updateUser: (id: string, data: Partial<User>) =>
    fetchJSON<User>(`/users/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteUser: (id: string) => fetchJSON<{ success: boolean }>(`/users/${id}`, { method: 'DELETE' }),

  // Settings
  getSettings: () => fetchJSON<Settings>('/settings'),
  updateSettings: (data: Partial<Settings>) =>
    fetchJSON<Settings>('/settings', { method: 'PUT', body: JSON.stringify(data) }),
  uploadLogo: (file: File) =>
    uploadFile<{ success: boolean; logoUrl: string; message: string }>('/settings/upload-logo', file),
  removeLogo: () =>
    fetchJSON<{ success: boolean; message: string }>('/settings/remove-logo', { method: 'POST' }),
  exportBackup: () => fetchJSON<any>('/settings/backup'),
  restoreBackup: (backupData: any) =>
    fetchJSON<{ success: boolean; message: string }>('/settings/restore', {
      method: 'POST',
      body: JSON.stringify(backupData),
    }),

  // AI Assistant
  getAIInsights: (promptType: string, productContext?: any) =>
    fetchJSON<{ insight: string }>('/ai/insights', {
      method: 'POST',
      body: JSON.stringify({ promptType, productContext }),
    }),

  // Telegram Alarm API
  getTelegramConfig: () =>
    fetchJSON<{
      botToken: string;
      chatId: string;
      enableLowStockAlerts: boolean;
      enableSalesAlerts: boolean;
      lastAlertSentAt: string | null;
    }>('/telegram/config'),

  updateTelegramConfig: (data: any) =>
    fetchJSON<{ success: boolean; config: any; message: string }>('/telegram/config', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  testTelegramAlarm: (botToken?: string, chatId?: string) =>
    fetchJSON<{ success: boolean; message?: string; reason?: string }>('/telegram/test', {
      method: 'POST',
      body: JSON.stringify({ botToken, chatId }),
    }),

  // MySQL Database API
  getMysqlConfig: () =>
    fetchJSON<{
      host: string;
      port: number;
      user: string;
      database: string;
      ssl: boolean;
      autoSync: boolean;
      status: string;
      lastSyncedAt: string;
    }>('/mysql/config'),

  updateMysqlConfig: (data: any) =>
    fetchJSON<{ success: boolean; config: any; message: string }>('/mysql/config', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  testMysqlConnection: (config?: any) =>
    fetchJSON<{ success: boolean; message: string; details?: any }>('/mysql/test', {
      method: 'POST',
      body: JSON.stringify(config || {}),
    }),

  syncMysqlDatabase: () =>
    fetchJSON<{ success: boolean; message: string; syncedTables: string[]; timestamp: string }>('/mysql/sync', {
      method: 'POST',
    }),
};

