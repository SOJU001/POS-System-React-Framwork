import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Settings,
  Product,
  Category,
  Customer,
  Supplier,
  Sale,
  CartItem,
  SuspendedSale,
  Purchase,
  Expense,
  DashboardStats,
  RolePermissions,
} from '../types';
import { api } from '../services/api';

interface POSContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  login: (user: User, token?: string) => void;
  logout: () => void;
  settings: Settings | null;
  setSettings: React.Dispatch<React.SetStateAction<Settings | null>>;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  language: string;
  setLanguage: (lang: string) => void;

  // Cart State
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  updateItemDiscount: (productId: string, discount: number) => void;
  clearCart: () => void;
  selectedCustomer: Customer | null;
  setSelectedCustomer: (customer: Customer | null) => void;
  orderDiscount: number;
  setOrderDiscount: (discount: number) => void;
  couponCode: string;
  setCouponCode: (code: string) => void;

  // Suspended Sales
  suspendedSales: SuspendedSale[];
  suspendCurrentSale: (note?: string) => void;
  resumeSuspendedSale: (suspendedId: string) => void;
  deleteSuspendedSale: (suspendedId: string) => void;

  // Real-time Collections Data
  products: Product[];
  categories: Category[];
  customers: Customer[];
  suppliers: Supplier[];
  sales: Sale[];
  purchases: Purchase[];
  expenses: Expense[];
  users: User[];
  stats: DashboardStats | null;
  loading: boolean;
  refreshData: () => Promise<void>;

  // Sound settings
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;

  // Quick sound effect helper
  playSound: (type: 'beep' | 'success' | 'delete') => void;

  // Dev Docs Modal
  showDevDocs: boolean;
  setShowDevDocs: (val: boolean) => void;

  // Role-based permissions
  rolePermissions: RolePermissions | null;
}

const POSContext = createContext<POSContextType | undefined>(undefined);

export const POSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Restore the authenticated session from localStorage (null = show the login screen)
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const raw = localStorage.getItem('smartpos_user');
      return raw ? (JSON.parse(raw) as User) : null;
    } catch {
      return null;
    }
  });

  const [settings, setSettings] = useState<Settings | null>(null);
  const [activeTab, setActiveTab] = useState<string>('pos'); // Default to POS screen for instant action
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [language, setLanguage] = useState<string>('EN');
  const [showDevDocs, setShowDevDocs] = useState<boolean>(false);

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [orderDiscount, setOrderDiscount] = useState<number>(0);
  const [couponCode, setCouponCode] = useState<string>('');
  const [suspendedSales, setSuspendedSales] = useState<SuspendedSale[]>([]);

  // Collections
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Sound effects
  const soundEnabled = settings?.enableSound ?? true;
  const setSoundEnabled = (val: boolean) => {
    setSettings((prev) => (prev ? { ...prev, enableSound: val } : prev));
  };

  const playSound = (type: 'beep' | 'success' | 'delete') => {
    if (settings && !settings.enableSound) return;
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'beep') {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.08);
      } else if (type === 'success') {
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      } else if (type === 'delete') {
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
      }
    } catch (e) {
      // AudioContext fallback
    }
  };

  const login = (user: User, token?: string) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('smartpos_user', JSON.stringify(user));
      if (token) localStorage.setItem('smartpos_token', token);
    } catch {
      // storage may be unavailable (private mode)
    }
  };

  const logout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem('smartpos_user');
      localStorage.removeItem('smartpos_token');
    } catch {
      // ignore
    }
    // Invalidate the session server-side (best effort)
    api.logout().catch(() => {});
  };

  const refreshData = async () => {
    try {
      setLoading(true);
      const [prods, cats, custs, supps, sls, purs, exps, st, setts, usrs] = await Promise.all([
        api.getProducts().catch(() => []),
        api.getCategories().catch(() => []),
        api.getCustomers().catch(() => []),
        api.getSuppliers().catch(() => []),
        api.getSales().catch(() => []),
        api.getPurchases().catch(() => []),
        api.getExpenses().catch(() => []),
        api.getDashboardStats().catch(() => null),
        api.getSettings().catch(() => null),
        api.getUsers().catch(() => []),
      ]);

      setProducts(Array.isArray(prods) ? prods : []);
      setCategories(Array.isArray(cats) ? cats : []);
      setCustomers(Array.isArray(custs) ? custs : []);
      setSuppliers(Array.isArray(supps) ? supps : []);
      setSales(Array.isArray(sls) ? sls : []);
      setPurchases(Array.isArray(purs) ? purs : []);
      setExpenses(Array.isArray(exps) ? exps : []);
      setUsers(Array.isArray(usrs) ? usrs : []);
      setStats(st);
      setSettings(setts);

      if (!selectedCustomer && Array.isArray(custs) && custs.length > 0) {
        setSelectedCustomer(custs[0]); // Default to Walk-in customer
      }
    } catch (err) {
      console.error('Failed to load POS data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    if (product.stock <= 0) return;
    playSound('beep');

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const newQty = existing.quantity + quantity;
        if (newQty > product.stock) return prev;
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: newQty } : item
        );
      }
      return [...prev, { product, quantity, discount: 0 }];
    });
  };

  const removeFromCart = (productId: string) => {
    playSound('delete');
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    const prod = products.find((p) => p.id === productId);
    if (prod && quantity > prod.stock) return;

    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const updateItemDiscount = (productId: string, discount: number) => {
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, discount } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
    setOrderDiscount(0);
    setCouponCode('');
  };

  // Suspend / Resume Sale
  const suspendCurrentSale = (note?: string) => {
    if (cart.length === 0) return;
    const suspended: SuspendedSale = {
      id: `susp-${Date.now()}`,
      reference: `HOLD-${Math.floor(100 + Math.random() * 900)}`,
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      items: [...cart],
      customer: selectedCustomer || undefined,
      note,
    };

    setSuspendedSales((prev) => [suspended, ...prev]);
    clearCart();
    playSound('beep');
  };

  const resumeSuspendedSale = (suspendedId: string) => {
    const item = suspendedSales.find((s) => s.id === suspendedId);
    if (item) {
      setCart(item.items);
      if (item.customer) setSelectedCustomer(item.customer);
      setSuspendedSales((prev) => prev.filter((s) => s.id !== suspendedId));
      playSound('beep');
    }
  };

  const deleteSuspendedSale = (suspendedId: string) => {
    setSuspendedSales((prev) => prev.filter((s) => s.id !== suspendedId));
    playSound('delete');
  };

  const rolePermissions = settings?.rolePermissions ?? null;

  return (
    <POSContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        login,
        logout,
        settings,
        setSettings,
        activeTab,
        setActiveTab,
        darkMode,
        setDarkMode,
        language,
        setLanguage,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        updateItemDiscount,
        clearCart,
        selectedCustomer,
        setSelectedCustomer,
        orderDiscount,
        setOrderDiscount,
        couponCode,
        setCouponCode,
        suspendedSales,
        suspendCurrentSale,
        resumeSuspendedSale,
        deleteSuspendedSale,
        products,
        categories,
        customers,
        suppliers,
        sales,
        purchases,
        expenses,
        users,
        setUsers,
        soundEnabled,
        setSoundEnabled,
        stats,
        loading,
        refreshData,
        playSound,
        showDevDocs,
        setShowDevDocs,
        rolePermissions,
      }}
    >
      <div className={darkMode ? 'dark bg-slate-900 text-slate-100 min-h-screen' : 'min-h-screen'}>
        {children}
      </div>
    </POSContext.Provider>
  );
};

export const usePOS = () => {
  const context = useContext(POSContext);
  if (!context) {
    throw new Error('usePOS must be used within a POSProvider');
  }
  return context;
};