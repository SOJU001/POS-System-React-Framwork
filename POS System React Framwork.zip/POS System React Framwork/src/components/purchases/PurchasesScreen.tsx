import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import { Truck, Plus, Search, FileText, CheckCircle2, X } from 'lucide-react';
import Swal from 'sweetalert2';

export const PurchasesScreen: React.FC = () => {
  const { purchases, suppliers, products, refreshData, playSound } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);

  const [supplierId, setSupplierId] = useState((suppliers || [])[0]?.id || '');
  const [selectedProductId, setSelectedProductId] = useState((products || [])[0]?.id || '');
  const [quantity, setQuantity] = useState(10);
  const [unitCost, setUnitCost] = useState((products || [])[0]?.purchasePrice || 10);

  const filtered = (purchases || []).filter(
    (p) =>
      (p.poNo && p.poNo.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.supplierName && p.supplierName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleCreatePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    const supp = suppliers.find((s) => s.id === supplierId);
    const prod = products.find((p) => p.id === selectedProductId);

    if (!supp || !prod) return;

    try {
      const payload = {
        supplierId: supp.id,
        supplierName: supp.companyName,
        items: [
          {
            productId: prod.id,
            productName: prod.name,
            quantity: Number(quantity),
            unitCost: Number(unitCost),
            totalCost: Number(quantity) * Number(unitCost),
          },
        ],
        totalAmount: Number(quantity) * Number(unitCost),
        status: 'Received' as const,
        paymentStatus: 'Paid' as const,
      };

      await api.createPurchase(payload);
      playSound('success');
      setShowModal(false);
      await refreshData();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Purchase Order Created & Stock Received!',
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Truck className="w-6 h-6 text-[#3271a8]" />
            <span>Purchase Orders (PO) & Receiving</span>
          </h1>
          <p className="text-xs text-slate-400">Order inventory from suppliers and auto-update stock levels</p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Purchase Order</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search PO number or supplier name..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                <th className="p-4">PO Number</th>
                <th className="p-4">Supplier</th>
                <th className="p-4">Date</th>
                <th className="p-4 text-center">Items Purchased</th>
                <th className="p-4 text-right">Total Cost</th>
                <th className="p-4 text-center">Stock Status</th>
                <th className="p-4 text-center">Payment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                  <td className="p-4 font-bold text-[#3271a8]">{p.poNo}</td>
                  <td className="p-4 font-semibold text-slate-800 dark:text-slate-200">{p.supplierName}</td>
                  <td className="p-4 text-slate-500">{p.date}</td>
                  <td className="p-4 text-center">
                    {p.items.map((i, idx) => (
                      <span key={idx} className="block text-slate-600 dark:text-slate-300 font-medium">
                        {i.productName} ({i.quantity} pcs)
                      </span>
                    ))}
                  </td>
                  <td className="p-4 text-right font-extrabold text-slate-900 dark:text-slate-100">
                    ${p.totalAmount.toFixed(2)}
                  </td>
                  <td className="p-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600">
                      {p.status}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600">
                      {p.paymentStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4">
              Create Purchase Order & Receive Stock
            </h2>

            <form onSubmit={handleCreatePurchase} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Select Supplier</label>
                <select
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.companyName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Product to Order</label>
                <select
                  value={selectedProductId}
                  onChange={(e) => {
                    setSelectedProductId(e.target.value);
                    const p = products.find((prod) => prod.id === e.target.value);
                    if (p) setUnitCost(p.purchasePrice);
                  }}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Quantity</label>
                  <input
                    type="number"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Unit Cost ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={unitCost}
                    onChange={(e) => setUnitCost(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 flex justify-between font-bold">
                <span>Total PO Amount:</span>
                <span className="text-[#3271a8]">${(quantity * unitCost).toFixed(2)}</span>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#3271a8] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25"
              >
                Create PO & Receive Goods
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
