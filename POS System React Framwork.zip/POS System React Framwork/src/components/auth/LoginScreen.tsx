import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import { GoogleOAuthProvider, GoogleLogin } from '@react-oauth/google';
import type { CredentialResponse } from '@react-oauth/google';
import { Lock, Mail, ArrowRight, ShieldCheck, ArrowLeft, KeyRound } from 'lucide-react';
import Swal from 'sweetalert2';
import { BrandLogo } from '../common/BrandLogo';
import { LoginResult } from '../../types';

const GOOGLE_CLIENT_ID: string = ((import.meta as any).env?.VITE_GOOGLE_CLIENT_ID as string) || '';

/** Default passwords assigned to the seeded demo accounts (hashed in the DB). */
const DEMO_CREDENTIALS: Record<string, { email: string; password: string }> = {
  Admin: { email: 'admin@smartpos.com', password: 'Admin@123' },
  Manager: { email: 'manager@smartpos.com', password: 'Manager@123' },
  Cashier: { email: 'cashier@smartpos.com', password: 'Cashier@123' },
};

export const LoginScreen: React.FC = () => {
  const { login, settings } = usePOS();
  const [email, setEmail] = useState('admin@smartpos.com');
  const [password, setPassword] = useState('Admin@123');
  const [loading, setLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // TOTP 2FA verification step (shown when the account has two-factor enabled)
  const [twoFactorChallenge, setTwoFactorChallenge] = useState<{
    pendingToken: string;
    email: string;
    name: string;
  } | null>(null);
  const [otpCode, setOtpCode] = useState('');
  const [otpLoading, setOtpLoading] = useState(false);

  const completeSession = (res: LoginResult) => {
    if ('requires2FA' in res) {
      setTwoFactorChallenge({ pendingToken: res.pendingToken, email: res.email, name: res.name });
      setOtpCode('');
      return;
    }
    login(res.user, res.token);
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'success',
      title: `Welcome back, ${res.user.name}!`,
      showConfirmButton: false,
      timer: 2000,
    });
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      completeSession(await api.login(email, password));
    } catch (err: any) {
      Swal.fire({
        icon: 'error',
        title: 'Authentication Failed',
        text: err.message || 'Invalid credentials. Please check your email and password.',
        confirmButtonColor: '#3271a8',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!twoFactorChallenge) return;
    setOtpLoading(true);
    try {
      const res = await api.verifyLogin2FA(twoFactorChallenge.pendingToken, otpCode);
      login(res.user, res.token);
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: `Welcome back, ${res.user.name}!`,
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({
        icon: 'error',
        title: 'Verification Failed',
        text: err.message || 'Invalid code. Please try again.',
        confirmButtonColor: '#3271a8',
      });
    } finally {
      setOtpLoading(false);
    }
  };

  const handleGoogleSuccess = async (credentialResponse: CredentialResponse) => {
    const credential = credentialResponse?.credential;
    if (!credential) return;
    try {
      completeSession(await api.googleLogin(credential));
    } catch (err: any) {
      Swal.fire({
        icon: 'error',
        title: 'Google Sign-In Failed',
        text: err.message || 'Unable to sign in with Google.',
        confirmButtonColor: '#3271a8',
      });
    }
  };

  const handleQuickDemo = (demoRole: 'Admin' | 'Manager' | 'Cashier') => {
    const creds = DEMO_CREDENTIALS[demoRole];
    setEmail(creds.email);
    setPassword(creds.password);
    setTwoFactorChallenge(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-[#1e3a8a] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative Blur Background Blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#3271a8]/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#7732a8]/30 rounded-full blur-3xl pointer-events-none" />

      {/* Glassmorphism Login Card */}
      <div className="w-full max-w-md bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-2xl relative z-10 text-white">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex mb-3">
            <BrandLogo className="w-16 h-16 rounded-2xl shadow-lg shadow-[#3271a8]/40" iconClassName="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">SmartPOS Enterprise</h1>
          <p className="text-xs text-slate-300 mt-1">
            {settings?.companyTagline || 'Modern Retail Point of Sale System'}
          </p>
        </div>

        {/* TOTP Two-Factor Verification Step */}
        {twoFactorChallenge ? (
          <form onSubmit={handleVerify2FA} className="space-y-4">
            <div className="text-center mb-2">
              <div className="inline-flex p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 mb-3">
                <ShieldCheck className="w-7 h-7 text-emerald-400" />
              </div>
              <h2 className="text-lg font-bold">Two-Factor Authentication</h2>
              <p className="text-xs text-slate-300 mt-1">
                Enter the 6-digit code from your authenticator app
                <span className="block text-slate-400 mt-0.5">{twoFactorChallenge.email}</span>
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-200 mb-1.5">Verification Code</label>
              <div className="relative">
                <KeyRound className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={6}
                  required
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••••"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900/50 border border-white/15 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 tracking-[0.5em] text-center font-mono text-lg transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={otpLoading || otpCode.length !== 6}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 font-semibold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all mt-2 cursor-pointer disabled:opacity-50"
            >
              {otpLoading ? (
                <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify & Sign In</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setTwoFactorChallenge(null)}
              className="w-full py-2 rounded-xl text-xs text-slate-300 hover:text-white flex items-center justify-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to sign in</span>
            </button>
          </form>
        ) : (
          <>
            {/* Form */}
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@company.com"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/50 border border-white/15 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#3271a8] transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1.5">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/50 border border-white/15 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#3271a8] transition-all"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-slate-600 bg-slate-800 text-[#3271a8] focus:ring-0 cursor-pointer"
                  />
                  <span>Remember me</span>
                </label>
                <button
                  type="button"
                  onClick={() =>
                    Swal.fire({
                      title: 'Reset Password',
                      text: 'Enter your admin email to receive reset instructions.',
                      input: 'email',
                      inputPlaceholder: 'admin@smartpos.com',
                      confirmButtonColor: '#3271a8',
                    })
                  }
                  className="text-[#60a5fa] hover:underline font-medium"
                >
                  Forgot password?
                </button>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#3271a8] to-[#7732a8] hover:opacity-90 font-semibold text-sm shadow-lg shadow-[#3271a8]/30 flex items-center justify-center gap-2 transition-all mt-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Sign In to Terminal</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Google Sign-In (only when VITE_GOOGLE_CLIENT_ID is configured) */}
            {GOOGLE_CLIENT_ID ? (
              <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
                <div className="mt-4">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex-1 h-px bg-white/15" />
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      or continue with
                    </span>
                    <div className="flex-1 h-px bg-white/15" />
                  </div>
                  <div className="flex justify-center">
                    <GoogleLogin
                      onSuccess={handleGoogleSuccess}
                      onError={() =>
                        Swal.fire({
                          icon: 'error',
                          title: 'Google Sign-In Failed',
                          text: 'Google authentication was cancelled or failed. Please try again.',
                          confirmButtonColor: '#3271a8',
                        })
                      }
                      shape="pill"
                      text="continue_with"
                      theme="filled_blue"
                    />
                  </div>
                </div>
              </GoogleOAuthProvider>
            ) : (
              <p className="text-[10px] text-slate-500 mt-4 text-center">
                Google sign-in will appear after adding{' '}
                <code className="text-slate-400">VITE_GOOGLE_CLIENT_ID</code> to your .env file
              </p>
            )}

            {/* Quick Demo Roles Selection */}
            <div className="mt-6 pt-6 border-t border-white/10">
              <p className="text-[11px] font-semibold text-slate-400 text-center uppercase tracking-wider mb-3">
                Quick One-Click Demo Access
              </p>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleQuickDemo('Admin')}
                  className="py-2 px-1 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] font-semibold text-slate-200 border border-white/10 transition-colors"
                >
                  👑 Admin
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('Manager')}
                  className="py-2 px-1 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] font-semibold text-slate-200 border border-white/10 transition-colors"
                >
                  👔 Manager
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('Cashier')}
                  className="py-2 px-1 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] font-semibold text-slate-200 border border-white/10 transition-colors"
                >
                  🛒 Cashier
                </button>
              </div>
              <p className="text-[10px] text-slate-500 text-center mt-3">
                Demo passwords: Admin@123 · Manager@123 · Cashier@123
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
