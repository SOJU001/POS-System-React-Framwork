import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import { User } from '../../types';
import { ShieldCheck, Plus, Search, Edit2, Trash2, Key, X } from 'lucide-react';
import Swal from 'sweetalert2';

export const UsersScreen: React.FC = () => {
  const { users, refreshData, playSound, currentUser, rolePermissions } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [formData, setFormData] = useState({
    username: '',
    name: '',
    email: '',
    role: 'Cashier' as User['role'],
    pin: '1234',
    password: '',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
  });

  const filtered = (users || []).filter(
    (u) =>
      (u.name && u.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (u.username && u.username.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (u.role && u.role.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const openAddModal = () => {
    setEditingUser(null);
    setFormData({
      username: '',
      name: '',
      email: '',
      role: 'Cashier',
      pin: `${Math.floor(1000 + Math.random() * 9000)}`,
      password: '',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    });
    setShowModal(true);
  };

  const openEditModal = (u: User) => {
    setEditingUser(u);
    setFormData({
      username: u.username || u.email.split('@')[0],
      name: u.name,
      email: u.email,
      role: u.role,
      pin: u.pin || '1234',
      password: '',
      avatar: u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    });
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingUser) {
        const { password, ...rest } = formData;
        // Blank password on edit = keep the existing password unchanged
        const payload = password ? { ...rest, password } : rest;
        await api.updateUser(editingUser.id, payload);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'User Account Updated', showConfirmButton: false, timer: 1500 });
      } else {
        await api.createUser(formData);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'User Account Created', showConfirmButton: false, timer: 1500 });
      }
      playSound('success');
      setShowModal(false);
      await refreshData();
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (id === currentUser?.id) {
      Swal.fire({ icon: 'error', title: 'Action Denied', text: 'You cannot delete your own active session account!' });
      return;
    }

    const res = await Swal.fire({
      title: `Delete User Account?`,
      html: `<div class="text-xs text-slate-600 dark:text-slate-300 mt-1">Are you sure you want to remove account <b>"${name}"</b>? This user will lose system access immediately.</div>`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Remove User',
      cancelButtonText: 'Cancel',
    });

    if (res.isConfirmed) {
      await api.deleteUser(id);
      playSound('delete');
      await refreshData();
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'User Removed', showConfirmButton: false, timer: 1500 });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-[#3271a8]" />
            <span>Staff & Access Control</span>
          </h1>
          <p className="text-xs text-slate-400">Manage cashier accounts, manager overrides, and PIN credentials</p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Staff Account</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search staff name, username, or role..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((u) => (
          <div
            key={u.id}
            className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-3 mb-3">
                <img src={u.avatar} alt={u.name} className="w-12 h-12 rounded-2xl object-cover shadow-sm" />
                <div>
                  <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">{u.name}</h3>
                  <p className="text-xs text-slate-400">@{u.username}</p>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-500 border-t border-slate-100 dark:border-slate-700 pt-3">
                <div className="flex justify-between items-center">
                  <span>Assigned Role:</span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      u.role === 'Admin'
                        ? 'bg-purple-500/10 text-purple-600'
                        : u.role === 'Manager'
                        ? 'bg-blue-500/10 text-blue-600'
                        : 'bg-emerald-500/10 text-emerald-600'
                    }`}
                  >
                    {u.role}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Passcode PIN:</span>
                  <span className="font-mono font-bold text-slate-800 dark:text-slate-200">****</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Email:</span>
                  <span className="text-slate-700 dark:text-slate-300 font-medium">{u.email}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Two-Factor Auth:</span>
                  {u.twoFactorEnabled ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>Enabled</span>
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-500/15 text-slate-500">
                      Off
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-700 mt-4">
              <button onClick={() => openEditModal(u)} className="p-1.5 rounded-lg text-slate-400 hover:text-[#3271a8]">
                <Edit2 className="w-4 h-4" />
              </button>
              {u.id !== currentUser?.id && (currentUser?.role === 'Admin' || rolePermissions?.canDelete?.[currentUser?.role as 'Manager' | 'Cashier']) && (
                <button onClick={() => handleDelete(u.id, u.name)} className="p-1.5 rounded-lg text-slate-400 hover:text-red-500">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4">
              {editingUser ? 'Edit Staff Credentials' : 'Create Staff User Account'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Username</label>
                  <input
                    type="text"
                    required
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Role</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Cashier">Cashier</option>
                    <option value="Manager">Manager</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Email</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">4-Digit PIN Passcode</label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={formData.pin}
                    onChange={(e) => setFormData({ ...formData, pin: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono tracking-widest text-center"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Login Password</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder={editingUser ? 'Leave blank to keep current password' : `Defaults to ${formData.role === 'Admin' ? 'Admin@123' : formData.role === 'Manager' ? 'Manager@123' : 'Cashier@123'}`}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  {editingUser
                    ? 'Optional — leave blank to keep the current password unchanged.'
                    : 'Optional — a role-based default password is assigned when left blank.'}
                </p>
              </div>

              <div>
                <label className="block font-semibold mb-1">Avatar Image URL</label>
                <input
                  type="url"
                  value={formData.avatar}
                  onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#3271a8] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25"
              >
                Save Staff Account
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
