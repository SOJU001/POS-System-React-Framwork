import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import {
  Search,
  Bell,
  Sun,
  Moon,
  Globe,
  ShoppingCart,
  AlertTriangle,
  User,
  LogOut,
  Settings as SettingsIcon,
  Sparkles,
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';

export const Navbar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    darkMode,
    setDarkMode,
    language,
    setLanguage,
    currentUser,
    logout,
    products,
    settings,
  } = usePOS();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Low stock products alert
  const lowStockProducts = (products || []).filter((p) => p.stock <= p.minStock);

  const languages = ['EN', 'ES', 'FR', 'KH'];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    setActiveTab('products');
  };

  return (
    <header className="sticky top-0 z-10 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-700/80 px-6 py-3 flex items-center justify-between gap-4">
      {/* Brand Logo & Name */}
      <div className="flex items-center gap-3 shrink-0">
        <BrandLogo className="w-9 h-9 rounded-xl" iconClassName="w-4 h-4" />
        <div className="hidden sm:block">
          <h1 className="font-bold text-sm text-slate-800 dark:text-slate-100 leading-tight">
            {settings?.companyName || 'SmartPOS'}
          </h1>
          <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 leading-tight">
            Enterprise POS
          </p>
        </div>
      </div>

      {/* Search Input */}
      <div className="flex-1 max-w-md">
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search products, barcodes, customers, or SKU..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#3271a8]/50 transition-all"
          />
        </form>
      </div>

      {/* Action Buttons & Profile */}
      <div className="flex items-center gap-3">
        {/* Quick POS Button */}
        {activeTab !== 'pos' && (
          <button
            onClick={() => setActiveTab('pos')}
            className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white text-xs font-semibold shadow-md shadow-[#3271a8]/20 transition-all"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Open POS Terminal</span>
          </button>
        )}

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfileMenu(false);
            }}
            className="relative p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {lowStockProducts.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white dark:ring-slate-800 animate-pulse" />
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 py-3 px-4 z-50">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-700">
                <h3 className="font-semibold text-sm text-slate-800 dark:text-slate-100">Notifications</h3>
                <span className="text-xs font-medium text-[#3271a8]">
                  {lowStockProducts.length} Alert{lowStockProducts.length !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="py-2 space-y-2 max-h-64 overflow-y-auto">
                {lowStockProducts.length === 0 ? (
                  <p className="text-xs text-slate-400 py-4 text-center">No new notifications. All stock levels healthy!</p>
                ) : (
                  lowStockProducts.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => {
                        setActiveTab('inventory');
                        setShowNotifications(false);
                      }}
                      className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-800/60 flex items-start gap-2.5 cursor-pointer hover:bg-amber-100/60 transition-colors"
                    >
                      <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold text-amber-900 dark:text-amber-200">{p.name}</p>
                        <p className="text-[11px] text-amber-700 dark:text-amber-400">
                          Stock is down to <span className="font-bold">{p.stock} {p.unit}</span> (Min: {p.minStock})
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Language Picker */}
        <div className="relative hidden md:block">
          <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-700/60 text-xs font-semibold text-slate-700 dark:text-slate-200">
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-transparent focus:outline-none cursor-pointer"
            >
              {languages.map((l) => (
                <option key={l} value={l} className="dark:bg-slate-800 dark:text-white">
                  {l}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Dark Mode Toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
        </button>

        {/* Profile Dropdown */}
        {currentUser && (
          <div className="relative">
            <button
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowNotifications(false);
              }}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150'}
                alt={currentUser.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-[#3271a8]"
              />
            </button>

            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 py-2 px-1 z-50">
                <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-700 mb-1">
                  <p className="font-semibold text-xs text-slate-800 dark:text-slate-100">{currentUser.name}</p>
                  <p className="text-[11px] text-slate-400 truncate">{currentUser.email}</p>
                  <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#3271a8]/10 text-[#3271a8]">
                    {currentUser.role}
                  </span>
                </div>

                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                >
                  <SettingsIcon className="w-4 h-4 text-slate-500" />
                  <span>{currentUser.role === 'Admin' ? 'Store & Account Settings' : 'Profile & Password Settings'}</span>
                </button>

                <button
                  onClick={() => {
                    logout();
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4 text-red-500" />
                  <span>Log Out</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
