import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Tags,
  Boxes,
  Truck,
  Users,
  UserCheck,
  Receipt,
  RotateCcw,
  DollarSign,
  BarChart3,
  UserCog,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Code2,
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, logout, settings, setShowDevDocs, rolePermissions } = usePOS();
  const [collapsed, setCollapsed] = useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, role: ['Admin', 'Manager'] },
    { id: 'pos', label: 'POS Terminal', icon: ShoppingCart, badge: 'FAST', role: ['Admin', 'Manager', 'Cashier'] },
    { id: 'products', label: 'Products', icon: Package, role: ['Admin', 'Manager'] },
    { id: 'categories', label: 'Categories', icon: Tags, role: ['Admin', 'Manager'] },
    { id: 'inventory', label: 'Inventory & Stock', icon: Boxes, role: ['Admin', 'Manager'] },
    { id: 'purchases', label: 'Purchases PO', icon: Truck, role: ['Admin', 'Manager'] },
    { id: 'suppliers', label: 'Suppliers', icon: Users, role: ['Admin', 'Manager'] },
    { id: 'customers', label: 'Customers & Loyalty', icon: UserCheck, role: ['Admin', 'Manager', 'Cashier'] },
    { id: 'sales', label: 'Sales History', icon: Receipt, role: ['Admin', 'Manager', 'Cashier'] },
    { id: 'returns', label: 'Returns & Refunds', icon: RotateCcw, role: ['Admin', 'Manager'] },
    { id: 'expenses', label: 'Expenses', icon: DollarSign, role: ['Admin', 'Manager'] },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3, role: ['Admin', 'Manager'] },
    { id: 'users', label: 'User Roles', icon: UserCog, role: ['Admin'] },
    { id: 'settings', label: 'Settings', icon: Settings, role: ['Admin', 'Manager', 'Cashier'] },
  ];

  // Determine which nav items the current user can see
  const allowedItems = menuItems.filter((item) => {
    if (!currentUser) return false;
    
    // Admin always sees all tabs
    if (currentUser.role === 'Admin') return true;
    
    // Check if role is in the default role list for this item
    const hasRoleAccess = item.role.includes(currentUser.role);
    if (!hasRoleAccess) return false;
    
    // If rolePermissions are configured, check the navTabs config
    if (rolePermissions && rolePermissions.navTabs) {
      const allowedTabs = rolePermissions.navTabs[currentUser.role];
      if (allowedTabs) {
        return allowedTabs.includes(item.id);
      }
    }
    
    // Fall back to default role-based access
    return true;
  });

  return (
    <aside
      className={`relative transition-all duration-300 ease-in-out flex flex-col justify-between z-20 ${
        collapsed ? 'w-20' : 'w-64'
      } bg-white/90 dark:bg-slate-800/90 backdrop-blur-md border-r border-slate-200/80 dark:border-slate-700/80 min-h-screen shadow-sm`}
    >
      {/* Brand Logo & Collapse Toggle */}
      <div>
        <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-700">
          {!collapsed ? (
            <div className="flex items-center gap-3">
              <BrandLogo className="w-10 h-10 rounded-xl" />
              <div>
                <h1 className="font-bold text-lg text-slate-800 dark:text-slate-100 leading-tight">
                  {settings?.companyName || 'SmartPOS'}
                </h1>
                <p className="text-[11px] font-medium text-slate-400 dark:text-slate-400">
                  v2.4 • Pro Enterprise
                </p>
              </div>
            </div>
          ) : (
            <BrandLogo className="mx-auto w-10 h-10 rounded-xl" />
          )}

          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 transition-colors hidden md:block"
            title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="p-3 space-y-1 max-h-[calc(100vh-180px)] overflow-y-auto">
          {allowedItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 group relative ${
                  isActive
                    ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/25 font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/60 hover:text-slate-900 dark:hover:text-white'
                }`}
                title={collapsed ? item.label : undefined}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-white' : 'text-slate-500 group-hover:text-[#3271a8]'}`} />
                
                {!collapsed && <span className="truncate">{item.label}</span>}

                {!collapsed && item.badge && (
                  <span className="ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Info & Developer Docs */}
      <div className="p-3 border-t border-slate-100 dark:border-slate-700 space-y-2">
        <button
          onClick={() => setShowDevDocs(true)}
          className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-xs font-semibold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition-colors ${
            collapsed ? 'justify-center' : ''
          }`}
          title="View Django & MySQL Architecture Code"
        >
          <Code2 className="w-4 h-4 text-purple-600" />
          {!collapsed && <span>Django & MySQL Specs</span>}
        </button>

        {/* User Card & Logout */}
        {currentUser && (
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-700/50">
            {!collapsed && (
              <div className="flex items-center gap-2.5 overflow-hidden">
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150'}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-[#3271a8]/30"
                />
                <div className="truncate">
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                    {currentUser.name}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium capitalize">
                    {currentUser.role}
                  </p>
                </div>
              </div>
            )}

            <button
              onClick={logout}
              className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};
