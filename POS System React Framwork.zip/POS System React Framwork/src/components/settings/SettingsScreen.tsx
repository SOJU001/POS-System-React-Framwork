import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import { BrandLogo } from '../common/BrandLogo';
import { RolePermissions } from '../../types';
import {
  Settings as SettingsIcon,
  Save,
  Download,
  Upload,
  Volume2,
  Store,
  Receipt,
  ShieldAlert,
  Bell,
  Send,
  Database,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Key,
  Server,
  FileCode,
  User as UserIcon,
  Lock,
  Shield,
  ShieldCheck,
  QrCode,
  ImageUp,
  Trash2,
  Eye,
  EyeOff,
} from 'lucide-react';
import Swal from 'sweetalert2';

// ---- Role Permissions Editor Component ----
const ALL_NAV_TABS = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'pos', label: 'POS Terminal' },
  { id: 'products', label: 'Products' },
  { id: 'categories', label: 'Categories' },
  { id: 'inventory', label: 'Inventory & Stock' },
  { id: 'purchases', label: 'Purchases PO' },
  { id: 'suppliers', label: 'Suppliers' },
  { id: 'customers', label: 'Customers & Loyalty' },
  { id: 'sales', label: 'Sales History' },
  { id: 'returns', label: 'Returns & Refunds' },
  { id: 'expenses', label: 'Expenses' },
  { id: 'reports', label: 'Reports & Analytics' },
  { id: 'users', label: 'User Roles' },
  { id: 'settings', label: 'Settings' },
];

const RolePermissionsEditor: React.FC<{
  permissions: RolePermissions | undefined;
  onSave: (perms: RolePermissions) => Promise<void>;
}> = ({ permissions, onSave }) => {
  const defaultPerms: RolePermissions = {
    navTabs: {
      Manager: ['dashboard', 'pos', 'products', 'categories', 'inventory', 'purchases', 'suppliers', 'customers', 'sales', 'returns', 'expenses', 'reports', 'settings'],
      Cashier: ['pos', 'customers', 'sales', 'settings'],
    },
    canDelete: {
      Manager: true,
      Cashier: false,
    },
  };

  const [localPerms, setLocalPerms] = useState<RolePermissions>(
    permissions || defaultPerms
  );

  const [activeRole, setActiveRole] = useState<'Manager' | 'Cashier'>('Manager');

  const toggleNavTab = (role: 'Manager' | 'Cashier', tabId: string) => {
    setLocalPerms((prev) => {
      const current = prev.navTabs[role];
      const updated = current.includes(tabId)
        ? current.filter((id) => id !== tabId)
        : [...current, tabId];
      return {
        ...prev,
        navTabs: { ...prev.navTabs, [role]: updated },
      };
    });
  };

  const toggleCanDelete = (role: 'Manager' | 'Cashier') => {
    setLocalPerms((prev) => ({
      ...prev,
      canDelete: { ...prev.canDelete, [role]: !prev.canDelete[role] },
    }));
  };

  return (
    <div className="space-y-4 text-xs">
      {/* Role Switcher */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setActiveRole('Manager')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeRole === 'Manager'
              ? 'bg-blue-500 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
          }`}
        >
          👔 Manager Role
        </button>
        <button
          type="button"
          onClick={() => setActiveRole('Cashier')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeRole === 'Cashier'
              ? 'bg-emerald-500 text-white shadow-md'
              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
          }`}
        >
          🛒 Cashier Role
        </button>
      </div>

      {/* Navigation Tabs Grid */}
      <div>
        <p className="font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
          <Eye className="w-3.5 h-3.5 text-purple-500" />
          <span>Allowed Navigation Tabs for {activeRole}</span>
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
          {ALL_NAV_TABS.map((tab) => {
            const isAllowed = localPerms.navTabs[activeRole].includes(tab.id);
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => toggleNavTab(activeRole, tab.id)}
                className={`px-3 py-2 rounded-xl text-[11px] font-semibold border transition-all cursor-pointer text-left ${
                  isAllowed
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  {isAllowed ? (
                    <Eye className="w-3 h-3 shrink-0 text-emerald-500" />
                  ) : (
                    <EyeOff className="w-3 h-3 shrink-0 text-slate-400" />
                  )}
                  <span className="truncate">{tab.label}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Delete Permission */}
      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700">
        <p className="font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
          <Trash2 className="w-3.5 h-3.5 text-red-500" />
          <span>Delete Permission for {activeRole}</span>
        </p>
        <label className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
          <div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-100 block">
              Allow {activeRole} to delete records
            </span>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              {activeRole === 'Manager'
                ? 'When enabled, Manager can delete products, categories, customers, suppliers, expenses, and inventory records'
                : 'When enabled, Cashier can delete records across the system'}
            </span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={localPerms.canDelete[activeRole]}
              onChange={() => toggleCanDelete(activeRole)}
              className="sr-only peer"
            />
            <div className="w-10 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-500"></div>
          </label>
        </label>
      </div>

      {/* Save Button */}
      <button
        type="button"
        onClick={() => onSave(localPerms)}
        className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md shadow-purple-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
      >
        <Save className="w-4 h-4" />
        <span>Save Role Permissions</span>
      </button>
    </div>
  );
};

export const SettingsScreen: React.FC = () => {
  const { settings, refreshData, soundEnabled, setSoundEnabled, playSound, currentUser, setCurrentUser, login } = usePOS();

  // Profile & Password State
  const [profileData, setProfileData] = useState({
    name: currentUser?.name || 'Administrator',
    email: currentUser?.email || 'admin@smartpos.io',
    phone: currentUser?.phone || '+1 (800) 555-7678',
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  useEffect(() => {
    if (currentUser) {
      setProfileData({
        name: currentUser.name || '',
        email: currentUser.email || '',
        phone: currentUser.phone || '',
      });
    }
  }, [currentUser]);

  const [formData, setFormData] = useState({
    companyName: settings?.companyName || 'SmartPOS Retail Inc.',
    address: settings?.address || '123 Tech Boulevard, Silicon Valley, CA',
    phone: settings?.phone || '+1 (800) 555-7678',
    email: settings?.email || 'support@smartpos.io',
    taxRate: settings?.taxRate || 10,
    currencySymbol: settings?.currencySymbol || '$',
    khrExchangeRate: settings?.khrExchangeRate || 4100,
    receiptHeader: settings?.receiptHeader || 'Thank you for shopping with us!',
    receiptFooter: settings?.receiptFooter || 'Goods sold are non-refundable after 7 days.',
  });

  // Telegram State
  const [telegramData, setTelegramData] = useState({
    botToken: '',
    chatId: '',
    enableLowStockAlerts: true,
    enableSalesAlerts: true,
  });
  const [testingTelegram, setTestingTelegram] = useState(false);

  // MySQL State
  const [mysqlData, setMysqlData] = useState({
    host: '127.0.0.1',
    port: 3306,
    user: 'root',
    password: '',
    database: 'smartpos_db',
    autoSync: true,
    status: 'Connected (Local MySQL Ready)',
    lastSyncedAt: '',
  });
  const [testingMysql, setTestingMysql] = useState(false);
  const [syncingMysql, setSyncingMysql] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [removingLogo, setRemovingLogo] = useState(false);

  // Two-Factor Authentication (TOTP) State
  const [twoFactorSetup, setTwoFactorSetup] = useState<{ qrCodeUrl: string; secret: string } | null>(null);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [twoFactorLoading, setTwoFactorLoading] = useState(false);

  useEffect(() => {
    // Load Telegram Config
    api
      .getTelegramConfig()
      .then((cfg) => {
        setTelegramData({
          botToken: cfg.botToken || '',
          chatId: cfg.chatId || '',
          enableLowStockAlerts: cfg.enableLowStockAlerts ?? true,
          enableSalesAlerts: cfg.enableSalesAlerts ?? true,
        });
      })
      .catch(() => {});

    // Load MySQL Config
    api
      .getMysqlConfig()
      .then((mcfg) => {
        setMysqlData({
          host: mcfg.host || '127.0.0.1',
          port: mcfg.port || 3306,
          user: mcfg.user || 'root',
          password: '',
          database: mcfg.database || 'smartpos_db',
          autoSync: mcfg.autoSync ?? true,
          status: mcfg.status || 'Connected (Local MySQL Ready)',
          lastSyncedAt: mcfg.lastSyncedAt || new Date().toISOString(),
        });
      })
      .catch(() => {});
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.updateSettings(formData);
      playSound('success');
      await refreshData();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Store Configuration Saved!',
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    }
  };

  // Telegram Handlers
  const saveTelegramConfig = async () => {
    try {
      await api.updateTelegramConfig(telegramData);
      playSound('success');
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Telegram Alarm Settings Saved!',
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Telegram Save Failed', text: err.message });
    }
  };

  const handleTestTelegram = async () => {
    if (!telegramData.botToken || !telegramData.chatId) {
      Swal.fire({
        icon: 'warning',
        title: 'Missing Telegram Credentials',
        text: 'Please enter your Telegram Bot Token and Chat ID before testing.',
      });
      return;
    }

    setTestingTelegram(true);
    try {
      const res = await api.testTelegramAlarm(telegramData.botToken, telegramData.chatId);
      if (res.success) {
        playSound('success');
        Swal.fire({
          icon: 'success',
          title: 'Telegram Alarm Delivered!',
          text: 'Check your Telegram app! A test alert message was received successfully.',
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Telegram Alarm Delivery Failed',
          text: res.reason || 'Please verify your Bot Token and Chat ID.',
        });
      }
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    } finally {
      setTestingTelegram(false);
    }
  };

  // MySQL Handlers
  const saveMysqlConfig = async () => {
    try {
      await api.updateMysqlConfig(mysqlData);
      playSound('success');
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'MySQL Connection Settings Saved!',
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'MySQL Save Failed', text: err.message });
    }
  };

  const handleTestMysql = async () => {
    setTestingMysql(true);
    try {
      const res = await api.testMysqlConnection(mysqlData);
      if (res.success) {
        playSound('success');
        Swal.fire({
          icon: 'success',
          title: 'MySQL Connection Active!',
          text: `Connected to ${mysqlData.host}:${mysqlData.port} (${mysqlData.database}). Ping: ${res.details?.pingMs || 12}ms.`,
        });
      } else {
        Swal.fire({ icon: 'error', title: 'Connection Failed', text: res.message });
      }
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'MySQL Test Error', text: err.message });
    } finally {
      setTestingMysql(false);
    }
  };

  const handleSyncMysql = async () => {
    setSyncingMysql(true);
    try {
      const res = await api.syncMysqlDatabase();
      playSound('success');
      setMysqlData((prev) => ({
        ...prev,
        status: `Synced (${res.syncedTables.length} tables)`,
        lastSyncedAt: res.timestamp,
      }));
      Swal.fire({
        icon: 'success',
        title: 'MySQL Schema Synchronized!',
        text: res.message,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Sync Error', text: err.message });
    } finally {
      setSyncingMysql(false);
    }
  };

  const exportBackup = async () => {
    try {
      const data = await api.exportBackup();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `SmartPOS_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Database Backup Exported', showConfirmButton: false, timer: 1500 });
    } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Backup Failed', text: e.message });
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        await api.restoreBackup(json);
        playSound('success');
        await refreshData();
        Swal.fire({ icon: 'success', title: 'Database Restored!', text: 'All products, sales, and settings restored successfully.' });
      } catch (err: any) {
        Swal.fire({ icon: 'error', title: 'Restore Failed', text: 'Invalid JSON backup file format.' });
      }
    };
    reader.readAsText(file);
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    try {
      const updated = await api.updateUser(currentUser.id, profileData);
      login(updated);
      playSound('success');
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Profile Updated Successfully!',
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Profile Update Failed', text: err.message });
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      Swal.fire({ icon: 'error', title: 'Password Mismatch', text: 'New password and confirmation do not match.' });
      return;
    }
    if (passwordData.newPassword.length < 4) {
      Swal.fire({ icon: 'error', title: 'Weak Password', text: 'Password must be at least 4 characters long.' });
      return;
    }

    try {
      await api.updateUser(currentUser.id, { password: passwordData.newPassword });
      playSound('success');
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Password Changed Successfully!',
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Password Update Failed', text: err.message });
    }
  };

  // ---- Two-Factor Authentication (TOTP) Handlers ----
  const [twoFactorPassword, setTwoFactorPassword] = useState('');

  const handleSetup2FA = async () => {
    if (!currentUser) return;
    const pw = await Swal.fire({
      icon: 'info',
      title: 'Confirm Your Password',
      text: 'Enter your current password to set up two-factor authentication.',
      input: 'password',
      inputPlaceholder: 'Your current password',
      showCancelButton: true,
      confirmButtonText: 'Continue',
      confirmButtonColor: '#3271a8',
      cancelButtonText: 'Cancel',
    });
    if (!pw.isConfirmed || !pw.value) return;

    setTwoFactorLoading(true);
    setTwoFactorPassword(String(pw.value));
    try {
      const setup = await api.setup2FA(currentUser.id, String(pw.value));
      setTwoFactorSetup({ qrCodeUrl: setup.qrCodeUrl, secret: setup.secret });
      setTwoFactorCode('');
    } catch (err: any) {
      setTwoFactorPassword('');
      Swal.fire({ icon: 'error', title: '2FA Setup Failed', text: err.message });
    } finally {
      setTwoFactorLoading(false);
    }
  };

  const handleEnable2FA = async () => {
    if (!currentUser) return;
    if (twoFactorCode.length !== 6) {
      Swal.fire({ icon: 'warning', title: 'Enter 6-Digit Code', text: 'Please enter the 6-digit code from your authenticator app.' });
      return;
    }
    setTwoFactorLoading(true);
    try {
      await api.enable2FA(currentUser.id, twoFactorPassword, twoFactorCode);
      login({ ...currentUser, twoFactorEnabled: true });
      setTwoFactorSetup(null);
      setTwoFactorCode('');
      setTwoFactorPassword('');
      playSound('success');
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Two-Factor Authentication Enabled!',
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Verification Failed', text: err.message });
    } finally {
      setTwoFactorLoading(false);
    }
  };

  const handleDisable2FA = async () => {
    if (!currentUser) return;
    const res = await Swal.fire({
      icon: 'warning',
      title: 'Disable Two-Factor Authentication?',
      text: 'Enter the current 6-digit code from your authenticator app to confirm.',
      input: 'text',
      inputPlaceholder: '••••••',
      inputAttributes: { maxlength: '6', inputmode: 'numeric' },
      showCancelButton: true,
      confirmButtonText: 'Disable 2FA',
      confirmButtonColor: '#dc2626',
      cancelButtonText: 'Cancel',
    });
    if (!res.isConfirmed || !res.value) return;
    setTwoFactorLoading(true);
    try {
      await api.disable2FA(currentUser.id, String(res.value).trim());
      login({ ...currentUser, twoFactorEnabled: false });
      playSound('delete');
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Two-Factor Authentication Disabled',
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Failed to Disable 2FA', text: err.message });
    } finally {
      setTwoFactorLoading(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate image type
    if (!file.type.startsWith('image/')) {
      Swal.fire({ icon: 'error', title: 'Invalid File', text: 'Please select an image file (PNG, JPG, SVG, etc.)' });
      return;
    }

    // Validate size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      Swal.fire({ icon: 'error', title: 'File Too Large', text: 'Logo image must be under 5MB.' });
      return;
    }

    setUploadingLogo(true);
    try {
      const res = await api.uploadLogo(file);
      playSound('success');
      await refreshData();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Logo uploaded! Reflecting across the system.',
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Upload Failed', text: err.message });
    } finally {
      setUploadingLogo(false);
      // Reset the input so the same file can be re-selected
      e.target.value = '';
    }
  };

  const handleRemoveLogo = async () => {
    const result = await Swal.fire({
      icon: 'warning',
      title: 'Remove Logo?',
      text: 'This will reset the logo to the default Store icon across the sidebar, navbar, login screen, and receipts.',
      showCancelButton: true,
      confirmButtonText: 'Yes, Remove Logo',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#dc2626',
      cancelButtonColor: '#64748b',
    });

    if (!result.isConfirmed) return;

    setRemovingLogo(true);
    try {
      await api.removeLogo();
      playSound('success');
      await refreshData();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Logo removed! Default icon restored.',
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Failed to Remove Logo', text: err.message });
    } finally {
      setRemovingLogo(false);
    }
  };

  const isAdmin = currentUser?.role === 'Admin';

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <SettingsIcon className="w-6 h-6 text-[#3271a8]" />
          <span>{isAdmin ? 'System & Account Configuration' : 'My Profile & Account Settings'}</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {isAdmin
            ? 'Manage account profile, change password, store info, POS display, Telegram alarms, and MySQL database sync'
            : 'Manage your personal account profile details and update your account security password'}
        </p>
      </div>

      {/* USER PROFILE & CHANGE PASSWORD SETTINGS */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-3">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#3271a8]/10 text-[#3271a8]">
              <UserIcon className="w-4 h-4" />
            </div>
            <span>User Account Profile & Change Password</span>
          </h3>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 self-start sm:self-auto">
            <Shield className="w-3 h-3 text-indigo-500" />
            <span>Role: {currentUser?.role || 'Administrator'}</span>
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Update Profile Form */}
          <form onSubmit={handleUpdateProfile} className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700 space-y-4">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-200/60 dark:border-slate-700 pb-2">
              <UserIcon className="w-4 h-4 text-[#3271a8]" />
              <span>Update Personal Profile Details</span>
            </h4>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={profileData.name}
                  onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={profileData.email}
                  onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={profileData.phone}
                  onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                  placeholder="+1 (800) 555-0199"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs shadow-md shadow-[#3271a8]/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile Updates</span>
            </button>
          </form>

          {/* Change Password Form */}
          <form onSubmit={handleChangePassword} className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700 space-y-4">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-200/60 dark:border-slate-700 pb-2">
              <Lock className="w-4 h-4 text-emerald-600" />
              <span>Security & Change Password</span>
            </h4>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Current Password</label>
                <input
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">New Password</label>
                <input
                  type="password"
                  required
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                  placeholder="Minimum 4 characters"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                  placeholder="Re-enter new password"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>Update Account Password</span>
            </button>
          </form>
        </div>

        {/* Two-Factor Authentication (TOTP) */}
        <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700 space-y-4">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-200/60 dark:border-slate-700 pb-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>Two-Factor Authentication (2FA)</span>
            {currentUser?.twoFactorEnabled && (
              <span className="ml-auto px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>ACTIVE</span>
              </span>
            )}
          </h4>

          {currentUser?.twoFactorEnabled ? (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-600 dark:text-slate-300">
                <p className="font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
                  Your account is protected with an authenticator app.
                </p>
                <p>Every sign-in now requires your email/password plus a 6-digit code.</p>
              </div>
              <button
                type="button"
                onClick={handleDisable2FA}
                disabled={twoFactorLoading}
                className="px-4 py-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-950/60 text-red-600 dark:text-red-400 font-semibold text-xs border border-red-200 dark:border-red-800/60 transition-all cursor-pointer disabled:opacity-50 shrink-0"
              >
                {twoFactorLoading ? 'Working...' : 'Disable 2FA'}
              </button>
            </div>
          ) : twoFactorSetup ? (
            <div className="flex flex-col sm:flex-row gap-5 items-start">
              <div className="shrink-0 mx-auto sm:mx-0">
                <img
                  src={twoFactorSetup.qrCodeUrl}
                  alt="2FA QR Code"
                  className="w-40 h-40 rounded-2xl bg-white p-2 shadow-md border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div className="flex-1 space-y-3 text-xs min-w-0">
                <div>
                  <p className="font-semibold text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-1.5">
                    <QrCode className="w-3.5 h-3.5 text-indigo-600" />
                    Scan with Google Authenticator / Authy
                  </p>
                  <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                    Scan the QR code with your authenticator app, then enter the 6-digit code below to confirm.
                  </p>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Manual Secret Key</label>
                  <code className="block px-3 py-2 rounded-xl bg-slate-900/60 dark:bg-slate-900 text-emerald-400 font-mono text-[11px] break-all select-all">
                    {twoFactorSetup.secret}
                  </code>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">6-Digit Verification Code</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      value={twoFactorCode}
                      onChange={(e) => setTwoFactorCode(e.target.value.replace(/\D/g, ''))}
                      placeholder="••••••"
                      className="w-32 px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-mono text-center tracking-[0.4em] font-bold"
                    />
                    <button
                      type="button"
                      onClick={handleEnable2FA}
                      disabled={twoFactorLoading || twoFactorCode.length !== 6}
                      className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all cursor-pointer disabled:opacity-50"
                    >
                      {twoFactorLoading ? 'Verifying...' : 'Verify & Enable'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setTwoFactorSetup(null)}
                      className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold text-xs border border-slate-200 dark:border-slate-600 transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-600 dark:text-slate-300">
                <p className="font-semibold text-slate-800 dark:text-slate-100 mb-1">Protect your account with an extra layer of security</p>
                <p className="text-slate-500 dark:text-slate-400">
                  Once enabled, sign-in requires your password plus a 6-digit code from an authenticator app (Google Authenticator, Authy, etc.).
                </p>
              </div>
              <button
                type="button"
                onClick={handleSetup2FA}
                disabled={twoFactorLoading}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 shrink-0"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{twoFactorLoading ? 'Preparing...' : 'Enable Two-Factor Authentication'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Store and System Settings - Visible ONLY to Admin Role */}
      {isAdmin && (
        <>
          {/* System Integration Tabs/Navigation Bar */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-3">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#3271a8]/10 text-[#3271a8]">
              <Store className="w-4 h-4" />
            </div>
            <span>POS Screen, Full Screen Mode & Direct Inline Discounts</span>
          </h3>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
            Inline Direct Discount Inputs Active
          </span>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Configure cashier checkout terminal behaviors. Discounts can be typed directly inline in the order panel next to Qty without popup dialogs.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700 space-y-3">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">Full Screen POS Terminal Toggle</h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Expand the POS terminal into borderless full screen mode for dedicated cashier hardware monitors.
            </p>
            <button
              type="button"
              onClick={() => {
                if (!document.fullscreenElement) {
                  document.documentElement.requestFullscreen().catch(() => {});
                } else if (document.exitFullscreen) {
                  document.exitFullscreen().catch(() => {});
                }
              }}
              className="w-full py-2.5 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs shadow-md shadow-[#3271a8]/20 transition-all cursor-pointer"
            >
              Toggle Full Screen POS Terminal
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700 space-y-2">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">Direct Input & Receipt Features</h4>
            <ul className="text-[11px] text-slate-600 dark:text-slate-300 space-y-1.5">
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Inline Item Discount % inputs next to Qty (No popups)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Order Discount percentage input with quick preset buttons</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Receipts support Print, PDF Export, and Photo PNG Download</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* 1. TELEGRAM ALARM NOTIFICATION SETTINGS */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-3">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
              <Bell className="w-4 h-4" />
            </div>
            <span>Telegram Alarm Notification Bot</span>
          </h3>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-sky-500/15 text-sky-600 dark:text-sky-400 self-start sm:self-auto">
            Instant Sales & Low Stock Alarms
          </span>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Connect your Telegram Bot to receive automated real-time alarms on mobile whenever a new sale is completed or inventory falls below safety thresholds.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-sky-500" />
              <span>Telegram Bot Token</span>
            </label>
            <input
              type="text"
              value={telegramData.botToken}
              onChange={(e) => setTelegramData({ ...telegramData, botToken: e.target.value })}
              placeholder="e.g. 123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-mono text-[11px]"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-sky-500" />
              <span>Target Chat / Group ID</span>
            </label>
            <input
              type="text"
              value={telegramData.chatId}
              onChange={(e) => setTelegramData({ ...telegramData, chatId: e.target.value })}
              placeholder="e.g. 987654321 or -100123456789"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-mono text-[11px]"
            />
          </div>
        </div>

        {/* Toggles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700/80 cursor-pointer">
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">Low Stock Alarm Warnings</span>
              <span className="text-[10px] text-slate-400 block">Sends alarm when stock reaches minimum reorder level</span>
            </div>
            <input
              type="checkbox"
              checked={telegramData.enableLowStockAlerts}
              onChange={(e) => setTelegramData({ ...telegramData, enableLowStockAlerts: e.target.checked })}
              className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
            />
          </label>

          <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700/80 cursor-pointer">
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">Sales Receipt Alarms</span>
              <span className="text-[10px] text-slate-400 block">Sends instant transaction notification on every checkout</span>
            </div>
            <input
              type="checkbox"
              checked={telegramData.enableSalesAlerts}
              onChange={(e) => setTelegramData({ ...telegramData, enableSalesAlerts: e.target.checked })}
              className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
            />
          </label>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
          <button
            type="button"
            onClick={saveTelegramConfig}
            className="w-full sm:w-auto px-5 py-2.5 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md shadow-sky-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Save Telegram Config</span>
          </button>

          <button
            type="button"
            onClick={handleTestTelegram}
            disabled={testingTelegram}
            className="w-full sm:w-auto px-5 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all border border-slate-200 dark:border-slate-600"
          >
            {testingTelegram ? <RefreshCw className="w-4 h-4 animate-spin text-sky-500" /> : <Send className="w-4 h-4 text-sky-500" />}
            <span>{testingTelegram ? 'Sending Test Alarm...' : 'Send Test Telegram Alarm'}</span>
          </button>
        </div>
      </div>

      {/* 2. LOCAL MYSQL DATABASE CONNECTION & SCHEMA SYNC */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-3">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Database className="w-4 h-4" />
            </div>
            <span>Local & Remote MySQL Database Connection</span>
          </h3>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 self-start sm:self-auto">
            <CheckCircle2 className="w-3 h-3" />
            <span>{mysqlData.status}</span>
          </span>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Connect your POS store directly to local MySQL (Workbench, XAMPP, phpMyAdmin) or a remote MySQL database server for persistent SQL storage and enterprise reporting.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="col-span-2 sm:col-span-1">
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
              <Server className="w-3.5 h-3.5 text-emerald-600" />
              <span>MySQL Host</span>
            </label>
            <input
              type="text"
              value={mysqlData.host}
              onChange={(e) => setMysqlData({ ...mysqlData, host: e.target.value })}
              placeholder="127.0.0.1"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-[11px]"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Port</label>
            <input
              type="number"
              value={mysqlData.port}
              onChange={(e) => setMysqlData({ ...mysqlData, port: Number(e.target.value) })}
              placeholder="3306"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-[11px]"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Database Name</label>
            <input
              type="text"
              value={mysqlData.database}
              onChange={(e) => setMysqlData({ ...mysqlData, database: e.target.value })}
              placeholder="smartpos_db"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-[11px]"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">User</label>
            <input
              type="text"
              value={mysqlData.user}
              onChange={(e) => setMysqlData({ ...mysqlData, user: e.target.value })}
              placeholder="root"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-[11px]"
            />
          </div>
        </div>

        {/* MySQL Actions */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={saveMysqlConfig}
            className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Save Connection Config</span>
          </button>

          <button
            type="button"
            onClick={handleTestMysql}
            disabled={testingMysql}
            className="px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all border border-slate-200 dark:border-slate-600"
          >
            {testingMysql ? <RefreshCw className="w-4 h-4 animate-spin text-emerald-500" /> : <Server className="w-4 h-4 text-emerald-500" />}
            <span>Test Connection</span>
          </button>

          <button
            type="button"
            onClick={handleSyncMysql}
            disabled={syncingMysql}
            className="px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all border border-slate-200 dark:border-slate-600"
          >
            {syncingMysql ? <RefreshCw className="w-4 h-4 animate-spin text-emerald-500" /> : <RefreshCw className="w-4 h-4 text-emerald-500" />}
            <span>Sync MySQL Schema</span>
          </button>

          <a
            href="/api/mysql/export-sql"
            download
            className="px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all border border-slate-200 dark:border-slate-600"
          >
            <FileCode className="w-4 h-4 text-emerald-500" />
            <span>Download .sql Export</span>
          </a>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Store Info */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-700 pb-3">
            <Store className="w-4 h-4 text-[#3271a8]" />
            <span>Store Profile & Tax Setup</span>
          </h3>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Company / Store Name</label>
              <input
                type="text"
                required
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Tax Rate (%)</label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.taxRate}
                onChange={(e) => setFormData({ ...formData, taxRate: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">USD → KHR Exchange Rate</label>
              <input
                type="number"
                step="1"
                min="1"
                required
                value={formData.khrExchangeRate}
                onChange={(e) => setFormData({ ...formData, khrExchangeRate: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-bold"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Used to show KHR (Cambodian Riel) amounts on receipts. Default: 4100.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Phone Contact</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="text-xs">
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Store Address</label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
            />
          </div>
        </div>

        {/* Logo Upload */}
        <div className="border-t border-slate-100 dark:border-slate-700 pt-4">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 mb-3">
            <ImageUp className="w-4 h-4 text-[#3271a8]" />
            <span>Company Logo</span>
          </h4>
          <div className="flex items-center gap-4">
            <div className="shrink-0">
              <BrandLogo className="w-16 h-16 rounded-2xl shadow-lg" iconClassName="w-7 h-7" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 transition-all cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>{uploadingLogo ? 'Uploading...' : 'Upload New Logo'}</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    onChange={handleLogoUpload}
                    disabled={uploadingLogo}
                    className="hidden"
                  />
                </label>
                <button
                  type="button"
                  onClick={handleRemoveLogo}
                  disabled={removingLogo}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-950/60 text-red-600 dark:text-red-400 font-semibold text-xs border border-red-200 dark:border-red-800/60 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{removingLogo ? 'Removing...' : 'Remove Logo'}</span>
                </button>
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500">
                PNG, JPG, SVG or WebP. Max 5MB. Square format recommended.<br />
                Updates immediately across the sidebar, navbar, login screen, and receipts.
              </p>
            </div>
          </div>
        </div>

        {/* Receipt Setup */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-700 pb-3">
            <Receipt className="w-4 h-4 text-[#3271a8]" />
            <span>Thermal Receipt Customization</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Header Welcome Note</label>
              <input
                type="text"
                value={formData.receiptHeader}
                onChange={(e) => setFormData({ ...formData, receiptHeader: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Footer Disclaimer Note</label>
              <input
                type="text"
                value={formData.receiptFooter}
                onChange={(e) => setFormData({ ...formData, receiptFooter: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
              />
            </div>
          </div>
        </div>

        {/* Preferences & Sound */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Volume2 className="w-5 h-5 text-[#3271a8]" />
            <div>
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">Audio Feedback Effects</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">Play barcode scanner bleeps and transaction alert chimes</p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={soundEnabled}
              onChange={(e) => setSoundEnabled(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#3271a8]"></div>
          </label>
        </div>

        <button
          type="submit"
          className="w-full py-3.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs shadow-xl shadow-[#3271a8]/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Save Store Configuration</span>
        </button>
      </form>

      {/* ROLE PERMISSIONS & ACCESS CONTROL - Admin Only */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700 pb-3">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Shield className="w-4 h-4" />
            </div>
            <span>Role Permissions & Access Control</span>
          </h3>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-purple-500/15 text-purple-600 dark:text-purple-400 self-start sm:self-auto">
            Admin Only
          </span>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Configure which navigation tabs each role can see and whether they can delete records. 
          Admin always has full access to all features and tabs.
        </p>

        <RolePermissionsEditor
          permissions={settings?.rolePermissions}
          onSave={async (perms) => {
            try {
              await api.updateSettings({ rolePermissions: perms });
              playSound('success');
              await refreshData();
              Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: 'Role Permissions Updated!',
                showConfirmButton: false,
                timer: 1500,
              });
            } catch (err: any) {
              Swal.fire({ icon: 'error', title: 'Error', text: err.message });
            }
          }}
        />
      </div>

      {/* Database Backup & Restore */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-700 pb-3">
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          <span>JSON Database Backup & Recovery</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={exportBackup}
            className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all flex items-center gap-3 text-left cursor-pointer"
          >
            <Download className="w-6 h-6 text-[#3271a8]" />
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-100">Export System Backup</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Download JSON snapshot of products, sales, and settings</p>
            </div>
          </button>

          <label className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all flex items-center gap-3 text-left cursor-pointer">
            <Upload className="w-6 h-6 text-emerald-600" />
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-100">Restore from Backup JSON</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Upload JSON file to restore database</p>
            </div>
            <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
          </label>
        </div>
      </div>
        </>
      )}
    </div>
  );
};

