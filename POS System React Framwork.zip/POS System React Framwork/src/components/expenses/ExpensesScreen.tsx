import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import { DollarSign, Plus, Search, Trash2, X } from 'lucide-react';
import { Paginator } from '../common/Paginator';
import Swal from 'sweetalert2';

export const ExpensesScreen: React.FC = () => {
  const { expenses, refreshData, playSound, currentUser, rolePermissions } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);

  // Pagination state
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(8);

  const [formData, setFormData] = useState({
    title: '',
    categoryName: 'Facility Rent',
    amount: 100,
    note: '',
  });

  const filtered = (expenses || []).filter(
    (e) =>
      (e.title && e.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (e.categoryName && e.categoryName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createExpense({
        ...formData,
        categoryId: `expcat-${Date.now()}`,
        createdBy: currentUser?.name || 'Manager',
      });
      playSound('success');
      setShowModal(false);
      await refreshData();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Expense Recorded',
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    }
  };

  const handleDelete = async (id: string, title: string) => {
    const res = await Swal.fire({
      title: `Delete Expense "${title}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DC3545',
    });

    if (res.isConfirmed) {
      await api.deleteExpense(id);
      playSound('delete');
      await refreshData();
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Expense Removed', showConfirmButton: false, timer: 1500 });
    }
  };

  const totalExpenseAmount = expenses.reduce((a, c) => a + c.amount, 0);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-[#3271a8]" />
            <span>Operating Expense Management</span>
          </h1>
          <p className="text-xs text-slate-400">Track store rent, utilities, maintenance, and administrative costs</p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Expense</span>
        </button>
      </div>

      <div className="p-5 rounded-3xl bg-gradient-to-r from-red-500/10 to-pink-500/10 border border-red-200/80 dark:border-red-800/60 flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold text-red-700 dark:text-red-300 uppercase tracking-wider">
            Total Expense Outflow
          </p>
          <h2 className="text-3xl font-extrabold text-red-600 dark:text-red-400 mt-1">
            ${totalExpenseAmount.toFixed(2)}
          </h2>
        </div>
        <div className="text-right text-xs text-slate-500">
          <span>{expenses.length} Expense Records</span>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search expense title or category..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                <th className="p-4">Expense Title</th>
                <th className="p-4">Category</th>
                <th className="p-4">Date</th>
                <th className="p-4 text-right">Amount ($)</th>
                <th className="p-4">Recorded By</th>
                <th className="p-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No operating expense records found.
                  </td>
                </tr>
              ) : (
                filtered.slice(first, first + rows).map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                    <td className="p-4 font-bold text-slate-800 dark:text-slate-100">{e.title}</td>
                    <td className="p-4">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#3271a8]/10 text-[#3271a8]">
                        {e.categoryName}
                      </span>
                    </td>
                    <td className="p-4 text-slate-500">{e.date}</td>
                    <td className="p-4 text-right font-extrabold text-red-600">${e.amount.toFixed(2)}</td>
                    <td className="p-4 text-slate-600 dark:text-slate-300 font-medium">{e.createdBy}</td>
                    <td className="p-4 text-center">
                      {(currentUser?.role === 'Admin' || rolePermissions?.canDelete?.[currentUser?.role as 'Manager' | 'Cashier']) && (
                        <button
                          onClick={() => handleDelete(e.id, e.title)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 cursor-pointer"
                          title="Delete Expense Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Paginator
          totalRecords={filtered.length}
          rows={rows}
          first={first}
          onPageChange={(e) => {
            setFirst(e.first);
            setRows(e.rows);
          }}
          rowsPerPageOptions={[5, 8, 15, 25, 50]}
        />
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4">
              Add Store Expense
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Expense Title</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Monthly Internet Bill"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={formData.categoryName}
                    onChange={(e) => setFormData({ ...formData, categoryName: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Facility Rent">Facility Rent</option>
                    <option value="Utilities">Utilities</option>
                    <option value="Staff Salaries">Staff Salaries</option>
                    <option value="Supplies & Equipment">Supplies & Equipment</option>
                    <option value="Marketing">Marketing</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-bold text-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Note / Description</label>
                <input
                  type="text"
                  value={formData.note}
                  onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#3271a8] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25"
              >
                Save Expense
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
