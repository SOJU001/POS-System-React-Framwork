import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { BarChart3, FileSpreadsheet, FileText, Download, Calendar } from 'lucide-react';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import Swal from 'sweetalert2';

export const ReportsScreen: React.FC = () => {
  const { sales, products, expenses, settings } = usePOS();
  const [reportType, setReportType] = useState<'sales' | 'inventory' | 'expenses' | 'profit'>('sales');

  const totalSalesRevenue = (sales || []).filter((s) => s.status === 'Completed').reduce((a, c) => a + c.total, 0);
  const totalExpensesCost = (expenses || []).reduce((a, c) => a + c.amount, 0);
  const totalStockValuation = (products || []).reduce((a, c) => a + c.stock * c.purchasePrice, 0);
  const netProfitEstimated = totalSalesRevenue * 0.38 - totalExpensesCost;

  const exportCSV = () => {
    let csvData: any[] = [];
    let filename = 'report.csv';

    if (reportType === 'sales') {
      csvData = (sales || []).map((s) => ({
        Invoice: s.invoiceNo,
        Date: s.date,
        Customer: s.customerName,
        Payment: s.paymentMethod,
        Total: s.total,
        Status: s.status,
      }));
      filename = 'sales_report.csv';
    } else if (reportType === 'inventory') {
      csvData = (products || []).map((p) => ({
        Name: p.name,
        SKU: p.sku,
        Category: p.categoryName,
        Stock: p.stock,
        CostPrice: p.purchasePrice,
        SellingPrice: p.sellingPrice,
      }));
      filename = 'inventory_valuation_report.csv';
    } else if (reportType === 'expenses') {
      csvData = (expenses || []).map((e) => ({
        Title: e.title,
        Category: e.categoryName,
        Amount: e.amount,
        Date: e.date,
      }));
      filename = 'expenses_report.csv';
    }

    const worksheet = XLSX.utils.json_to_sheet(csvData);
    const csvOutput = XLSX.utils.sheet_to_csv(worksheet);
    const blob = new Blob([csvOutput], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: `Exported ${filename}`, showConfirmButton: false, timer: 1500 });
  };

  const exportExcel = () => {
    let data: any[] = [];
    if (reportType === 'sales') {
      data = sales.map((s) => ({
        Invoice: s.invoiceNo,
        Date: s.date,
        Customer: s.customerName,
        Payment: s.paymentMethod,
        TotalAmount: s.total,
        Status: s.status,
      }));
    } else if (reportType === 'inventory') {
      data = products.map((p) => ({
        ProductName: p.name,
        SKU: p.sku,
        Barcode: p.barcode,
        Category: p.categoryName,
        StockQty: p.stock,
        PurchasePrice: p.purchasePrice,
        SellingPrice: p.sellingPrice,
        Valuation: p.stock * p.purchasePrice,
      }));
    } else {
      data = expenses.map((e) => ({
        Title: e.title,
        Category: e.categoryName,
        Amount: e.amount,
        Date: e.date,
        RecordedBy: e.createdBy,
      }));
    }

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');
    XLSX.writeFile(workbook, `SmartPOS_${reportType}_report.xlsx`);

    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Excel Export Complete', showConfirmButton: false, timer: 1500 });
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text(`${settings?.companyName || 'SmartPOS'} - ${reportType.toUpperCase()} REPORT`, 14, 15);
    doc.setFontSize(10);
    doc.text(`Generated Date: ${new Date().toLocaleDateString()}`, 14, 22);

    let head: string[][] = [];
    let body: (string | number)[][] = [];

    if (reportType === 'sales') {
      head = [['Invoice #', 'Date', 'Customer', 'Payment', 'Total ($)', 'Status']];
      body = sales.map((s) => [s.invoiceNo, s.date, s.customerName, s.paymentMethod, `$${s.total.toFixed(2)}`, s.status]);
    } else if (reportType === 'inventory') {
      head = [['Product Name', 'SKU', 'Category', 'Stock', 'Cost ($)', 'Price ($)']];
      body = products.map((p) => [p.name, p.sku, p.categoryName || 'General', `${p.stock} ${p.unit}`, `$${p.purchasePrice.toFixed(2)}`, `$${p.sellingPrice.toFixed(2)}`]);
    } else {
      head = [['Title', 'Category', 'Date', 'Amount ($)', 'Created By']];
      body = expenses.map((e) => [e.title, e.categoryName, e.date, `$${e.amount.toFixed(2)}`, e.createdBy]);
    }

    autoTable(doc, {
      startY: 28,
      head,
      body,
      theme: 'grid',
    });

    doc.save(`SmartPOS_${reportType}_report.pdf`);
    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'PDF Export Downloaded', showConfirmButton: false, timer: 1500 });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-[#3271a8]" />
            <span>Reports & Data Export Hub</span>
          </h1>
          <p className="text-xs text-slate-400">Export financial summaries to Excel, CSV, and PDF formats</p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-100 font-semibold text-xs flex items-center gap-1.5"
          >
            <FileText className="w-4 h-4 text-amber-500" />
            <span>CSV</span>
          </button>
          <button
            onClick={exportExcel}
            className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel (.xlsx)</span>
          </button>
          <button
            onClick={exportPDF}
            className="px-3 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>PDF</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 dark:border-slate-700 pb-2">
        {[
          { id: 'sales', label: 'Sales Revenue' },
          { id: 'inventory', label: 'Stock Valuation' },
          { id: 'expenses', label: 'Operating Expenses' },
          { id: 'profit', label: 'Profit & Loss Summary' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setReportType(t.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              reportType === t.id
                ? 'bg-[#3271a8] text-white shadow-md'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <p className="text-xs text-slate-400 font-semibold">Total Completed Sales</p>
          <h3 className="text-xl font-extrabold text-[#3271a8] mt-1">${totalSalesRevenue.toFixed(2)}</h3>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <p className="text-xs text-slate-400 font-semibold">Stock Inventory Asset Value</p>
          <h3 className="text-xl font-extrabold text-indigo-600 mt-1">${totalStockValuation.toFixed(2)}</h3>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <p className="text-xs text-slate-400 font-semibold">Total Operating Expenses</p>
          <h3 className="text-xl font-extrabold text-red-600 mt-1">${totalExpensesCost.toFixed(2)}</h3>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <p className="text-xs text-slate-400 font-semibold">Net Operating Profit (Est.)</p>
          <h3 className="text-xl font-extrabold text-emerald-600 mt-1">${Math.max(0, netProfitEstimated).toFixed(2)}</h3>
        </div>
      </div>

      {/* Data Table Preview */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden p-4">
        <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 mb-3">
          {reportType.toUpperCase()} Preview Table
        </h3>

        {reportType === 'sales' && (
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400">
                <th className="py-2">Invoice #</th>
                <th className="py-2">Customer</th>
                <th className="py-2">Method</th>
                <th className="py-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
              {sales.map((s) => (
                <tr key={s.id}>
                  <td className="py-2 font-bold text-[#3271a8]">{s.invoiceNo}</td>
                  <td className="py-2">{s.customerName}</td>
                  <td className="py-2">{s.paymentMethod}</td>
                  <td className="py-2 text-right font-bold">${s.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {reportType === 'inventory' && (
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400">
                <th className="py-2">Product</th>
                <th className="py-2">SKU</th>
                <th className="py-2 text-center">Stock</th>
                <th className="py-2 text-right">Purchase Cost</th>
                <th className="py-2 text-right">Selling Price</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
              {products.map((p) => (
                <tr key={p.id}>
                  <td className="py-2 font-bold">{p.name}</td>
                  <td className="py-2 font-mono">{p.sku}</td>
                  <td className="py-2 text-center font-bold text-emerald-600">{p.stock}</td>
                  <td className="py-2 text-right">${p.purchasePrice.toFixed(2)}</td>
                  <td className="py-2 text-right font-bold text-[#3271a8]">${p.sellingPrice.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {(reportType === 'expenses' || reportType === 'profit') && (
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400">
                <th className="py-2">Expense Title</th>
                <th className="py-2">Category</th>
                <th className="py-2">Date</th>
                <th className="py-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
              {expenses.map((e) => (
                <tr key={e.id}>
                  <td className="py-2 font-bold">{e.title}</td>
                  <td className="py-2">{e.categoryName}</td>
                  <td className="py-2">{e.date}</td>
                  <td className="py-2 text-right font-bold text-red-600">${e.amount.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
