import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { usePOS } from '../../context/POSContext';
import { SaleReturn, Sale } from '../../types';
import { RotateCcw, Search, Plus, DollarSign, PackageCheck, FileText, X, CheckCircle2 } from 'lucide-react';
import { Paginator } from '../common/Paginator';
import Swal from 'sweetalert2';

export const ReturnsScreen: React.FC = () => {
  const { sales, refreshData, playSound } = usePOS();
  const [returnsList, setReturnsList] = useState<SaleReturn[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);

  // Pagination state
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(8);

  // Form state
  const [selectedInvoice, setSelectedInvoice] = useState('');
  const [returnReason, setReturnReason] = useState('Customer Changed Mind');
  const [refundMethod, setRefundMethod] = useState<'Cash' | 'Card' | 'Store Credit'>('Cash');

  const loadReturns = async () => {
    try {
      const data = await api.getReturns();
      setReturnsList(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadReturns();
  }, []);

  const filtered = returnsList.filter(
    (r) =>
      r.returnNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.invoiceNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.reason.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalRefundAmount = returnsList.reduce((acc, r) => acc + r.totalRefund, 0);

  const handleProcessReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetSale = sales.find((s) => s.invoiceNo === selectedInvoice || s.id === selectedInvoice);
    if (!targetSale) {
      Swal.fire({ icon: 'error', title: 'Invalid Invoice', text: 'Please select a valid completed invoice.' });
      return;
    }

    try {
      await api.refundSale(targetSale.id, returnReason, refundMethod);

      playSound('success');
      setShowModal(false);
      setSelectedInvoice('');
      await refreshData();
      await loadReturns();

      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Return Processed & Items Restocked',
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Return Failed', text: err.message });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <RotateCcw className="w-6 h-6 text-[#3271a8]" />
            <span>Sales Returns & Refund Log</span>
          </h1>
          <p className="text-xs text-slate-400">Track all customer order returns, refund payouts, and restock logs</p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Process New Return</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-gradient-to-r from-red-500/10 to-rose-500/10 border border-red-200/80 dark:border-red-800/60">
          <p className="text-xs font-semibold text-red-700 dark:text-red-300 uppercase tracking-wider">
            Total Refund Outflow
          </p>
          <h2 className="text-2xl font-extrabold text-red-600 dark:text-red-400 mt-1">
            ${totalRefundAmount.toFixed(2)}
          </h2>
          <span className="text-[10px] text-slate-400 mt-1 block">Cash & Credit Refunded</span>
        </div>

        <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-200/80 dark:border-amber-800/60">
          <p className="text-xs font-semibold text-amber-700 dark:text-amber-300 uppercase tracking-wider">
            Total Return Transactions
          </p>
          <h2 className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 mt-1">
            {returnsList.length} Returns
          </h2>
          <span className="text-[10px] text-slate-400 mt-1 block">Processed Invoices</span>
        </div>

        <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-200/80 dark:border-emerald-800/60">
          <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-300 uppercase tracking-wider">
            Stock Restock Status
          </p>
          <h2 className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1.5">
            <PackageCheck className="w-6 h-6 text-emerald-600" />
            <span>Auto-Restocked</span>
          </h2>
          <span className="text-[10px] text-slate-400 mt-1 block">Inventory Quantities Updated</span>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search return number, invoice, customer, or reason..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>
      </div>

      {/* Returns Data Table */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                <th className="p-4">Return #</th>
                <th className="p-4">Original Invoice</th>
                <th className="p-4">Date</th>
                <th className="p-4">Customer</th>
                <th className="p-4 text-right">Refund Amount</th>
                <th className="p-4">Reason</th>
                <th className="p-4 text-center">Refund Method</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No sales returns found matching your query.
                  </td>
                </tr>
              ) : (
                filtered.slice(first, first + rows).map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                    <td className="p-4 font-bold text-red-500">{r.returnNo}</td>
                    <td className="p-4 font-semibold text-[#3271a8]">{r.invoiceNo}</td>
                    <td className="p-4 text-slate-500">{r.date}</td>
                    <td className="p-4 font-medium text-slate-800 dark:text-slate-200">{r.customerName}</td>
                    <td className="p-4 text-right font-extrabold text-red-600">${r.totalRefund.toFixed(2)}</td>
                    <td className="p-4 text-slate-500">{r.reason}</td>
                    <td className="p-4 text-center">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600">
                        {r.refundMethod}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Paginator
          totalRecords={filtered.length}
          rows={rows}
          first={first}
          onPageChange={(e) => {
            setFirst(e.first);
            setRows(e.rows);
          }}
          rowsPerPageOptions={[5, 8, 15, 25, 50]}
        />
      </div>

      {/* New Return Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <RotateCcw className="w-5 h-5 text-red-500" />
              <span>Process Order Return & Refund</span>
            </h2>

            <form onSubmit={handleProcessReturn} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Select Completed Invoice</label>
                <select
                  required
                  value={selectedInvoice}
                  onChange={(e) => setSelectedInvoice(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-bold text-slate-800 dark:text-slate-100"
                >
                  <option value="">-- Choose Invoice to Refund --</option>
                  {sales
                    .filter((s) => s.status === 'Completed')
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.invoiceNo} — {s.customerName} (${s.total.toFixed(2)})
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Return Reason</label>
                <select
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                >
                  <option value="Customer Changed Mind">Customer Changed Mind</option>
                  <option value="Defective / Damaged Item">Defective / Damaged Item</option>
                  <option value="Wrong Item Purchased">Wrong Item Purchased</option>
                  <option value="Expired Product">Expired Product</option>
                  <option value="Special Return Request">Special Return Request</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Refund Payout Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Cash', 'Card', 'Store Credit'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setRefundMethod(method)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        refundMethod === method
                          ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/20'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 text-[11px] text-amber-800 dark:text-amber-300">
                <p className="font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                  <span>Automatic Restock Action:</span>
                </p>
                <p className="mt-0.5">
                  Refunding this sale will automatically revert product stock levels and record the financial refund outflow.
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg shadow-red-600/25 transition-all cursor-pointer"
              >
                Confirm & Issue Refund
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

