import React, { useState } from 'react';
import { Store } from 'lucide-react';
import { usePOS } from '../../context/POSContext';

interface BrandLogoProps {
  /** Sizing & rounding classes for the logo box (e.g. "w-10 h-10 rounded-xl") */
  className?: string;
  /** Sizing classes for the fallback icon (e.g. "w-5 h-5") */
  iconClassName?: string;
}

/**
 * Company logo used in the sidebar, navbar, and login screen.
 * Uses the settings logoUrl from the database (uploaded via Settings page).
 * Falls back to /logo.png, and finally to the Store icon if nothing is found.
 */
export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  iconClassName = 'w-5 h-5',
}) => {
  const { settings } = usePOS();
  const [imgError, setImgError] = useState(false);

  // Priority: settings.logoUrl (from DB) → /logo.png (static file) → fallback icon
  const logoSrc = settings?.logoUrl || '/logo.png';

  return (
    <div
      className={`relative shrink-0 overflow-hidden bg-gradient-to-tr from-[#3271a8] to-[#7732a8] flex items-center justify-center text-white shadow-md shadow-[#3271a8]/20 ${className}`}
    >
      {!imgError ? (
        <img
          src={logoSrc}
          alt="Company Logo"
          onError={() => setImgError(true)}
          className="w-full h-full object-contain p-1"
        />
      ) : (
        <Store className={iconClassName} />
      )}
    </div>
  );
};