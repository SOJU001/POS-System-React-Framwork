import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from 'lucide-react';

export interface PageChangeEvent {
  first: number;
  rows: number;
  page: number;
  pageCount: number;
}

interface PaginatorProps {
  totalRecords: number;
  rows: number;
  first: number;
  onPageChange: (event: PageChangeEvent) => void;
  rowsPerPageOptions?: number[];
  className?: string;
}

export const Paginator: React.FC<PaginatorProps> = ({
  totalRecords,
  rows = 10,
  first = 0,
  onPageChange,
  rowsPerPageOptions = [5, 10, 20, 50],
  className = '',
}) => {
  if (totalRecords <= 0) return null;

  const pageCount = Math.ceil(totalRecords / rows);
  const currentPage = Math.floor(first / rows);

  const handlePageClick = (pageIndex: number) => {
    if (pageIndex < 0 || pageIndex >= pageCount) return;
    const newFirst = pageIndex * rows;
    onPageChange({
      first: newFirst,
      rows,
      page: pageIndex,
      pageCount,
    });
  };

  const handleRowsChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newRows = Number(e.target.value);
    onPageChange({
      first: 0,
      rows: newRows,
      page: 0,
      pageCount: Math.ceil(totalRecords / newRows),
    });
  };

  // Generate page numbers array with intelligent ellipsis
  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisiblePages = 5;

    if (pageCount <= maxVisiblePages) {
      for (let i = 0; i < pageCount; i++) pages.push(i);
    } else {
      pages.push(0);
      if (currentPage > 2) pages.push('...');

      const start = Math.max(1, currentPage - 1);
      const end = Math.min(pageCount - 2, currentPage + 1);

      for (let i = start; i <= end; i++) {
        if (!pages.includes(i)) pages.push(i);
      }

      if (currentPage < pageCount - 3) pages.push('...');
      pages.push(pageCount - 1);
    }
    return pages;
  };

  const startRecord = totalRecords > 0 ? first + 1 : 0;
  const endRecord = Math.min(first + rows, totalRecords);

  return (
    <div className={`p-paginator p-component ${className}`}>
      {/* Left: Summary text */}
      <div className="text-xs text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1.5">
        <span>Showing</span>
        <span className="font-bold text-slate-800 dark:text-slate-200">
          {startRecord} - {endRecord}
        </span>
        <span>of</span>
        <span className="font-bold text-slate-800 dark:text-slate-200">{totalRecords}</span>
        <span>items</span>
      </div>

      {/* Center: Pagination Controls */}
      <div className="flex items-center gap-1">
        {/* First page button */}
        <button
          type="button"
          onClick={() => handlePageClick(0)}
          disabled={currentPage === 0}
          title="First Page"
          className="p-paginator-first p-paginator-element"
        >
          <ChevronsLeft className="w-4 h-4" />
        </button>

        {/* Previous page button */}
        <button
          type="button"
          onClick={() => handlePageClick(currentPage - 1)}
          disabled={currentPage === 0}
          title="Previous Page"
          className="p-paginator-prev p-paginator-element"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* Page buttons */}
        <div className="p-paginator-pages flex items-center">
          {getPageNumbers().map((p, idx) => {
            if (typeof p === 'string') {
              return (
                <span key={`ellipsis-${idx}`} className="px-1 text-slate-400 text-xs">
                  •••
                </span>
              );
            }
            const isHighlight = p === currentPage;
            return (
              <button
                key={`page-${p}`}
                type="button"
                onClick={() => handlePageClick(p)}
                className={`p-paginator-page p-paginator-element ${
                  isHighlight ? 'p-highlight' : ''
                }`}
              >
                {p + 1}
              </button>
            );
          })}
        </div>

        {/* Next page button */}
        <button
          type="button"
          onClick={() => handlePageClick(currentPage + 1)}
          disabled={currentPage >= pageCount - 1}
          title="Next Page"
          className="p-paginator-next p-paginator-element"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

        {/* Last page button */}
        <button
          type="button"
          onClick={() => handlePageClick(pageCount - 1)}
          disabled={currentPage >= pageCount - 1}
          title="Last Page"
          className="p-paginator-last p-paginator-element"
        >
          <ChevronsRight className="w-4 h-4" />
        </button>
      </div>

      {/* Right: Rows per page selection */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-500 dark:text-slate-400 font-medium hidden sm:inline">Rows per page:</span>
        <select
          value={rows}
          onChange={handleRowsChange}
          className="p-paginator-rpp-options"
        >
          {rowsPerPageOptions.map((opt) => (
            <option key={opt} value={opt}>
              {opt} / page
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
