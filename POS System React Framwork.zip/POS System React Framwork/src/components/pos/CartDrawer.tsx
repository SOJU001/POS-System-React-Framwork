import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import {
  Trash2,
  Plus,
  Minus,
  Tag,
  Percent,
  PauseCircle,
  XCircle,
  CreditCard,
  UserCheck,
  Maximize,
} from 'lucide-react';

interface Props {
  onOpenCheckout: () => void;
  onOpenSuspendModal: () => void;
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  total: number;
}

export const CartDrawer: React.FC<Props> = ({
  onOpenCheckout,
  onOpenSuspendModal,
  subtotal,
  discountAmount,
  taxAmount,
  total,
}) => {
  const {
    cart,
    removeFromCart,
    updateQuantity,
    updateItemDiscount,
    clearCart,
    selectedCustomer,
    setSelectedCustomer,
    customers,
    orderDiscount,
    setOrderDiscount,
    couponCode,
    setCouponCode,
    suspendCurrentSale,
    settings,
  } = usePOS();

  const [showCouponInput, setShowCouponInput] = useState(false);

  // Toggle full screen function
  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  return (
    <div className="w-full lg:w-96 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-xl flex flex-col justify-between overflow-hidden">
      {/* Header & Customer Picker */}
      <div className="p-4 border-b border-slate-100 dark:border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <span>Current Order</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-[#3271a8]/10 text-[#3271a8]">
              {cart.reduce((a, c) => a + c.quantity, 0)} Items
            </span>
          </h2>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={toggleFullScreen}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              title="Toggle Full Screen POS"
            >
              <Maximize className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenSuspendModal}
              className="p-1.5 rounded-xl text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-xs font-semibold flex items-center gap-1"
              title="View Suspended Held Sales"
            >
              <PauseCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Hold</span>
            </button>
            <button
              onClick={clearCart}
              disabled={cart.length === 0}
              className="p-1.5 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors disabled:opacity-30 cursor-pointer"
              title="Clear Cart"
            >
              <XCircle className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Customer Select Dropdown */}
        <div className="flex items-center gap-2">
          <div className="flex-1 relative">
            <UserCheck className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <select
              value={selectedCustomer?.id || ''}
              onChange={(e) => {
                const found = customers.find((c) => c.id === e.target.value);
                if (found) setSelectedCustomer(found);
              }}
              className="w-full pl-9 pr-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
            >
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.tier} • {c.points} pts)
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Cart Items List */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 max-h-[calc(100vh-380px)]">
        {cart.length === 0 ? (
          <div className="py-12 text-center text-slate-400 space-y-2">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400">
              <Tag className="w-6 h-6" />
            </div>
            <p className="text-xs font-medium">Cart is currently empty</p>
            <p className="text-[11px] text-slate-400">Click products or scan barcode to add</p>
          </div>
        ) : (
          cart.map((item) => {
            const originalLineTotal = item.product.sellingPrice * item.quantity;
            const itemDiscountPercent = item.discount || 0;
            const unitPriceAfterDisc = item.product.sellingPrice * (1 - itemDiscountPercent / 100);
            const discountedLineTotal = unitPriceAfterDisc * item.quantity;

            return (
              <div
                key={item.product.id}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-700/40 border border-slate-100 dark:border-slate-700 flex flex-col gap-2.5 group transition-all"
              >
                {/* Item Top Row: Info & Price */}
                <div className="flex items-center justify-between gap-3">
                  <img
                    src={item.product.image || 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300'}
                    alt={item.product.name}
                    className="w-10 h-10 rounded-xl object-cover shrink-0"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300';
                    }}
                  />

                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                      {item.product.name}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      ${(item.product?.sellingPrice || 0).toFixed(2)} / {item.product?.unit || 'pcs'}
                    </p>
                  </div>

                  {/* Line Total & Remove Button */}
                  <div className="text-right shrink-0 flex items-center gap-2">
                    <div>
                      {itemDiscountPercent > 0 ? (
                        <div>
                          <span className="text-[10px] text-slate-400 line-through block">
                            ${originalLineTotal.toFixed(2)}
                          </span>
                          <p className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                            ${discountedLineTotal.toFixed(2)}
                          </p>
                        </div>
                      ) : (
                        <p className="text-xs font-bold text-[#3271a8]">${discountedLineTotal.toFixed(2)}</p>
                      )}
                    </div>

                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-slate-400 hover:text-red-500 transition-colors p-1 cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Item Bottom Controls: Direct Inline Quantity & Inline Discount Inputs (No Popup) */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-xs">
                  {/* Quantity Control Input */}
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase">Qty:</span>
                    <div className="flex items-center bg-white dark:bg-slate-800 rounded-xl p-0.5 border border-slate-200 dark:border-slate-600">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                        title="Decrease Quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateQuantity(item.product.id, Math.max(1, Number(e.target.value)))}
                        className="w-8 text-center text-xs font-bold text-slate-800 dark:text-slate-100 bg-transparent outline-none"
                      />
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                        title="Increase Quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Inline Direct Item Discount Input (% Off) */}
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase flex items-center gap-0.5">
                      <Percent className="w-2.5 h-2.5 text-emerald-600" />
                      Disc%:
                    </span>
                    <div className="flex items-center bg-white dark:bg-slate-800 rounded-xl p-0.5 border border-slate-200 dark:border-slate-600">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="0"
                        value={itemDiscountPercent === 0 ? '' : itemDiscountPercent}
                        onChange={(e) => {
                          const val = Math.min(100, Math.max(0, Number(e.target.value)));
                          updateItemDiscount(item.product.id, val);
                        }}
                        className="w-10 text-center text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-transparent outline-none"
                      />
                      <span className="text-[10px] font-extrabold pr-1 text-slate-400">%</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Summary Totals & Actions */}
      <div className="p-4 border-t border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 space-y-3">
        {/* Order-level direct inline discount input (No Popup) */}
        <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-[#3271a8]" />
              <span>Order Discount (%)</span>
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {orderDiscount > 0 ? `-${orderDiscount}% Applied` : 'Direct Input'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex-1 relative">
              <input
                type="number"
                min="0"
                max="100"
                placeholder="0"
                value={orderDiscount === 0 ? '' : orderDiscount}
                onChange={(e) => setOrderDiscount(Math.min(100, Math.max(0, Number(e.target.value))))}
                className="w-full px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-[#3271a8]"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">%</span>
            </div>

            {/* Quick Discount Presets */}
            <div className="flex gap-1">
              {[0, 5, 10, 15, 20].map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() => setOrderDiscount(pct)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                    orderDiscount === pct
                      ? 'bg-[#3271a8] text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {pct}%
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Totals Breakdown */}
        <div className="space-y-1 text-xs">
          <div className="flex justify-between text-slate-500">
            <span>Subtotal:</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200">${subtotal.toFixed(2)}</span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600 font-semibold">
              <span>Order Discount:</span>
              <span>-${discountAmount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between text-slate-500">
            <span>VAT / Tax ({settings?.taxRate || 10}%):</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200">${taxAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-base font-extrabold text-slate-900 dark:text-slate-100 pt-1 border-t border-slate-200 dark:border-slate-700">
            <span>Payable Total:</span>
            <span className="text-[#3271a8]">${total.toFixed(2)}</span>
          </div>
        </div>

        {/* Action Checkout Button */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => suspendCurrentSale()}
            disabled={cart.length === 0}
            className="py-2.5 px-3 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-400 font-semibold text-xs border border-amber-500/30 transition-all disabled:opacity-40"
          >
            Hold Order
          </button>

          <button
            onClick={onOpenCheckout}
            disabled={cart.length === 0}
            className="py-2.5 px-3 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25 flex items-center justify-center gap-1.5 transition-all disabled:opacity-40 cursor-pointer"
          >
            <CreditCard className="w-4 h-4" />
            <span>Pay ${total.toFixed(2)}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

