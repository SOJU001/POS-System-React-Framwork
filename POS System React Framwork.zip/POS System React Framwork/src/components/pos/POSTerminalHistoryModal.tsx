import React, { useState } from 'react';
import { Sale } from '../../types';
import { usePOS } from '../../context/POSContext';
import { Paginator } from '../common/Paginator';
import {
  X,
  History,
  Search,
  Printer,
  Eye,
  CheckCircle2,
  Calendar,
  CreditCard,
  User,
  ShoppingBag,
  RotateCcw,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onReprintReceipt: (sale: Sale) => void;
}

export const POSTerminalHistoryModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onReprintReceipt,
}) => {
  const { sales } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);

  // Pagination state
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(5);

  if (!isOpen) return null;

  // Filter sales
  const filteredSales = (sales || []).filter((s) => {
    const query = searchTerm.toLowerCase();
    return (
      s.invoiceNo.toLowerCase().includes(query) ||
      (s.customerName && s.customerName.toLowerCase().includes(query)) ||
      (s.cashierName && s.cashierName.toLowerCase().includes(query)) ||
      s.paymentMethod.toLowerCase().includes(query)
    );
  });

  const paginatedSales = filteredSales.slice(first, first + rows);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-800 rounded-3xl w-full max-w-4xl shadow-2xl border border-slate-200 dark:border-slate-700 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-[#3271a8]/10 text-[#3271a8]">
              <History className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                Terminal Sales History
              </h2>
              <p className="text-xs text-slate-400">
                View past terminal transactions and reprint receipts on demand
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Controls */}
        <div className="p-4 bg-slate-50/50 dark:bg-slate-900/30 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setFirst(0);
              }}
              placeholder="Search invoice #, customer, cashier, payment..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-[#3271a8]"
            />
          </div>

          <div className="text-xs text-slate-500 font-semibold">
            Total Sales: <span className="text-[#3271a8]">{filteredSales.length}</span>
          </div>
        </div>

        {/* Content area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredSales.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-2">
              <ShoppingBag className="w-12 h-12 mx-auto opacity-40" />
              <p className="text-sm font-semibold">No transaction records found</p>
              <p className="text-xs">Completed POS sales will be logged here.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50 dark:bg-slate-900/40">
                    <th className="p-3">Invoice #</th>
                    <th className="p-3">Date & Time</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Payment</th>
                    <th className="p-3 text-right">Amount</th>
                    <th className="p-3 text-center">Status</th>
                    <th className="p-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
                  {paginatedSales.map((sale) => (
                    <tr
                      key={sale.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                    >
                      <td className="p-3 font-mono font-bold text-[#3271a8]">
                        {sale.invoiceNo}
                      </td>
                      <td className="p-3 text-slate-500 font-mono">{sale.date}</td>
                      <td className="p-3 font-medium text-slate-800 dark:text-slate-200">
                        {sale.customerName}
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-300">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 font-semibold text-[10px]">
                          {sale.paymentMethod}
                        </span>
                      </td>
                      <td className="p-3 text-right font-extrabold text-slate-900 dark:text-slate-100">
                        ${(sale.total || 0).toFixed(2)}
                      </td>
                      <td className="p-3 text-center">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                          {sale.status}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setSelectedSale(selectedSale?.id === sale.id ? null : sale)}
                            title="View Items Breakdown"
                            className="p-1.5 rounded-lg text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-950/40 cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              onReprintReceipt(sale);
                              onClose();
                            }}
                            title="Print Receipt Again"
                            className="px-3 py-1 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-[11px] shadow-sm flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Print Again</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Details drawer for selected sale */}
          {selectedSale && (
            <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                    Items in Invoice {selectedSale.invoiceNo}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({selectedSale.items?.length || 0} line items)
                  </span>
                </div>
                <button
                  onClick={() => setSelectedSale(null)}
                  className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-semibold"
                >
                  Close Details
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {(selectedSale.items || []).map((item, idx) => {
                  const price = item.product?.sellingPrice || 0;
                  const itemDiscount = item.discount || 0;
                  const discountedPrice = price * (1 - itemDiscount / 100);
                  const total = discountedPrice * (item.quantity || 1);

                  return (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between"
                    >
                      <div>
                        <p className="font-bold text-slate-800 dark:text-slate-100">
                          {item.product?.name || 'Product'}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {item.quantity || 1} x ${discountedPrice.toFixed(2)}{' '}
                          {itemDiscount > 0 && (
                            <span className="text-emerald-600 font-bold">
                              (-{itemDiscount}% item disc)
                            </span>
                          )}
                        </p>
                      </div>
                      <span className="font-extrabold text-[#3271a8]">
                        ${total.toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Paginator Component Footer */}
        <Paginator
          totalRecords={filteredSales.length}
          rows={rows}
          first={first}
          onPageChange={(e) => {
            setFirst(e.first);
            setRows(e.rows);
          }}
          rowsPerPageOptions={[5, 10, 20]}
        />
      </div>
    </div>
  );
};
