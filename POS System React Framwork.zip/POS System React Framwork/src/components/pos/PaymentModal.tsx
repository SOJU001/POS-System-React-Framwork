import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { PaymentMethodType, Sale } from '../../types';
import { api } from '../../services/api';
import { BrandLogo } from '../common/BrandLogo';
import {
  Banknote,
  QrCode,
  CreditCard,
  Building2,
  Split,
  CheckCircle2,
  X,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import Swal from 'sweetalert2';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (sale: Sale) => void;
  subtotal: number;
  discount: number;
  tax: number;
  taxAmount: number;
  total: number;
}

export const PaymentModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onPaymentSuccess,
  subtotal,
  discount,
  tax,
  taxAmount,
  total,
}) => {
  const {
    cart,
    clearCart,
    selectedCustomer,
    currentUser,
    settings,
    refreshData,
    playSound,
  } = usePOS();

  const [method, setMethod] = useState<PaymentMethodType>('Cash');
  const [payCurrency, setPayCurrency] = useState<'USD' | 'KHR'>('USD');
  const [cashTendered, setCashTendered] = useState<number>(Math.ceil(total));
  const [refNumber, setRefNumber] = useState<string>('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const khrRate = settings?.khrExchangeRate || 4100;
  const totalInKHR = Math.round(total * khrRate);

  // cashTendered is always stored in the ACTIVE currency (USD or KHR)
  const tenderedUSD = payCurrency === 'KHR' ? cashTendered / khrRate : cashTendered;
  const changeUSD = Math.max(0, tenderedUSD - total);
  const changeInCurrency = payCurrency === 'KHR' ? Math.round(changeUSD * khrRate) : changeUSD;

  const fmt = (amount: number, cur: 'USD' | 'KHR' = payCurrency) =>
    cur === 'KHR' ? `៛${Math.round(amount).toLocaleString()}` : `$${Number(amount).toFixed(2)}`;

  const switchCurrency = (cur: 'USD' | 'KHR') => {
    if (cur === payCurrency) return;
    setCashTendered((prev) =>
      cur === 'KHR' ? Math.round(prev * khrRate) : Number((prev / khrRate).toFixed(2))
    );
    setPayCurrency(cur);
    playSound('beep');
  };

  const quickCashOptions = (payCurrency === 'KHR'
    ? [
        Math.ceil(totalInKHR),
        Math.ceil(totalInKHR / 1000) * 1000,
        Math.ceil(totalInKHR / 5000) * 5000,
        Math.ceil(totalInKHR / 10000) * 10000,
        50000,
        100000,
      ]
    : [total, Math.ceil(total), Math.ceil(total / 5) * 5, Math.ceil(total / 10) * 10, 50, 100]
  ).filter(
    (v, i, a) => v >= (payCurrency === 'KHR' ? totalInKHR : total) && a.indexOf(v) === i
  );

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleCheckout = async () => {
    if (method === 'Cash' && cashTendered < (payCurrency === 'KHR' ? totalInKHR : total)) {
      Swal.fire({
        icon: 'warning',
        title: 'Insufficient Cash Tendered',
        text: `Amount paid (${fmt(cashTendered)}) is less than total bill (${fmt(
          payCurrency === 'KHR' ? totalInKHR : total
        )}).`,
        confirmButtonColor: '#3271a8',
      });
      return;
    }

    setLoading(true);
    try {
      const saleData: Partial<Sale> = {
        customerId: selectedCustomer?.id || 'cust-1',
        customerName: selectedCustomer?.name || 'Walk-in Customer',
        cashierId: currentUser?.id || 'usr-1',
        cashierName: currentUser?.name || 'Cashier',
        items: cart,
        subtotal,
        discount,
        tax,
        taxAmount,
        total,
        paymentMethod: method,
        paymentDetails: {
          method,
          currency: method === 'Cash' ? payCurrency : 'USD',
          amountPaid: method === 'Cash' ? Number(tenderedUSD.toFixed(2)) : total,
          change: method === 'Cash' ? Number(changeUSD.toFixed(2)) : 0,
          referenceNumber: refNumber || `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
        },
      };

      const completedSale = await api.createSale(saleData);
      playSound('success');
      triggerConfetti();
      clearCart();
      await refreshData();
      onPaymentSuccess(completedSale);
      onClose();
    } catch (err: any) {
      Swal.fire({
        icon: 'error',
        title: 'Checkout Failed',
        text: err.message || 'Error processing transaction.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-xl shadow-2xl border border-slate-100 dark:border-slate-700 relative animate-in fade-in zoom-in duration-200 my-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-700 mb-5">
          <div className="flex items-center gap-3">
            <div className="hidden sm:block">
              <BrandLogo className="w-10 h-10 rounded-xl" iconClassName="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Checkout & Payment</h2>
              <p className="text-xs text-slate-400">{settings?.companyName || 'SmartPOS'} • Select payment method</p>
            </div>
          </div>
          <div className="text-right flex flex-col items-end gap-1">
            <span className="text-xs font-medium text-slate-400">Total Payable</span>
            <p className="text-2xl font-extrabold text-[#3271a8]">
              {payCurrency === 'KHR' ? `៛${totalInKHR.toLocaleString()}` : `$${total.toFixed(2)}`}
            </p>
            <p className="text-[11px] text-slate-400">
              {payCurrency === 'KHR' ? `≈ $${total.toFixed(2)}` : `≈ ៛${totalInKHR.toLocaleString()}`}
            </p>
            {/* Currency selector */}
            <div className="mt-1 inline-flex rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 text-[11px] font-bold">
              <button
                type="button"
                onClick={() => switchCurrency('USD')}
                className={`px-3 py-1.5 transition-all ${
                  payCurrency === 'USD'
                    ? 'bg-[#3271a8] text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                USD
              </button>
              <button
                type="button"
                onClick={() => switchCurrency('KHR')}
                className={`px-3 py-1.5 transition-all ${
                  payCurrency === 'KHR'
                    ? 'bg-[#3271a8] text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                KHR
              </button>
            </div>
          </div>
        </div>

        {/* Payment Methods Grid */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          {[
            { id: 'Cash', label: 'Cash', icon: Banknote, color: 'text-emerald-500' },
            { id: 'ABA Pay', label: 'ABA Pay', icon: QrCode, color: 'text-blue-500' },
            { id: 'Credit Card', label: 'Card', icon: CreditCard, color: 'text-purple-500' },
            { id: 'Bank Transfer', label: 'Bank', icon: Building2, color: 'text-amber-500' },
          ].map((m) => {
            const Icon = m.icon;
            const isSelected = method === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id as PaymentMethodType)}
                className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                  isSelected
                    ? 'border-[#3271a8] bg-[#3271a8]/10 text-[#3271a8] font-bold shadow-sm'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50'
                }`}
              >
                <Icon className={`w-5 h-5 ${m.color}`} />
                <span className="text-xs">{m.label}</span>
              </button>
            );
          })}
        </div>

        {/* Payment Method Details Panel */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700 mb-6">
          {method === 'Cash' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Amount Tendered ({payCurrency === 'KHR' ? '៛ KHR' : '$ USD'})
                </label>
                <span className="text-xs text-slate-500">Quick preset cash buttons</span>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {quickCashOptions.map((amount, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setCashTendered(amount)}
                    className={`py-2 px-1 rounded-xl text-xs font-bold transition-all ${
                      cashTendered === amount
                        ? 'bg-[#3271a8] text-white shadow-md'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-[#3271a8]'
                    }`}
                  >
                    {payCurrency === 'KHR' ? `៛${amount.toLocaleString()}` : `$${amount.toFixed(2)}`}
                  </button>
                ))}
              </div>

              <input
                type="number"
                step={payCurrency === 'KHR' ? 100 : 0.01}
                min="0"
                value={cashTendered}
                onChange={(e) => setCashTendered(Number(e.target.value) || 0)}
                placeholder={payCurrency === 'KHR' ? '0 ៛' : '0.00'}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-lg font-bold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
              />

              <div className="flex justify-between items-center pt-2 border-t border-slate-200 dark:border-slate-700">
                <span className="text-xs font-semibold text-slate-500">Change Due:</span>
                <span className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">
                  {payCurrency === 'KHR'
                    ? `៛${changeInCurrency.toLocaleString()}`
                    : `$${changeInCurrency.toFixed(2)}`}
                </span>
              </div>
              {payCurrency === 'KHR' && (
                <p className="text-[11px] text-slate-400 text-right -mt-1">≈ ${changeUSD.toFixed(2)} USD</p>
              )}
            </div>
          )}

          {method === 'ABA Pay' && (
            <div className="text-center space-y-3 py-2">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                Scan ABA PAY KHQR Code to Complete Payment
              </p>
              <div className="w-40 h-40 mx-auto bg-white p-3 rounded-2xl shadow-md border border-slate-200 flex flex-col items-center justify-center">
                <QrCode className="w-28 h-28 text-slate-800" />
                <span className="text-[10px] font-bold text-blue-600 mt-1">ABA PAY KHQR</span>
              </div>
              <p className="text-[11px] text-slate-400">Merchant: {settings?.companyName}</p>
            </div>
          )}

          {(method === 'Credit Card' || method === 'Bank Transfer') && (
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Transaction Reference / Authorization Code
              </label>
              <input
                type="text"
                value={refNumber}
                onChange={(e) => setRefNumber(e.target.value)}
                placeholder="e.g. TXN-98234102"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
              />
              <p className="text-[11px] text-slate-400">
                Swipe card on POS terminal or enter bank transfer confirmation receipt ID.
              </p>
            </div>
          )}
        </div>

        {/* Action Button */}
        <button
          onClick={handleCheckout}
          disabled={loading}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#3271a8] to-[#7732a8] hover:opacity-90 text-white font-bold text-sm shadow-xl shadow-[#3271a8]/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
        >
          {loading ? (
            <span className="inline-block w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <CheckCircle2 className="w-5 h-5" />
              <span>
                Complete Payment (
                {payCurrency === 'KHR' ? `៛${totalInKHR.toLocaleString()}` : `$${total.toFixed(2)}`})
              </span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
