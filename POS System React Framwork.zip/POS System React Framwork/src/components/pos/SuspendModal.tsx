import React from 'react';
import { usePOS } from '../../context/POSContext';
import { PauseCircle, Play, Trash2, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const SuspendModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { suspendedSales, resumeSuspendedSale, deleteSuspendedSale } = usePOS();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-100 dark:border-slate-700 relative animate-in fade-in zoom-in duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-600">
            <PauseCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Held / Suspended Orders</h3>
            <p className="text-xs text-slate-400">Resume saved customer sales</p>
          </div>
        </div>

        <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
          {suspendedSales.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">No held orders found.</p>
          ) : (
            suspendedSales.map((item) => {
              const itemTotal = item.items.reduce((a, c) => a + c.product.sellingPrice * c.quantity, 0);
              return (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-700/50 border border-slate-200/80 dark:border-slate-600 flex items-center justify-between gap-3"
                >
                  <div>
                    <span className="text-xs font-bold text-[#3271a8]">{item.reference}</span>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                      {item.customer?.name || 'Walk-in Customer'} • {item.items.length} items
                    </p>
                    <p className="text-[11px] text-slate-400">Time: {item.date}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold text-slate-900 dark:text-slate-100 mr-2">
                      ${itemTotal.toFixed(2)}
                    </span>
                    <button
                      onClick={() => {
                        resumeSuspendedSale(item.id);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1 shadow-sm"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Resume</span>
                    </button>
                    <button
                      onClick={() => deleteSuspendedSale(item.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
