import React, { useState } from 'react';
import { Camera, X, Barcode, CheckCircle2 } from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import Swal from 'sweetalert2';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const BarcodeScannerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { products, addToCart } = usePOS();
  const [manualCode, setManualCode] = useState('');

  if (!isOpen) return null;

  const handleScanSubmit = (codeToScan: string) => {
    const matched = products.find(
      (p) => p.barcode === codeToScan.trim() || p.sku.toLowerCase() === codeToScan.trim().toLowerCase()
    );

    if (matched) {
      addToCart(matched, 1);
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: `Scanned: ${matched.name}`,
        showConfirmButton: false,
        timer: 1500,
      });
      setManualCode('');
      onClose();
    } else {
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'warning',
        title: 'Barcode Not Found',
        text: `No product matching code "${codeToScan}"`,
        showConfirmButton: false,
        timer: 2000,
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative animate-in fade-in zoom-in duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-2xl bg-[#3271a8]/10 text-[#3271a8]">
            <Barcode className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Barcode / QR Scanner</h3>
            <p className="text-xs text-slate-400">Point scanner or type code to add item</p>
          </div>
        </div>

        {/* Simulated Camera Viewfinder */}
        <div className="relative w-full h-48 bg-slate-900 rounded-2xl overflow-hidden mb-4 border-2 border-dashed border-[#3271a8]/50 flex flex-col items-center justify-center text-slate-400">
          <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-0.5 bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse" />
          <Camera className="w-10 h-10 mb-2 opacity-50" />
          <p className="text-xs text-slate-300 font-medium">Camera Scanner Active</p>
          <p className="text-[10px] text-slate-500">Align barcode inside the box</p>
        </div>

        {/* Manual Code Input */}
        <div className="space-y-3">
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Manual Barcode Entry / Simulated USB Scanner
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              autoFocus
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleScanSubmit(manualCode);
                }
              }}
              placeholder="e.g. 8801234567891 or AUDIO-NC-900"
              className="flex-1 px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
            />
            <button
              type="button"
              onClick={() => handleScanSubmit(manualCode)}
              className="px-4 py-2.5 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs transition-colors"
            >
              Scan
            </button>
          </div>

          <p className="text-[11px] text-slate-400 italic">
            Quick demo barcodes: <code className="bg-slate-100 dark:bg-slate-700 px-1 py-0.5 rounded text-slate-700 dark:text-slate-200 font-mono">8801234567891</code> or <code className="bg-slate-100 dark:bg-slate-700 px-1 py-0.5 rounded text-slate-700 dark:text-slate-200 font-mono">8801234567893</code>
          </p>
        </div>
      </div>
    </div>
  );
};
