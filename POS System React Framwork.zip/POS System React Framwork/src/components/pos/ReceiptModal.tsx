import React from 'react';
import { Sale } from '../../types';
import { usePOS } from '../../context/POSContext';
import { Printer, Download, Image as ImageIcon, X } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { toPng } from 'html-to-image';
import Swal from 'sweetalert2';

interface Props {
  sale: Sale | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptModal: React.FC<Props> = ({ sale, isOpen, onClose }) => {
  const { settings } = usePOS();

  if (!isOpen || !sale) return null;

  const handlePrint = () => {
    window.print();
  };

  const itemsList = sale.items || [];
  const discountAmt = sale.discountAmount ?? (((sale.subtotal || 0) * ((sale.discount || 0) / 100)) || 0);
  const amountPaid = sale.paymentDetails?.amountPaid ?? sale.total ?? 0;
  const changeDue = sale.paymentDetails?.change ?? 0;

  // KHR (Cambodian Riel) conversion using the configurable exchange rate from Settings
  const khrRate = settings?.khrExchangeRate || 4100;
  const toKHR = (usd: number) => Math.round(usd * khrRate);
  const fmtKHR = (usd: number) => toKHR(usd).toLocaleString('en-US') + ' ៛';

  // Calculate item discounts total
  const totalItemDiscounts = itemsList.reduce((acc, item) => {
    const origLine = (item.product?.sellingPrice || 0) * (item.quantity || 1);
    const discPct = item.discount || 0;
    const itemSavings = origLine * (discPct / 100);
    return acc + itemSavings;
  }, 0);

  const rawSubtotal = itemsList.reduce((acc, item) => acc + (item.product?.sellingPrice || 0) * (item.quantity || 1), 0);

  const handleDownloadPhoto = async () => {
    const node = document.getElementById('printable-receipt');
    if (!node) return;
    try {
      const dataUrl = await toPng(node, {
        quality: 0.95,
        cacheBust: true,
        skipFonts: true,
        fontEmbedCSS: '',
      });
      const link = document.createElement('a');
      link.download = `${sale.invoiceNo || 'receipt'}_receipt.png`;
      link.href = dataUrl;
      link.click();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Receipt Photo Downloaded!',
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (err) {
      console.error(err);
      Swal.fire({ icon: 'error', title: 'Export Failed', text: 'Unable to capture receipt image.' });
    }
  };

  const handleDownloadPDF = async () => {
    const doc = new jsPDF({
      unit: 'mm',
      format: [80, 220],
    });

    // Try to add logo image to PDF
    const logoSrc = settings?.logoUrl || '/logo.png';
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      const imgData = await new Promise<string>((resolve, reject) => {
        img.onload = () => {
          try {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            ctx?.drawImage(img, 0, 0);
            resolve(canvas.toDataURL('image/png'));
          } catch (e) {
            reject(e);
          }
        };
        img.onerror = reject;
        img.src = logoSrc;
      });
      doc.addImage(imgData, 'PNG', 32, 2, 16, 16);
    } catch {
      // Logo not available — skip, just use text
    }

    doc.setFontSize(10);
    doc.text(settings?.companyName || 'SmartPOS Store', 40, 22, { align: 'center' });
    doc.setFontSize(7);
    doc.text(settings?.address || '123 Tech Avenue', 40, 26, { align: 'center' });
    doc.text(`Invoice: ${sale.invoiceNo || ''}`, 40, 30, { align: 'center' });
    doc.text(`Date: ${sale.date || ''}`, 40, 34, { align: 'center' });

    const tableData = itemsList.map((i) => {
      const origPrice = i.product?.sellingPrice || 0;
      const discPct = i.discount || 0;
      const unitAfterDisc = origPrice * (1 - discPct / 100);
      const lineNet = unitAfterDisc * (i.quantity || 1);
      return [
        i.product?.name || 'Item',
        (i.quantity || 1).toString(),
        `$${origPrice.toFixed(2)}`,
        discPct > 0 ? `${discPct}%` : '0%',
        `$${lineNet.toFixed(2)}`,
      ];
    });

    autoTable(doc, {
      startY: 38,
      head: [['Item', 'Qty', 'Price', 'Disc', 'Total']],
      body: tableData,
      styles: { fontSize: 6 },
      theme: 'plain',
    });

    const finalY = (doc as any).lastAutoTable.finalY + 4;
    doc.setFontSize(7);
    doc.text(`Gross Subtotal: $${rawSubtotal.toFixed(2)}`, 70, finalY, { align: 'right' });
    doc.text(`  (${fmtKHR(rawSubtotal)})`, 40, finalY, { align: 'left' });
    if (totalItemDiscounts > 0) {
      doc.text(`Item Discounts: -$${totalItemDiscounts.toFixed(2)}`, 70, finalY + 3.5, { align: 'right' });
      doc.text(`  (${fmtKHR(totalItemDiscounts)})`, 40, finalY + 3.5, { align: 'left' });
    }
    if ((sale.discount || 0) > 0) {
      doc.text(`Order Discount (${sale.discount}%): -$${discountAmt.toFixed(2)}`, 70, finalY + 7, { align: 'right' });
      doc.text(`  (${fmtKHR(discountAmt)})`, 40, finalY + 7, { align: 'left' });
    }
    doc.text(`Tax (${sale.tax || 0}%): $${(sale.taxAmount || 0).toFixed(2)}`, 70, finalY + 10.5, { align: 'right' });
    doc.text(`  (${fmtKHR(sale.taxAmount || 0)})`, 40, finalY + 10.5, { align: 'left' });
    doc.setFontSize(8);
    doc.text(`TOTAL: $${(sale.total || 0).toFixed(2)}`, 70, finalY + 15, { align: 'right' });
    doc.setFontSize(7);
    doc.text(`  (${fmtKHR(sale.total || 0)})`, 40, finalY + 15, { align: 'left' });
    doc.setFontSize(8);
    doc.text(`Paid (${sale.paymentMethod || 'Cash'}): $${amountPaid.toFixed(2)}`, 70, finalY + 19, { align: 'right' });
    doc.setFontSize(7);
    doc.text(`  (${fmtKHR(amountPaid)})`, 40, finalY + 19, { align: 'left' });
    doc.setFontSize(8);
    doc.text(`Change: $${changeDue.toFixed(2)}`, 70, finalY + 23, { align: 'right' });
    doc.setFontSize(7);
    doc.text(`  (${fmtKHR(changeDue)})`, 40, finalY + 23, { align: 'left' });

    doc.save(`${sale.invoiceNo || 'receipt'}.pdf`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-slate-100 dark:border-slate-700 relative my-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Printable Section */}
        <div id="printable-receipt" className="text-slate-900 bg-white p-4 rounded-xl font-mono text-xs shadow-inner border border-slate-200">
          {/* Header with Logo */}
          <div className="text-center pb-3 border-b border-dashed border-slate-300">
            <div className="flex justify-center mb-2">
              <img
                src={settings?.logoUrl || '/logo.png'}
                alt="Logo"
                className="w-12 h-12 rounded-lg object-contain bg-gradient-to-tr from-[#3271a8] to-[#7732a8] p-1"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                }}
              />
            </div>
            <h2 className="font-bold text-base tracking-tight uppercase">{settings?.companyName || 'SmartPOS Store'}</h2>
            <p className="text-[10px] text-slate-500 leading-tight">{settings?.address}</p>
            <p className="text-[10px] text-slate-500">Tel: {settings?.phone} • Tax: {settings?.vatNumber}</p>
          </div>

          {/* Meta Info */}
          <div className="py-2 border-b border-dashed border-slate-300 text-[11px] space-y-0.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Invoice:</span>
              <span className="font-semibold">{sale.invoiceNo}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Date/Time:</span>
              <span>{sale.date}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Cashier:</span>
              <span>{sale.cashierName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Customer:</span>
              <span>{sale.customerName}</span>
            </div>
          </div>

          {/* Items Table with Discounts */}
          <div className="py-2 border-b border-dashed border-slate-300">
            <table className="w-full text-left text-[10px]">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase">
                  <th className="py-1">Item</th>
                  <th className="text-center py-1">Qty</th>
                  <th className="text-right py-1">Price</th>
                  <th className="text-right py-1">Disc</th>
                  <th className="text-right py-1">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {itemsList.map((item, idx) => {
                  const origUnit = item.product?.sellingPrice || 0;
                  const discPct = item.discount || 0;
                  const unitAfterDisc = origUnit * (1 - discPct / 100);
                  const lineTotal = unitAfterDisc * (item.quantity || 1);
                  const discAmount = (origUnit - unitAfterDisc) * (item.quantity || 1);

                  return (
                    <tr key={idx} className="align-top">
                      <td className="py-1.5 font-semibold">
                        <div>{item.product?.name || 'Item'}</div>
                        {discPct > 0 && (
                          <div className="text-[9px] text-emerald-600 font-normal">
                            Orig: ${origUnit.toFixed(2)} (-${discAmount.toFixed(2)})
                          </div>
                        )}
                      </td>
                      <td className="text-center py-1.5">{item.quantity || 1}</td>
                      <td className="text-right py-1.5">${origUnit.toFixed(2)}</td>
                      <td className="text-right py-1.5 text-emerald-600 font-bold">
                        {discPct > 0 ? `${discPct}%` : '-'}
                      </td>
                      <td className="text-right py-1.5 font-bold">${lineTotal.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Detailed Totals with Discounts Breakdown */}
          <div className="py-2 border-b border-dashed border-slate-300 space-y-1 text-[11px]">
            <div className="flex justify-between text-slate-600">
              <span>Gross Subtotal:</span>
              <div className="text-right">
                <div>${rawSubtotal.toFixed(2)}</div>
                <div className="text-[9px] text-slate-400">{fmtKHR(rawSubtotal)}</div>
              </div>
            </div>

            {totalItemDiscounts > 0 && (
              <div className="flex justify-between text-emerald-600 font-medium">
                <span>Line Item Discounts:</span>
                <div className="text-right">
                  <div>-${totalItemDiscounts.toFixed(2)}</div>
                  <div className="text-[9px] text-emerald-500/70">-{fmtKHR(totalItemDiscounts)}</div>
                </div>
              </div>
            )}

            {(sale.discount || 0) > 0 && (
              <div className="flex justify-between text-emerald-600 font-medium">
                <span>Order Discount ({sale.discount}%):</span>
                <div className="text-right">
                  <div>-${discountAmt.toFixed(2)}</div>
                  <div className="text-[9px] text-emerald-500/70">-{fmtKHR(discountAmt)}</div>
                </div>
              </div>
            )}

            {(totalItemDiscounts > 0 || (sale.discount || 0) > 0) && (
              <div className="flex justify-between text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                <span>Total Savings:</span>
                <div className="text-right">
                  <div>-${(totalItemDiscounts + discountAmt).toFixed(2)}</div>
                  <div className="text-[9px] text-emerald-600/70">-{fmtKHR(totalItemDiscounts + discountAmt)}</div>
                </div>
              </div>
            )}

            <div className="flex justify-between text-slate-600 pt-0.5">
              <span>VAT / Tax ({sale.tax || 0}%):</span>
              <div className="text-right">
                <div>${(sale.taxAmount || 0).toFixed(2)}</div>
                <div className="text-[9px] text-slate-400">{fmtKHR(sale.taxAmount || 0)}</div>
              </div>
            </div>

            <div className="flex justify-between text-sm font-extrabold border-t border-slate-300 pt-1 text-slate-900">
              <span>GRAND TOTAL:</span>
              <div className="text-right">
                <div>${(sale.total || 0).toFixed(2)}</div>
                <div className="text-[10px] text-[#3271a8]">{fmtKHR(sale.total || 0)}</div>
              </div>
            </div>
          </div>

          {/* Payment Info */}
          <div className="py-2 border-b border-dashed border-slate-300 text-[11px] space-y-0.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Payment Method:</span>
              <span className="font-semibold">{sale.paymentMethod || 'Cash'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Amount Paid:</span>
              <div className="text-right">
                <div>${amountPaid.toFixed(2)}</div>
                <div className="text-[9px] text-slate-400">{fmtKHR(amountPaid)}</div>
              </div>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Change Due:</span>
              <div className="text-right">
                <div className="font-bold text-emerald-700">${changeDue.toFixed(2)}</div>
                <div className="text-[9px] text-emerald-600/70">{fmtKHR(changeDue)}</div>
              </div>
            </div>
          </div>

          {/* Barcode & Footer */}
          <div className="pt-3 text-center space-y-2">
            <div className="inline-block p-1 border border-slate-300 rounded bg-white">
              <svg className="w-48 h-8 mx-auto" viewBox="0 0 200 40">
                <rect x="10" y="5" width="3" height="30" fill="black" />
                <rect x="16" y="5" width="1" height="30" fill="black" />
                <rect x="20" y="5" width="4" height="30" fill="black" />
                <rect x="27" y="5" width="2" height="30" fill="black" />
                <rect x="32" y="5" width="5" height="30" fill="black" />
                <rect x="40" y="5" width="2" height="30" fill="black" />
                <rect x="46" y="5" width="4" height="30" fill="black" />
                <rect x="54" y="5" width="1" height="30" fill="black" />
                <rect x="60" y="5" width="6" height="30" fill="black" />
                <rect x="70" y="5" width="2" height="30" fill="black" />
                <rect x="75" y="5" width="3" height="30" fill="black" />
                <rect x="82" y="5" width="1" height="30" fill="black" />
                <rect x="86" y="5" width="5" height="30" fill="black" />
                <rect x="95" y="5" width="2" height="30" fill="black" />
                <rect x="100" y="5" width="4" height="30" fill="black" />
                <rect x="108" y="5" width="3" height="30" fill="black" />
                <rect x="115" y="5" width="2" height="30" fill="black" />
                <rect x="122" y="5" width="5" height="30" fill="black" />
                <rect x="130" y="5" width="1" height="30" fill="black" />
                <rect x="135" y="5" width="4" height="30" fill="black" />
                <rect x="142" y="5" width="2" height="30" fill="black" />
                <rect x="150" y="5" width="3" height="30" fill="black" />
                <rect x="158" y="5" width="1" height="30" fill="black" />
                <rect x="165" y="5" width="4" height="30" fill="black" />
                <rect x="175" y="5" width="2" height="30" fill="black" />
                <rect x="180" y="5" width="5" height="30" fill="black" />
              </svg>
            </div>
            <p className="text-[10px] text-slate-500">{settings?.receiptFooter || 'Thank you for shopping with us!'}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          <button
            onClick={handlePrint}
            className="py-2.5 px-2 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-[#3271a8]/20 transition-all cursor-pointer"
            title="Print Receipt"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
          <button
            onClick={handleDownloadPDF}
            className="py-2.5 px-2 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-100 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            title="Download PDF"
          >
            <Download className="w-3.5 h-3.5" />
            <span>PDF</span>
          </button>
          <button
            onClick={handleDownloadPhoto}
            className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
            title="Download Photo PNG Image"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Photo PNG</span>
          </button>
        </div>
      </div>
    </div>
  );
};
