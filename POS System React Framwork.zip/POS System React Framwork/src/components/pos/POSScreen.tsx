import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { Product, Sale } from '../../types';
import { CartDrawer } from './CartDrawer';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { PaymentModal } from './PaymentModal';
import { ReceiptModal } from './ReceiptModal';
import { SuspendModal } from './SuspendModal';
import { POSTerminalHistoryModal } from './POSTerminalHistoryModal';
import {
  Search,
  Barcode,
  Layers,
  Plus,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  History,
} from 'lucide-react';

export const POSScreen: React.FC = () => {
  const {
    products,
    categories,
    addToCart,
    cart,
    orderDiscount,
    settings,
  } = usePOS();

  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showBarcodeModal, setShowBarcodeModal] = useState<boolean>(false);
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);
  const [showReceiptModal, setShowReceiptModal] = useState<boolean>(false);
  const [showSuspendModal, setShowSuspendModal] = useState<boolean>(false);
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [lastCompletedSale, setLastCompletedSale] = useState<Sale | null>(null);

  // Filter products by category and search term
  const filteredProducts = (products || []).filter((p) => {
    const matchesCat = selectedCat === 'all' || p.categoryId === selectedCat;
    const matchesSearch =
      (p.name && p.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.sku && p.sku.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.barcode && p.barcode.includes(searchTerm));
    return matchesCat && matchesSearch;
  });

  // Calculate order subtotal, discounts, tax, and grand total
  const subtotal = (cart || []).reduce((acc, item) => {
    const priceAfterItemDiscount = item.product.sellingPrice * (1 - item.discount / 100);
    return acc + priceAfterItemDiscount * item.quantity;
  }, 0);

  const discountAmount = (subtotal * orderDiscount) / 100;
  const taxableTotal = Math.max(0, subtotal - discountAmount);
  const taxRate = settings?.taxRate || 10;
  const taxAmount = (taxableTotal * taxRate) / 100;
  const total = taxableTotal + taxAmount;

  return (
    <div className="flex flex-col lg:flex-row gap-6 p-6 min-h-[calc(100vh-80px)]">
      {/* Left Main Products View */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        {/* Top Controls: Search Bar, Barcode Scan, & Terminal History Trigger */}
        <div className="flex items-center gap-3 bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search product name, SKU, or barcode..."
              className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]/50"
            />
          </div>

          <button
            onClick={() => setShowBarcodeModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#3271a8] to-[#7732a8] text-white text-xs font-semibold shadow-md shadow-[#3271a8]/20 hover:opacity-90 transition-all cursor-pointer whitespace-nowrap"
          >
            <Barcode className="w-4 h-4" />
            <span className="hidden sm:inline">Scan Barcode</span>
          </button>

          <button
            onClick={() => setShowHistoryModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all cursor-pointer whitespace-nowrap border border-slate-200 dark:border-slate-600"
          >
            <History className="w-4 h-4 text-[#3271a8]" />
            <span className="hidden sm:inline">Terminal History</span>
          </button>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            onClick={() => setSelectedCat('all')}
            className={`px-4 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCat === 'all'
                ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/25'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 border border-slate-200/80 dark:border-slate-700'
            }`}
          >
            All Items ({(products || []).length})
          </button>

          {(categories || []).map((cat) => {
            const count = (products || []).filter((p) => p.categoryId === cat.id).length;
            const isSelected = selectedCat === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCat(cat.id)}
                className={`px-4 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/25'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 border border-slate-200/80 dark:border-slate-700'
                }`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 overflow-y-auto max-h-[calc(100vh-220px)] pr-1">
          {filteredProducts.length === 0 ? (
            <div className="col-span-full py-16 text-center text-slate-400">
              <Layers className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm font-semibold">No products found</p>
              <p className="text-xs">Try selecting another category or clear search filter</p>
            </div>
          ) : (
            filteredProducts.map((p) => {
              const isLowStock = p.stock <= p.minStock && p.stock > 0;
              const isOutOfStock = p.stock === 0;

              return (
                <div
                  key={p.id}
                  onClick={() => !isOutOfStock && addToCart(p, 1)}
                  className={`group relative bg-white dark:bg-slate-800 rounded-3xl p-3 border border-slate-200/80 dark:border-slate-700/80 shadow-sm hover:shadow-xl hover:border-[#3271a8]/50 transition-all duration-200 cursor-pointer flex flex-col justify-between ${
                    isOutOfStock ? 'opacity-60 grayscale cursor-not-allowed' : ''
                  }`}
                >
                  {/* Stock Badge */}
                  <div className="absolute top-4 left-4 z-10">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full backdrop-blur-md shadow-sm ${
                        isOutOfStock
                          ? 'bg-red-500 text-white'
                          : isLowStock
                          ? 'bg-amber-500 text-white'
                          : 'bg-emerald-500/90 text-white'
                      }`}
                    >
                      {isOutOfStock ? 'Out of Stock' : `${p.stock} ${p.unit}`}
                    </span>
                  </div>

                  {/* Image */}
                  <div className="w-full h-32 rounded-2xl overflow-hidden mb-2 bg-slate-100 dark:bg-slate-700">
                    <img
                      src={p.image || 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300'}
                      alt={p.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300';
                      }}
                    />
                  </div>

                  {/* Title & Category */}
                  <div>
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      {p.categoryName || 'General'}
                    </span>
                    <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100 line-clamp-2 leading-tight mb-1">
                      {p.name}
                    </h3>
                  </div>

                  {/* Price & Add Button */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700/60 mt-2">
                    <span className="text-sm font-extrabold text-[#3271a8]">${p.sellingPrice.toFixed(2)}</span>
                    <button
                      disabled={isOutOfStock}
                      className="w-7 h-7 rounded-xl bg-slate-100 dark:bg-slate-700 group-hover:bg-[#3271a8] group-hover:text-white text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors shadow-sm"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Right Cart Sidebar Drawer */}
      <CartDrawer
        onOpenCheckout={() => setShowPaymentModal(true)}
        onOpenSuspendModal={() => setShowSuspendModal(true)}
        subtotal={subtotal}
        discountAmount={discountAmount}
        taxAmount={taxAmount}
        total={total}
      />

      {/* Modals */}
      <BarcodeScannerModal
        isOpen={showBarcodeModal}
        onClose={() => setShowBarcodeModal(false)}
      />

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPaymentSuccess={(completedSale) => {
          setLastCompletedSale(completedSale);
          setShowReceiptModal(true);
        }}
        subtotal={subtotal}
        discount={orderDiscount}
        tax={taxRate}
        taxAmount={taxAmount}
        total={total}
      />

      <ReceiptModal
        isOpen={showReceiptModal}
        sale={lastCompletedSale}
        onClose={() => setShowReceiptModal(false)}
      />

      <SuspendModal
        isOpen={showSuspendModal}
        onClose={() => setShowSuspendModal(false)}
      />

      <POSTerminalHistoryModal
        isOpen={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
        onReprintReceipt={(sale) => {
          setLastCompletedSale(sale);
          setShowReceiptModal(true);
        }}
      />
    </div>
  );
};
