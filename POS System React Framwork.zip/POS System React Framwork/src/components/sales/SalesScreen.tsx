import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { Sale } from '../../types';
import { api } from '../../services/api';
import {
  Receipt,
  Search,
  Eye,
  RotateCcw,
  Printer,
  FileText,
  Download,
  Upload,
  Trash2,
  Clock,
  ShieldAlert,
  FileJson,
  FileSpreadsheet,
  History,
  DollarSign,
  Calendar,
} from 'lucide-react';
import { ReceiptModal } from '../pos/ReceiptModal';
import { Paginator } from '../common/Paginator';
import Swal from 'sweetalert2';

export const SalesScreen: React.FC = () => {
  const { sales, refreshData, playSound } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  // Pagination state
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(10);

  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const olderSales = (sales || []).filter((s) => {
    if (!s.date) return false;
    const t = new Date(s.date).getTime();
    return !isNaN(t) && t < sevenDaysAgo;
  });

  const totalRevenue = (sales || []).reduce((sum, s) => sum + (s.total || 0), 0);

  const filtered = (sales || []).filter(
    (s) =>
      (s.invoiceNo && s.invoiceNo.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (s.customerName && s.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (s.cashierName && s.cashierName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleRefund = async (s: Sale) => {
    if (s.status === 'Refunded') return;

    const { value: formValues } = await Swal.fire({
      title: `Process Refund for ${s.invoiceNo}`,
      html: `
        <div class="text-left text-xs space-y-3 mt-3">
          <div class="p-3 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 flex items-center justify-between text-red-900 dark:text-red-200">
            <span class="font-semibold">Refund Amount:</span>
            <span class="text-base font-extrabold text-red-600 dark:text-red-400">$${(s.total || 0).toFixed(2)}</span>
          </div>

          <div>
            <label class="block font-bold text-slate-700 dark:text-slate-200 mb-1">Reason for Refund</label>
            <input id="swal-input-reason" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#3271a8]" placeholder="e.g. Damaged product / Customer return">
          </div>

          <div>
            <label class="block font-bold text-slate-700 dark:text-slate-200 mb-1">Refund Payment Method</label>
            <select id="swal-select-method" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#3271a8]">
              <option value="Cash">Refund via Cash</option>
              <option value="ABA Pay">Refund via ABA Pay</option>
              <option value="Credit Card">Refund via Credit Card</option>
            </select>
          </div>
        </div>
      `,
      icon: 'warning',
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Issue Refund Now',
      cancelButtonText: 'Cancel',
      preConfirm: () => {
        return {
          reason: (document.getElementById('swal-input-reason') as HTMLInputElement)?.value || 'Customer return',
          method: (document.getElementById('swal-select-method') as HTMLSelectElement)?.value || 'Cash',
        };
      },
    });

    if (formValues) {
      try {
        await api.refundSale(s.id, formValues.reason, formValues.method);
        playSound('success');
        await refreshData();
        Swal.fire({
          toast: true,
          position: 'top-end',
          icon: 'success',
          title: 'Refund Processed & Stock Restored!',
          showConfirmButton: false,
          timer: 2000,
        });
      } catch (err: any) {
        Swal.fire({ icon: 'error', title: 'Refund Failed', text: err.message });
      }
    }
  };

  const handleExportCSV = () => {
    const headers = ['Invoice #', 'Date/Time', 'Customer', 'Cashier', 'Payment Method', 'Subtotal', 'Tax', 'Discount', 'Total', 'Status', 'Items'];
    const csvRows = filtered.map((s) => [
      `"${s.invoiceNo || ''}"`,
      `"${s.date || ''}"`,
      `"${(s.customerName || '').replace(/"/g, '""')}"`,
      `"${(s.cashierName || '').replace(/"/g, '""')}"`,
      `"${s.paymentMethod || ''}"`,
      (s.subtotal || 0).toFixed(2),
      (s.taxAmount || 0).toFixed(2),
      (s.discountAmount || 0).toFixed(2),
      (s.total || 0).toFixed(2),
      `"${s.status || ''}"`,
      `"${(s.items || []).map((i) => `${i.product?.name || 'Item'} (x${i.quantity || 1})`).join('; ')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...csvRows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sales_history_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleBackupSales = async () => {
    try {
      const data = await api.backupSales();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `sales_backup_${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
      playSound('success');
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Sales History Backup Downloaded!',
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Backup Failed', text: err.message });
    }
  };

  const handleRestoreBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const salesArray = Array.isArray(parsed) ? parsed : parsed.sales || [];
        if (!Array.isArray(salesArray) || salesArray.length === 0) {
          throw new Error('No valid sales records found in JSON file.');
        }

        const res = await api.restoreSales(salesArray);
        playSound('success');
        await refreshData();
        Swal.fire({
          icon: 'success',
          title: 'Sales History Restored',
          text: res.message,
        });
      } catch (err: any) {
        Swal.fire({ icon: 'error', title: 'Restore Failed', text: err.message });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleWeeklyCleanup = async () => {
    const confirm = await Swal.fire({
      title: 'Run Weekly Sales Auto-Cleanup?',
      html: `
        <div class="text-left text-xs space-y-3 mt-2">
          <p class="text-slate-600 dark:text-slate-300">
            This operation will permanently purge sales and invoice history records older than <b>7 days (1 week)</b> to maintain peak database performance.
          </p>

          <div class="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 space-y-1.5">
            <div class="flex items-center justify-between font-bold">
              <span>Records Ready to Purge:</span>
              <span class="px-2.5 py-1 rounded-lg bg-amber-200/80 dark:bg-amber-900 text-amber-900 dark:text-amber-100 font-extrabold text-xs">
                ${olderSales.length} Invoices
              </span>
            </div>
            <p class="text-[11px] text-amber-700 dark:text-amber-300 leading-relaxed">
              ⚠️ Make sure you click <b>Export CSV</b> or <b>Backup Sales (JSON)</b> first if you need long-term record archives!
            </p>
          </div>
        </div>
      `,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Delete ${olderSales.length} Old Record${olderSales.length === 1 ? '' : 's'}`,
      cancelButtonText: 'Cancel & Keep Data',
    });

    if (confirm.isConfirmed) {
      try {
        const result = await api.cleanupWeeklySales();
        playSound('success');
        await refreshData();
        Swal.fire({
          icon: 'success',
          title: 'Weekly Auto-Cleanup Completed',
          html: `<div class="text-xs text-slate-600 dark:text-slate-300 mt-1">${result.message}</div>`,
        });
      } catch (err: any) {
        Swal.fire({ icon: 'error', title: 'Cleanup Failed', text: err.message });
      }
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header and Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Receipt className="w-6 h-6 text-[#3271a8]" />
            <span>Sales & Invoice History</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            View completed transactions, print receipts, process refunds, and manage weekly retention backups
          </p>
        </div>

        {/* Action Buttons: Export, Backup, Restore, Cleanup */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            title="Export sales to CSV format"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleBackupSales}
            className="px-3.5 py-2 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-[#3271a8]/20"
            title="Download full JSON backup of sales history"
          >
            <FileJson className="w-4 h-4" />
            <span>Backup Sales (JSON)</span>
          </button>

          <label className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20">
            <Upload className="w-4 h-4" />
            <span>Restore Backup</span>
            <input type="file" accept=".json" onChange={handleRestoreBackup} className="hidden" />
          </label>

          <button
            onClick={handleWeeklyCleanup}
            className="px-3.5 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 font-bold text-xs border border-red-200 dark:border-red-900/50 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Purge transactions older than 7 days"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
            <span>Weekly Purge ({olderSales.length})</span>
          </button>
        </div>
      </div>

      {/* Overview Stats & Auto-Delete Information Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Sales Count</p>
            <p className="text-xl font-extrabold text-slate-800 dark:text-slate-100 mt-1">{(sales || []).length} Invoices</p>
          </div>
          <div className="p-3 rounded-xl bg-[#3271a8]/10 text-[#3271a8]">
            <Receipt className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Revenue Recorded</p>
            <p className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">${totalRevenue.toFixed(2)}</p>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-600">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-amber-600/10 dark:from-amber-950/30 dark:to-amber-900/20 border border-amber-200 dark:border-amber-800/50 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-[11px] font-semibold text-amber-700 dark:text-amber-300 uppercase tracking-wider">Weekly Auto-Delete Policy</p>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-1 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>Auto-deletes every 7 days ({olderSales.length} pending)</span>
            </p>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400">
            <History className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Information Banner */}
      <div className="p-4 rounded-2xl bg-sky-50 dark:bg-slate-800/80 border border-sky-200 dark:border-slate-700 text-xs text-sky-900 dark:text-sky-200 flex items-start gap-3 shadow-sm">
        <ShieldAlert className="w-5 h-5 text-[#3271a8] shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="font-bold text-slate-800 dark:text-slate-100">
            Automatic Weekly Retention & Data Backup Policy
          </p>
          <p className="text-slate-600 dark:text-slate-300">
            To ensure high system responsiveness and avoid storage bloat, sales & invoice history older than 7 days (1 week) is flagged for automatic cleanup.
            Use the <b>Export CSV</b> or <b>Backup Sales (JSON)</b> buttons above to save historical records before purging.
          </p>
        </div>
      </div>

      {/* Search Filter Bar */}
      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search invoice number, customer name, or cashier..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>
      </div>

      {/* Sales Table */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                <th className="p-4">Invoice #</th>
                <th className="p-4">Date / Time</th>
                <th className="p-4">Customer</th>
                <th className="p-4">Cashier</th>
                <th className="p-4">Payment Method</th>
                <th className="p-4 text-right">Grand Total</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No sales records found matching your query.
                  </td>
                </tr>
              ) : (
                filtered.slice(first, first + rows).map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                    <td className="p-4 font-bold text-[#3271a8]">{s.invoiceNo}</td>
                    <td className="p-4 text-slate-500">{s.date}</td>
                    <td className="p-4 font-medium text-slate-800 dark:text-slate-200">{s.customerName}</td>
                    <td className="p-4 text-slate-500">{s.cashierName}</td>
                    <td className="p-4 font-semibold text-slate-700 dark:text-slate-300">{s.paymentMethod}</td>
                    <td className="p-4 text-right font-extrabold text-slate-900 dark:text-slate-100">
                      ${(s.total || 0).toFixed(2)}
                    </td>
                    <td className="p-4 text-center">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          s.status === 'Completed'
                            ? 'bg-emerald-500/10 text-emerald-600'
                            : 'bg-red-500/10 text-red-600'
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => {
                            setSelectedSale(s);
                            setShowReceipt(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-[#3271a8] hover:bg-slate-100 dark:hover:bg-slate-700"
                          title="View / Print Receipt"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        {s.status === 'Completed' && (
                          <button
                            onClick={() => handleRefund(s)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40"
                            title="Process Refund"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Paginator
          totalRecords={filtered.length}
          rows={rows}
          first={first}
          onPageChange={(e) => {
            setFirst(e.first);
            setRows(e.rows);
          }}
          rowsPerPageOptions={[5, 10, 20, 50]}
        />
      </div>

      <ReceiptModal
        isOpen={showReceipt}
        sale={selectedSale}
        onClose={() => setShowReceipt(false)}
      />
    </div>
  );
};

