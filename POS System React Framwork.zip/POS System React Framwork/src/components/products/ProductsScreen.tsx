import React, { useState, useRef } from 'react';
import { usePOS } from '../../context/POSContext';
import { Product } from '../../types';
import { api } from '../../services/api';
import { Paginator } from '../common/Paginator';
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  X,
  Sparkles,
  Upload,
  UploadCloud,
  Image as ImageIcon,
  Link as LinkIcon,
  Eye,
  Camera,
  RefreshCw,
} from 'lucide-react';
import Swal from 'sweetalert2';

// Preset sample photos for fast selection
const SAMPLE_PRESETS = [
  { label: 'Headphones', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=400' },
  { label: 'Smartwatch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=400' },
  { label: 'Coffee Beans', url: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&q=80&w=400' },
  { label: 'Leather Wallet', url: 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&q=80&w=400' },
  { label: 'Electric Blender', url: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&q=80&w=400' },
  { label: 'Face Serum', url: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400' },
  { label: 'Keyboard', url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&q=80&w=400' },
  { label: 'Energy Drink', url: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=400' },
];

export const ProductsScreen: React.FC = () => {
  const { products, categories, refreshData, playSound, currentUser, rolePermissions } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [imageModalUrl, setImageModalUrl] = useState<string | null>(null);

  // Pagination state
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(8);

  // Photo tab mode inside form: 'upload' | 'url' | 'presets'
  const [photoSourceMode, setPhotoSourceMode] = useState<'upload' | 'url' | 'presets'>('upload');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    barcode: '',
    categoryId: '',
    brand: '',
    purchasePrice: 0,
    sellingPrice: 0,
    stock: 0,
    minStock: 5,
    unit: 'pcs',
    image: '',
    description: '',
  });

  const filtered = (products || []).filter((p) => {
    const matchCat = selectedCat === 'all' || p.categoryId === selectedCat;
    const matchSearch =
      (p.name && p.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.sku && p.sku.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.barcode && p.barcode.includes(searchTerm));
    return matchCat && matchSearch;
  });

  const openAddModal = () => {
    setEditingProduct(null);
    const randomSku = `SKU-${Math.floor(1000 + Math.random() * 9000)}`;
    const randomBarcode = `880${Math.floor(1000000000 + Math.random() * 9000000000)}`;
    setFormData({
      name: '',
      sku: randomSku,
      barcode: randomBarcode,
      categoryId: categories[0]?.id || '',
      brand: 'Generic',
      purchasePrice: 10,
      sellingPrice: 19.99,
      stock: 25,
      minStock: 5,
      unit: 'pcs',
      image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300',
      description: '',
    });
    setPhotoSourceMode('upload');
    setShowModal(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setFormData({
      name: p.name,
      sku: p.sku,
      barcode: p.barcode,
      categoryId: p.categoryId,
      brand: p.brand || '',
      purchasePrice: p.purchasePrice,
      sellingPrice: p.sellingPrice,
      stock: p.stock,
      minStock: p.minStock,
      unit: p.unit,
      image: p.image || '',
      description: p.description || '',
    });
    setPhotoSourceMode(p.image?.startsWith('data:') ? 'upload' : 'url');
    setShowModal(true);
  };

  const handleFileUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      Swal.fire({ icon: 'error', title: 'Invalid File', text: 'Please upload an image file (PNG, JPG, WEBP).' });
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      Swal.fire({ icon: 'warning', title: 'File Too Large', text: 'Please select an image smaller than 8MB.' });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setFormData((prev) => ({ ...prev, image: e.target!.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const catObj = categories.find((c) => c.id === formData.categoryId);
      const payload = {
        ...formData,
        categoryName: catObj?.name || 'General',
      };

      if (editingProduct) {
        await api.updateProduct(editingProduct.id, payload);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Product details & photo saved', showConfirmButton: false, timer: 1800 });
      } else {
        await api.createProduct(payload);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Product created & saved', showConfirmButton: false, timer: 1800 });
      }

      playSound('success');
      setShowModal(false);
      await refreshData();
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error Saving Product', text: err.message });
    }
  };

  const handleDelete = async (id: string, name: string) => {
    const result = await Swal.fire({
      title: `Delete "${name}"?`,
      text: 'This action will permanently delete the product from the database.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DC3545',
      cancelButtonColor: '#6C757D',
      confirmButtonText: 'Yes, Delete',
    });

    if (result.isConfirmed) {
      await api.deleteProduct(id);
      playSound('delete');
      await refreshData();
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Product Deleted', showConfirmButton: false, timer: 1500 });
    }
  };

  const handleGenerateAIDescription = async () => {
    if (!formData.name) {
      Swal.fire({ toast: true, position: 'top-end', icon: 'info', title: 'Please enter a product title first', showConfirmButton: false, timer: 1500 });
      return;
    }
    try {
      const catObj = categories.find((c) => c.id === formData.categoryId);
      const res = await api.getAIInsights('product_description', {
        name: formData.name,
        categoryName: catObj?.name,
      });
      setFormData((prev) => ({ ...prev, description: res.insight }));
    } catch (e) {
      // Fallback
      setFormData((prev) => ({
        ...prev,
        description: `High-quality ${formData.name} designed for long-lasting performance and maximum customer satisfaction.`,
      }));
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Package className="w-6 h-6 text-[#3271a8]" />
            <span>Product Inventory Management</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Edit product details, upload photos, track margins, and sync with persistent database
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="flex-1 relative w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by product title, SKU, or barcode..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>

        <select
          value={selectedCat}
          onChange={(e) => setSelectedCat(e.target.value)}
          className="w-full sm:w-52 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100"
        >
          <option value="all">All Categories ({categories.length})</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* Products Table */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/60 font-semibold">
                <th className="p-4">Product Photo</th>
                <th className="p-4">SKU / Barcode</th>
                <th className="p-4">Category</th>
                <th className="p-4 text-right">Cost Price</th>
                <th className="p-4 text-right">Selling Price</th>
                <th className="p-4 text-center">Margin %</th>
                <th className="p-4 text-center">Stock</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No products found matching your search.
                  </td>
                </tr>
              ) : (
                filtered.slice(first, first + rows).map((p) => {
                  const margin = p.sellingPrice > 0 ? (((p.sellingPrice - p.purchasePrice) / p.sellingPrice) * 100).toFixed(1) : '0';
                  const isLow = p.stock <= p.minStock && p.stock > 0;
                  const isOut = p.stock === 0;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div
                            onClick={() => setImageModalUrl(p.image)}
                            className="relative w-12 h-12 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-700 shrink-0 border border-slate-200 dark:border-slate-600 group cursor-pointer"
                            title="Click to view full photo"
                          >
                            <img
                              src={p.image || 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300'}
                              alt={p.name}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300';
                              }}
                            />
                            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                              <Eye className="w-4 h-4" />
                            </div>
                          </div>
                          <div>
                            <p className="font-bold text-slate-800 dark:text-slate-100">{p.name}</p>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400">{p.brand || 'No Brand'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 font-mono text-[11px] text-slate-600 dark:text-slate-300">
                        <div className="font-semibold text-slate-700 dark:text-slate-200">{p.sku}</div>
                        <div className="text-slate-400 text-[10px]">{p.barcode}</div>
                      </td>
                      <td className="p-4 font-semibold text-slate-600 dark:text-slate-300">{p.categoryName}</td>
                      <td className="p-4 text-right font-medium text-slate-500 dark:text-slate-400">${p.purchasePrice.toFixed(2)}</td>
                      <td className="p-4 text-right font-bold text-[#3271a8] dark:text-sky-400">${p.sellingPrice.toFixed(2)}</td>
                      <td className="p-4 text-center font-bold text-emerald-600 dark:text-emerald-400">{margin}%</td>
                      <td className="p-4 text-center">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            isOut
                              ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                              : isLow
                              ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                              : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                          }`}
                        >
                          {p.stock} {p.unit}
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => openEditModal(p)}
                            className="p-2 rounded-xl text-slate-500 hover:text-[#3271a8] hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                            title="Edit product & photo"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          {(currentUser?.role === 'Admin' || rolePermissions?.canDelete?.[currentUser?.role as 'Manager' | 'Cashier']) && (
                            <button
                              onClick={() => handleDelete(p.id, p.name)}
                              className="p-2 rounded-xl text-slate-500 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <Paginator
          totalRecords={filtered.length}
          rows={rows}
          first={first}
          onPageChange={(e) => {
            setFirst(e.first);
            setRows(e.rows);
          }}
          rowsPerPageOptions={[5, 8, 15, 25, 50]}
        />
      </div>

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-2xl shadow-2xl border border-slate-100 dark:border-slate-700 relative my-8">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 rounded-2xl bg-[#3271a8]/10 text-[#3271a8] dark:text-sky-400">
                <Package className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                  {editingProduct ? 'Edit Product Details & Photo' : 'Add New Product to Database'}
                </h2>
                <p className="text-xs text-slate-400">Fill in pricing, stock, description, and upload product photo</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              {/* Product Photo Upload Section */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#3271a8]" />
                    <span>Product Photo</span>
                  </label>

                  {/* Mode Selector Tabs */}
                  <div className="flex items-center gap-1 bg-slate-200/70 dark:bg-slate-800 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setPhotoSourceMode('upload')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                        photoSourceMode === 'upload'
                          ? 'bg-white dark:bg-slate-700 text-[#3271a8] dark:text-sky-300 shadow-sm'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
                      }`}
                    >
                      Upload File
                    </button>
                    <button
                      type="button"
                      onClick={() => setPhotoSourceMode('url')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                        photoSourceMode === 'url'
                          ? 'bg-white dark:bg-slate-700 text-[#3271a8] dark:text-sky-300 shadow-sm'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
                      }`}
                    >
                      Web Link URL
                    </button>
                    <button
                      type="button"
                      onClick={() => setPhotoSourceMode('presets')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                        photoSourceMode === 'presets'
                          ? 'bg-white dark:bg-slate-700 text-[#3271a8] dark:text-sky-300 shadow-sm'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
                      }`}
                    >
                      Sample Presets
                    </button>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  {/* Photo Preview Card */}
                  <div className="relative w-28 h-28 rounded-2xl overflow-hidden bg-slate-200 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 shrink-0 shadow-inner group">
                    {formData.image ? (
                      <>
                        <img
                          src={formData.image}
                          alt="Product Preview"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=300';
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, image: '' })}
                          className="absolute top-1 right-1 p-1 rounded-full bg-red-600 text-white shadow-md hover:bg-red-700 transition-colors opacity-90 hover:opacity-100"
                          title="Remove photo"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </>
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 p-2 text-center">
                        <ImageIcon className="w-8 h-8 mb-1" />
                        <span className="text-[10px]">No Photo</span>
                      </div>
                    )}
                  </div>

                  {/* Photo Input Controls */}
                  <div className="flex-1 w-full">
                    {photoSourceMode === 'upload' && (
                      <div
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        onClick={() => fileInputRef.current?.click()}
                        className={`border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-all ${
                          isDragging
                            ? 'border-[#3271a8] bg-[#3271a8]/10'
                            : 'border-slate-300 dark:border-slate-700 hover:border-[#3271a8] bg-white dark:bg-slate-800/60'
                        }`}
                      >
                        <input
                          type="file"
                          ref={fileInputRef}
                          onChange={handleFileChange}
                          accept="image/*"
                          className="hidden"
                        />
                        <UploadCloud className="w-7 h-7 text-[#3271a8] mx-auto mb-1 animate-bounce" />
                        <p className="font-bold text-slate-700 dark:text-slate-200">
                          Click to upload or drag & drop photo file
                        </p>
                        <p className="text-[10px] text-slate-400 mt-0.5">Supports PNG, JPG, WEBP or GIF (Max 8MB)</p>
                      </div>
                    )}

                    {photoSourceMode === 'url' && (
                      <div className="space-y-2">
                        <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                          Direct Image Web Address (URL)
                        </label>
                        <div className="relative">
                          <LinkIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                          <input
                            type="url"
                            value={formData.image}
                            onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                            placeholder="https://images.unsplash.com/..."
                            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-[#3271a8]"
                          />
                        </div>
                      </div>
                    )}

                    {photoSourceMode === 'presets' && (
                      <div>
                        <p className="text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-2">
                          Select a sample product photo:
                        </p>
                        <div className="grid grid-cols-4 gap-2">
                          {SAMPLE_PRESETS.map((p, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => setFormData({ ...formData, image: p.url })}
                              className="p-1 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-[#3271a8] bg-white dark:bg-slate-800 flex flex-col items-center text-center gap-1 transition-all"
                            >
                              <img src={p.url} alt={p.label} className="w-10 h-10 rounded-lg object-cover" />
                              <span className="text-[9px] font-medium text-slate-600 dark:text-slate-300 truncate w-full">
                                {p.label}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Title & Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Wireless Noise-Canceling Headphones"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-[#3271a8]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.categoryId}
                    onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-[#3271a8]"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* SKU, Barcode, Brand */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">SKU</label>
                  <input
                    type="text"
                    required
                    value={formData.sku}
                    onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Barcode</label>
                  <input
                    type="text"
                    required
                    value={formData.barcode}
                    onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Brand</label>
                  <input
                    type="text"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    placeholder="e.g. Sony, Bellroy"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              {/* Cost, Selling, Stock, Min Stock */}
              <div className="grid grid-cols-4 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Purchase Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.purchasePrice}
                    onChange={(e) => setFormData({ ...formData, purchasePrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Selling Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.sellingPrice}
                    onChange={(e) => setFormData({ ...formData, sellingPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-bold text-[#3271a8]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    required
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Min Stock Alert</label>
                  <input
                    type="number"
                    value={formData.minStock}
                    onChange={(e) => setFormData({ ...formData, minStock: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Description</label>
                  <button
                    type="button"
                    onClick={handleGenerateAIDescription}
                    className="text-[10px] font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Auto-Generate AI Copy</span>
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter product features, specs or details..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25 transition-all mt-2 cursor-pointer flex items-center justify-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>{editingProduct ? 'Save Product Details & Photo' : 'Create & Store Product'}</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Full Photo Preview Modal */}
      {imageModalUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
          onClick={() => setImageModalUrl(null)}
        >
          <div className="relative max-w-xl w-full bg-slate-900 rounded-3xl overflow-hidden p-3 shadow-2xl border border-slate-700">
            <button
              onClick={() => setImageModalUrl(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 text-white hover:bg-slate-700 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <img src={imageModalUrl} alt="Product Full View" className="w-full h-auto max-h-[75vh] object-contain rounded-2xl" />
          </div>
        </div>
      )}
    </div>
  );
};
