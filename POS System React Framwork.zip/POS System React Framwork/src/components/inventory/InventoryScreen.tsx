import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import { StockAdjustment, Product } from '../../types';
import { Paginator } from '../common/Paginator';
import {
  Boxes,
  Plus,
  Search,
  AlertTriangle,
  ArrowUpDown,
  X,
  ClipboardCheck,
  RefreshCw,
  FileText,
  TrendingDown,
  TrendingUp,
  CheckCircle2,
  DollarSign,
  Filter,
  CheckSquare,
  PackageCheck,
  ArrowRight,
  Send,
  Eye,
  Edit,
  Trash2,
  User,
  Calendar,
  Info,
} from 'lucide-react';
import Swal from 'sweetalert2';

export const InventoryScreen: React.FC = () => {
  const { products, categories, refreshData, playSound, currentUser, rolePermissions } = usePOS();
  const [adjustments, setAdjustments] = useState<StockAdjustment[]>([]);
  const [activeTab, setActiveTab] = useState<'log' | 'audit' | 'reorder'>('log');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);

  // Pagination states
  const [logFirst, setLogFirst] = useState(0);
  const [logRows, setLogRows] = useState(8);
  const [auditFirst, setAuditFirst] = useState(0);
  const [auditRows, setAuditRows] = useState(8);
  const [reorderFirst, setReorderFirst] = useState(0);
  const [reorderRows, setReorderRows] = useState(8);

  // View & Edit Modal States
  const [viewingAdjustment, setViewingAdjustment] = useState<StockAdjustment | null>(null);
  const [editingAdjustment, setEditingAdjustment] = useState<StockAdjustment | null>(null);
  const [editFormData, setEditFormData] = useState({
    productId: '',
    quantity: 0,
    type: 'Restock' as const,
    reason: '',
    adjustedBy: '',
  });

  // Physical Audit Counts state: map productId -> physicalCount
  const [auditCounts, setAuditCounts] = useState<{ [productId: string]: number }>({});
  const [isSubmittingAudit, setIsSubmittingAudit] = useState(false);

  const [formData, setFormData] = useState({
    productId: products[0]?.id || '',
    quantity: 5,
    type: 'Restock' as const,
    reason: 'New shipment received',
  });

  const loadAdjustments = async () => {
    try {
      const data = await api.getStockAdjustments();
      setAdjustments(data);
    } catch (e) {}
  };

  useEffect(() => {
    loadAdjustments();
  }, []);

  // Initialize audit counts when products load or tab changes
  useEffect(() => {
    if (products && products.length > 0) {
      const initialCounts: { [id: string]: number } = {};
      products.forEach((p) => {
        initialCounts[p.id] = p.stock;
      });
      setAuditCounts(initialCounts);
    }
  }, [products]);

  const handleSubmitAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createStockAdjustment(formData);
      playSound('success');
      setShowModal(false);
      await refreshData();
      await loadAdjustments();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Stock Adjustment Recorded',
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    }
  };

  const openEditModal = (adj: StockAdjustment) => {
    setEditingAdjustment(adj);
    setEditFormData({
      productId: adj.productId,
      quantity: adj.quantity,
      type: adj.type as any,
      reason: adj.reason,
      adjustedBy: adj.adjustedBy || 'Admin',
    });
  };

  const handleUpdateAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdjustment) return;

    try {
      await api.updateStockAdjustment(editingAdjustment.id, editFormData);
      playSound('success');
      setEditingAdjustment(null);
      await refreshData();
      await loadAdjustments();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Adjustment Log Updated Successfully',
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Update Error', text: err.message });
    }
  };

  const handleDeleteAdjustment = async (adj: StockAdjustment) => {
    const confirmRes = await Swal.fire({
      title: 'Delete Stock Adjustment Record?',
      html: `Are you sure you want to delete the audit log for <b>${adj.productName}</b> (${adj.type}, ${
        adj.quantity > 0 ? '+' : ''
      }${adj.quantity})?<br/><br/>
      <span style="color: #e11d48; font-weight: 600;">Product stock will be automatically reverted by ${
        -adj.quantity >= 0 ? '+' : ''
      }${-adj.quantity} units.</span>`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e11d48',
      confirmButtonText: 'Yes, Delete & Revert Stock',
    });

    if (!confirmRes.isConfirmed) return;

    try {
      await api.deleteStockAdjustment(adj.id);
      playSound('success');
      await refreshData();
      await loadAdjustments();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'Adjustment log deleted & product stock reverted',
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Delete Error', text: err.message });
    }
  };

  const handleAuditCountChange = (productId: string, val: number) => {
    setAuditCounts((prev) => ({
      ...prev,
      [productId]: Math.max(0, val),
    }));
  };

  const handleCommitPhysicalAudit = async () => {
    const discrepancies: { product: Product; systemStock: number; physicalStock: number; diff: number }[] = [];

    products.forEach((p) => {
      const physical = auditCounts[p.id] ?? p.stock;
      if (physical !== p.stock) {
        discrepancies.push({
          product: p,
          systemStock: p.stock,
          physicalStock: physical,
          diff: physical - p.stock,
        });
      }
    });

    if (discrepancies.length === 0) {
      Swal.fire({
        icon: 'info',
        title: 'All Stock Counts Match!',
        text: 'Physical audit counts match current system stock perfectly. No reconciliation required.',
      });
      return;
    }

    const confirmRes = await Swal.fire({
      title: `Commit Audit Reconciliation (${discrepancies.length} items)?`,
      html: `Found <b>${discrepancies.length} item discrepancies</b> between physical count and system stock.<br/><br/>
      System will automatically create audit adjustment logs and reconcile current stock.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3271a8',
      confirmButtonText: 'Yes, Reconcile Stock Now',
    });

    if (!confirmRes.isConfirmed) return;

    setIsSubmittingAudit(true);
    try {
      for (const item of discrepancies) {
        await api.createStockAdjustment({
          productId: item.product.id,
          quantity: item.diff,
          type: 'Correction',
          reason: `Physical Audit Reconciliation (System: ${item.systemStock} -> Physical: ${item.physicalStock})`,
          adjustedBy: 'Audit Manager',
        });
      }

      playSound('success');
      await refreshData();
      await loadAdjustments();

      Swal.fire({
        icon: 'success',
        title: 'Audit Reconciliation Complete!',
        text: `Successfully updated stock for ${discrepancies.length} products and recorded audit audit logs.`,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Reconciliation Error', text: err.message });
    } finally {
      setIsSubmittingAudit(false);
    }
  };

  const handleQuickRestock = async (product: Product, qty: number) => {
    try {
      await api.createStockAdjustment({
        productId: product.id,
        quantity: qty,
        type: 'Restock',
        reason: `Quick Restock Order for Low Stock Item (${product.name})`,
        adjustedBy: 'Store Staff',
      });
      playSound('success');
      await refreshData();
      await loadAdjustments();
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: `Restocked +${qty} ${product.unit} of ${product.name}!`,
        showConfirmButton: false,
        timer: 1800,
      });
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Restock Error', text: err.message });
    }
  };

  // Filtered Products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.barcode?.includes(searchTerm);
    const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Filtered Adjustments
  const filteredAdjustments = adjustments.filter((a) => {
    const matchesSearch =
      a.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.adjustedBy.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || a.type === selectedType;
    return matchesSearch && matchesType;
  });

  // Low stock items
  const lowStockProducts = products.filter((p) => p.stock <= p.minStock);
  const outOfStockProducts = products.filter((p) => p.stock === 0);
  const totalValuation = products.reduce((a, c) => a + c.stock * c.purchasePrice, 0);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Boxes className="w-6 h-6 text-[#3271a8]" />
            <span>Inventory & Stock Audit</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Audit physical inventory, track stock movements, handle write-offs, and trigger restock orders
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowModal(true)}
            className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Stock Adjustment</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-[#3271a8]/10 text-[#3271a8]">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Total Active Products</p>
            <p className="text-lg font-bold text-slate-800 dark:text-slate-100">{products.length} SKUs</p>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 shadow-sm flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-amber-700 dark:text-amber-400 font-semibold">Low Stock Threshold</p>
            <p className="text-lg font-bold text-amber-900 dark:text-amber-200">
              {lowStockProducts.length} Items Need Restock
            </p>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/80 shadow-sm flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-red-500/10 text-red-600 dark:text-red-400">
            <TrendingDown className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-red-700 dark:text-red-400 font-semibold">Out of Stock</p>
            <p className="text-lg font-bold text-red-900 dark:text-red-200">{outOfStockProducts.length} Items Critical</p>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 shadow-sm flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold">Inventory Valuation</p>
            <p className="text-lg font-bold text-emerald-900 dark:text-emerald-200">${totalValuation.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Mode Tabs & Search Controls */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-2.5 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setActiveTab('log')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'log'
                ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/20'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Stock Movement Log ({adjustments.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'audit'
                ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/20'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5" />
            <span>Physical Stock Take Audit</span>
          </button>

          <button
            onClick={() => setActiveTab('reorder')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'reorder'
                ? 'bg-[#3271a8] text-white shadow-md shadow-[#3271a8]/20'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
            <span>Low Stock Reorder Queue ({lowStockProducts.length})</span>
          </button>
        </div>

        {/* Search & Filter */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 md:w-56">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search product, SKU, note..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-100"
            />
          </div>

          {activeTab === 'log' && (
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-300 font-medium"
            >
              <option value="all">All Types</option>
              <option value="Restock">Restock</option>
              <option value="Damaged">Damaged</option>
              <option value="Correction">Correction</option>
              <option value="Transfer">Transfer</option>
            </select>
          )}

          {activeTab === 'audit' && (
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-300 font-medium"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* TAB 1: STOCK MOVEMENT LOG */}
      {activeTab === 'log' && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#3271a8]" />
              <span>Audit Log & Stock Movement Records</span>
            </h3>
            <span className="text-xs text-slate-400">Showing {filteredAdjustments.length} logs</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                  <th className="p-4">Date / Time</th>
                  <th className="p-4">Product Name</th>
                  <th className="p-4 text-center">Type</th>
                  <th className="p-4 text-center">Adjustment Qty</th>
                  <th className="p-4">Reason / Audit Note</th>
                  <th className="p-4">Adjusted By</th>
                  <th className="p-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
                {filteredAdjustments.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-slate-400">
                      No stock adjustments found matching your search.
                    </td>
                  </tr>
                ) : (
                  filteredAdjustments.slice(logFirst, logFirst + logRows).map((a) => (
                    <tr key={a.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                      <td className="p-4 font-mono text-slate-500 dark:text-slate-400">{a.date}</td>
                      <td className="p-4 font-bold text-slate-800 dark:text-slate-100">{a.productName}</td>
                      <td className="p-4 text-center">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            a.type === 'Restock'
                              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                              : a.type === 'Damaged'
                              ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                              : a.type === 'Transfer'
                              ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                              : 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                          }`}
                        >
                          {a.type}
                        </span>
                      </td>
                      <td
                        className={`p-4 text-center font-extrabold text-sm ${
                          a.quantity >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'
                        }`}
                      >
                        {a.quantity > 0 ? `+${a.quantity}` : a.quantity}
                      </td>
                      <td className="p-4 text-slate-600 dark:text-slate-300 max-w-xs truncate">{a.reason}</td>
                      <td className="p-4 text-slate-700 dark:text-slate-300 font-medium">
                        <div className="flex items-center gap-1.5">
                          <div className="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-[9px] font-bold flex items-center justify-center text-slate-600 dark:text-slate-300">
                            {a.adjustedBy ? a.adjustedBy.slice(0, 1) : 'A'}
                          </div>
                          <span>{a.adjustedBy || 'Admin'}</span>
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setViewingAdjustment(a)}
                            title="View Record Details"
                            className="p-1.5 rounded-lg text-sky-600 dark:text-sky-400 hover:bg-sky-50 dark:hover:bg-sky-950/50 transition-colors cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => openEditModal(a)}
                            title="Edit Record"
                            className="p-1.5 rounded-lg text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/50 transition-colors cursor-pointer"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          {(currentUser?.role === 'Admin' || rolePermissions?.canDelete?.[currentUser?.role as 'Manager' | 'Cashier']) && (
                            <button
                              onClick={() => handleDeleteAdjustment(a)}
                              title="Delete Record"
                              className="p-1.5 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <Paginator
            totalRecords={filteredAdjustments.length}
            rows={logRows}
            first={logFirst}
            onPageChange={(e) => {
              setLogFirst(e.first);
              setLogRows(e.rows);
            }}
            rowsPerPageOptions={[5, 8, 15, 25, 50]}
          />
        </div>
      )}

      {/* TAB 2: PHYSICAL STOCK TAKE AUDIT */}
      {activeTab === 'audit' && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <ClipboardCheck className="w-4 h-4 text-[#3271a8]" />
                <span>Physical Stock Audit & Count Sheet</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Count physical items in storage and enter quantities below to automatically detect discrepancies.
              </p>
            </div>

            <button
              onClick={handleCommitPhysicalAudit}
              disabled={isSubmittingAudit}
              className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all self-start sm:self-auto"
            >
              {isSubmittingAudit ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <PackageCheck className="w-4 h-4" />
              )}
              <span>Commit Audit Reconciliation</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                  <th className="p-4">SKU / Barcode</th>
                  <th className="p-4">Product Name</th>
                  <th className="p-4">Category</th>
                  <th className="p-4 text-center">System Stock</th>
                  <th className="p-4 text-center">Physical Count (Floor)</th>
                  <th className="p-4 text-center">Variance (Diff)</th>
                  <th className="p-4 text-right">Cost Impact ($)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-slate-400">
                      No products found.
                    </td>
                  </tr>
                ) : (
                  filteredProducts.slice(auditFirst, auditFirst + auditRows).map((p) => {
                    const physical = auditCounts[p.id] ?? p.stock;
                    const diff = physical - p.stock;
                    const costImpact = diff * p.purchasePrice;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                        <td className="p-4 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                          <div>{p.sku}</div>
                          <div className="text-[10px] text-slate-400">{p.barcode}</div>
                        </td>
                        <td className="p-4 font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                          <img src={p.image} alt="" className="w-8 h-8 rounded-lg object-cover bg-slate-100" />
                          <span>{p.name}</span>
                        </td>
                        <td className="p-4 text-slate-500">{p.categoryName}</td>
                        <td className="p-4 text-center font-bold text-slate-700 dark:text-slate-300">
                          {p.stock} {p.unit}
                        </td>
                        <td className="p-4 text-center">
                          <input
                            type="number"
                            min="0"
                            value={physical}
                            onChange={(e) => handleAuditCountChange(p.id, Number(e.target.value))}
                            className="w-20 px-2.5 py-1.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-center font-bold text-slate-800 dark:text-slate-100 text-xs focus:ring-2 focus:ring-[#3271a8]"
                          />
                        </td>
                        <td className="p-4 text-center">
                          {diff === 0 ? (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-500">
                              Matched
                            </span>
                          ) : diff > 0 ? (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                              +{diff} surplus
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-500/15 text-red-600 dark:text-red-400">
                              {diff} shortage
                            </span>
                          )}
                        </td>
                        <td
                          className={`p-4 text-right font-mono font-bold text-xs ${
                            costImpact === 0
                              ? 'text-slate-400'
                              : costImpact > 0
                              ? 'text-emerald-600'
                              : 'text-red-500'
                          }`}
                        >
                          {costImpact === 0 ? '$0.00' : `${costImpact > 0 ? '+' : ''}$${costImpact.toFixed(2)}`}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <Paginator
            totalRecords={filteredProducts.length}
            rows={auditRows}
            first={auditFirst}
            onPageChange={(e) => {
              setAuditFirst(e.first);
              setAuditRows(e.rows);
            }}
            rowsPerPageOptions={[5, 8, 15, 25, 50]}
          />
        </div>
      )}

      {/* TAB 3: LOW STOCK REORDER QUEUE */}
      {activeTab === 'reorder' && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Low Stock & Safety Threshold Queue</span>
            </h3>
            <span className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
              {lowStockProducts.length} Products At/Below Safety Level
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                  <th className="p-4">Product</th>
                  <th className="p-4">Category</th>
                  <th className="p-4 text-center">Current Stock</th>
                  <th className="p-4 text-center">Min Safety Level</th>
                  <th className="p-4 text-center">Suggested Restock Qty</th>
                  <th className="p-4 text-right">Est. Cost ($)</th>
                  <th className="p-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
                {lowStockProducts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-emerald-600 font-bold">
                      🎉 Excellent! All inventory levels are well above safety threshold levels.
                    </td>
                  </tr>
                ) : (
                  lowStockProducts.slice(reorderFirst, reorderFirst + reorderRows).map((p) => {
                    const suggestedQty = Math.max(10, p.minStock * 2 - p.stock);
                    const totalCost = suggestedQty * p.purchasePrice;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                        <td className="p-4 font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                          <img src={p.image} alt="" className="w-8 h-8 rounded-lg object-cover bg-slate-100" />
                          <div>
                            <div>{p.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{p.sku}</div>
                          </div>
                        </td>
                        <td className="p-4 text-slate-500">{p.categoryName}</td>
                        <td className="p-4 text-center font-bold text-red-500">
                          {p.stock} {p.unit}
                        </td>
                        <td className="p-4 text-center font-bold text-slate-600 dark:text-slate-400">
                          {p.minStock} {p.unit}
                        </td>
                        <td className="p-4 text-center font-extrabold text-[#3271a8]">+{suggestedQty} pcs</td>
                        <td className="p-4 text-right font-mono font-bold text-slate-800 dark:text-slate-100">
                          ${totalCost.toFixed(2)}
                        </td>
                        <td className="p-4 text-center">
                          <button
                            onClick={() => handleQuickRestock(p, suggestedQty)}
                            className="px-3.5 py-1.5 rounded-xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-[11px] shadow-sm flex items-center justify-center gap-1.5 mx-auto cursor-pointer transition-all"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Quick Restock (+{suggestedQty})</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <Paginator
            totalRecords={lowStockProducts.length}
            rows={reorderRows}
            first={reorderFirst}
            onPageChange={(e) => {
              setReorderFirst(e.first);
              setReorderRows(e.rows);
            }}
            rowsPerPageOptions={[5, 8, 15, 25, 50]}
          />
        </div>
      )}

      {/* NEW STOCK ADJUSTMENT MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <Boxes className="w-5 h-5 text-[#3271a8]" />
              <span>Record Manual Stock Adjustment</span>
            </h2>

            <form onSubmit={handleSubmitAdjustment} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Select Product</label>
                <select
                  value={formData.productId}
                  onChange={(e) => setFormData({ ...formData, productId: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Current: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Adjustment Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-medium"
                  >
                    <option value="Restock">Restock (+)</option>
                    <option value="Damaged">Damaged Write-Off (-)</option>
                    <option value="Correction">Audit Correction (+/-)</option>
                    <option value="Transfer">Inter-Branch Transfer (-)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Quantity Change</label>
                  <input
                    type="number"
                    required
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Reason / Audit Note</label>
                <input
                  type="text"
                  required
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="e.g. Broken in shipment, Supplier delivery..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25 transition-all cursor-pointer"
              >
                Apply Stock Adjustment Log
              </button>
            </form>
          </div>
        </div>
      )}

      {/* VIEW ADJUSTMENT DETAILS MODAL */}
      {viewingAdjustment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setViewingAdjustment(null)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5 border-b border-slate-100 dark:border-slate-700 pb-3">
              <div className="p-3 rounded-2xl bg-sky-500/10 text-sky-600 dark:text-sky-400">
                <Info className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-800 dark:text-slate-100">Stock Adjustment Details</h2>
                <p className="text-xs text-slate-400 font-mono">Record ID: {viewingAdjustment.id}</p>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Product</p>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-100">{viewingAdjustment.productName}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Adjustment Type</p>
                  <span
                    className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      viewingAdjustment.type === 'Restock'
                        ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                        : viewingAdjustment.type === 'Damaged'
                        ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                        : viewingAdjustment.type === 'Transfer'
                        ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                        : 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                    }`}
                  >
                    {viewingAdjustment.type}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Quantity Adjustment</p>
                  <p
                    className={`text-lg font-black mt-0.5 ${
                      viewingAdjustment.quantity >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'
                    }`}
                  >
                    {viewingAdjustment.quantity > 0 ? `+${viewingAdjustment.quantity}` : viewingAdjustment.quantity} pcs
                  </p>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Adjusted By Staff</p>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-1 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>{viewingAdjustment.adjustedBy || 'Admin'}</span>
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60">
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Reason / Audit Note</p>
                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium mt-1 leading-relaxed">
                  {viewingAdjustment.reason}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-slate-500">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Logged Date & Time:</span>
                </div>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-100">{viewingAdjustment.date}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 mt-6">
              <button
                onClick={() => {
                  const target = viewingAdjustment;
                  setViewingAdjustment(null);
                  openEditModal(target);
                }}
                className="flex-1 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md shadow-amber-600/20"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit Adjustment</span>
              </button>

              <button
                onClick={() => setViewingAdjustment(null)}
                className="flex-1 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold text-xs cursor-pointer transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT ADJUSTMENT MODAL */}
      {editingAdjustment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setEditingAdjustment(null)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-2">
              <Edit className="w-5 h-5 text-amber-500" />
              <span>Edit Stock Adjustment Log</span>
            </h2>
            <p className="text-xs text-slate-400 mb-4 font-mono">ID: {editingAdjustment.id}</p>

            <form onSubmit={handleUpdateAdjustment} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Select Product</label>
                <select
                  value={editFormData.productId}
                  onChange={(e) => setEditFormData({ ...editFormData, productId: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Current: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Adjustment Type</label>
                  <select
                    value={editFormData.type}
                    onChange={(e) => setEditFormData({ ...editFormData, type: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-medium"
                  >
                    <option value="Restock">Restock (+)</option>
                    <option value="Damaged">Damaged Write-Off (-)</option>
                    <option value="Correction">Audit Correction (+/-)</option>
                    <option value="Transfer">Inter-Branch Transfer (-)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Quantity Change</label>
                  <input
                    type="number"
                    required
                    value={editFormData.quantity}
                    onChange={(e) => setEditFormData({ ...editFormData, quantity: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Reason / Audit Note</label>
                <input
                  type="text"
                  required
                  value={editFormData.reason}
                  onChange={(e) => setEditFormData({ ...editFormData, reason: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Adjusted By (Staff Name)</label>
                <input
                  type="text"
                  required
                  value={editFormData.adjustedBy}
                  onChange={(e) => setEditFormData({ ...editFormData, adjustedBy: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingAdjustment(null)}
                  className="flex-1 py-3 rounded-2xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold text-xs cursor-pointer transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-lg shadow-amber-600/25 transition-all cursor-pointer"
                >
                  Update Adjustment Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

