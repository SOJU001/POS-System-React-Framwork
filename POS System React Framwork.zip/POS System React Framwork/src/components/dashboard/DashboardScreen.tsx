import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { api } from '../../services/api';
import {
  DollarSign,
  ShoppingBag,
  TrendingUp,
  Receipt,
  Users,
  AlertCircle,
  PackageCheck,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  BarChart2,
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line as LineChart, Bar as BarChart, Doughnut as DoughnutChart } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

export const DashboardScreen: React.FC = () => {
  const { stats, sales, products, expenses, setActiveTab, playSound } = usePOS();
  const [aiInsight, setAiInsight] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  const fetchAIInsights = async () => {
    setAiLoading(true);
    try {
      const res = await api.getAIInsights('forecast');
      setAiInsight(res.insight);
    } catch (e) {
      setAiInsight('Analyze sales trends and reorder low-stock items in Electronics & Food & Beverage.');
    } finally {
      setAiLoading(false);
    }
  };

  useEffect(() => {
    fetchAIInsights();
  }, []);

  // Sales trend line chart configuration
  const salesChartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Sales Revenue ($)',
        data: [1200, 1850, 2400, 2100, 3100, 4200, 3800],
        borderColor: '#3271a8',
        backgroundColor: 'rgba(50, 113, 168, 0.1)',
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Expenses ($)',
        data: [300, 450, 200, 600, 350, 800, 400],
        borderColor: '#DC3545',
        backgroundColor: 'rgba(220, 53, 69, 0.1)',
        tension: 0.4,
      },
    ],
  };

  // Top Products Bar chart data
  const topProductsData = {
    labels: (products || []).slice(0, 5).map((p) => p.name?.split(' ')[0] || p.name || 'Item'),
    datasets: [
      {
        label: 'Units Sold',
        data: [142, 98, 85, 62, 45],
        backgroundColor: '#7732a8',
        borderRadius: 8,
      },
    ],
  };

  // Expense distribution Doughnut
  const expenseChartData = {
    labels: ['Facility Rent', 'Utilities', 'Salaries', 'Supplies'],
    datasets: [
      {
        data: [1500, 280, 2400, 650],
        backgroundColor: ['#3271a8', '#7732a8', '#198754', '#FFC107'],
      },
    ],
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header Banner & Gemini AI Copilot */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-[#1e3a8a] to-[#3271a8] p-6 rounded-3xl text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-200 bg-white/10 px-3 py-1 rounded-full border border-white/10">
            Real-Time POS Analytics
          </span>
          <h1 className="text-2xl font-extrabold mt-2">Executive Store Performance</h1>
          <p className="text-xs text-blue-100 max-w-xl mt-1">
            Track daily sales velocity, profit margins, stock turns, and automated Gemini AI inventory insights.
          </p>
        </div>

        <button
          onClick={() => {
            playSound('beep');
            fetchAIInsights();
          }}
          className="relative z-10 px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/20 text-xs font-semibold flex items-center gap-2 backdrop-blur-md transition-all cursor-pointer shrink-0"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>Refresh AI Advisory</span>
        </button>
      </div>

      {/* AI Advisory Box */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-900/10 via-purple-800/10 to-indigo-900/10 dark:from-purple-950/40 dark:to-indigo-950/40 border border-purple-200 dark:border-purple-800/60 flex items-start gap-3">
        <div className="p-2 rounded-xl bg-purple-600 text-white shrink-0 mt-0.5 shadow-md">
          <Sparkles className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <h3 className="text-xs font-bold uppercase text-purple-900 dark:text-purple-300">
            Smart POS Gemini AI Recommendation
          </h3>
          <p className="text-xs text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">
            {aiLoading ? 'Analyzing inventory trends & profit velocity...' : aiInsight}
          </p>
        </div>
      </div>

      {/* Key Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            title: "Today's Revenue",
            value: `$${(stats?.todaySales || 0).toFixed(2)}`,
            change: '+14.5%',
            isPositive: true,
            icon: DollarSign,
            color: 'from-blue-500 to-indigo-600',
          },
          {
            title: "Today's Orders",
            value: stats?.todayOrders || 0,
            change: '+8.2%',
            isPositive: true,
            icon: ShoppingBag,
            color: 'from-emerald-500 to-teal-600',
          },
          {
            title: 'Total Gross Profit',
            value: `$${(stats?.profit || 0).toFixed(2)}`,
            change: '+22.1%',
            isPositive: true,
            icon: TrendingUp,
            color: 'from-purple-500 to-violet-600',
          },
          {
            title: 'Low Stock Warnings',
            value: `${stats?.lowStockCount || 0} Items`,
            change: 'Action Needed',
            isPositive: false,
            icon: AlertCircle,
            color: 'from-amber-500 to-orange-600',
            onClick: () => setActiveTab('inventory'),
          },
        ].map((card, idx) => {
          const Icon = card.icon;
          return (
            <div
              key={idx}
              onClick={card.onClick}
              className={`p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm hover:shadow-xl transition-all cursor-pointer ${
                card.onClick ? 'hover:border-amber-500' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  {card.title}
                </span>
                <div className={`p-2.5 rounded-2xl bg-gradient-to-tr ${card.color} text-white shadow-md`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>

              <h2 className="text-2xl font-extrabold text-slate-800 dark:text-slate-100 mb-1">
                {card.value}
              </h2>

              <div className="flex items-center gap-1 text-xs font-bold">
                {card.isPositive ? (
                  <span className="text-emerald-600 flex items-center">
                    <ArrowUpRight className="w-3.5 h-3.5" /> {card.change}
                  </span>
                ) : (
                  <span className="text-amber-600 flex items-center">
                    <ArrowDownRight className="w-3.5 h-3.5" /> {card.change}
                  </span>
                )}
                <span className="text-slate-400 font-normal">vs last week</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Sales Trend Line Chart */}
        <div className="lg:col-span-2 p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100">Revenue & Expense Velocity</h3>
              <p className="text-xs text-slate-400">Weekly sales trajectory comparison</p>
            </div>
          </div>
          <div className="h-64">
            <LineChart
              data={salesChartData}
              options={{ responsive: true, maintainAspectRatio: false }}
            />
          </div>
        </div>

        {/* Expense Category Distribution */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Expense Distribution</h3>
            <p className="text-xs text-slate-400">Operating overhead breakdown</p>
          </div>
          <div className="h-48 my-2">
            <DoughnutChart
              data={expenseChartData}
              options={{ responsive: true, maintainAspectRatio: false }}
            />
          </div>
        </div>
      </div>

      {/* Recent Orders & Top Products Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions */}
        <div className="lg:col-span-2 p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Recent Completed Orders</h3>
            <button
              onClick={() => setActiveTab('sales')}
              className="text-xs font-semibold text-[#3271a8] hover:underline"
            >
              View All Sales
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400">
                  <th className="py-2.5">Invoice #</th>
                  <th className="py-2.5">Customer</th>
                  <th className="py-2.5">Payment</th>
                  <th className="py-2.5 text-right">Total</th>
                  <th className="py-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
                {sales.slice(0, 5).map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                    <td className="py-3 font-semibold text-[#3271a8]">{s.invoiceNo}</td>
                    <td className="py-3 font-medium text-slate-800 dark:text-slate-200">{s.customerName}</td>
                    <td className="py-3 text-slate-500">{s.paymentMethod}</td>
                    <td className="py-3 text-right font-bold text-slate-900 dark:text-slate-100">
                      ${s.total.toFixed(2)}
                    </td>
                    <td className="py-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                        {s.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Selling Bar Chart */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">Top Selling Items</h3>
          <p className="text-xs text-slate-400 mb-3">Volume units sold this month</p>
          <div className="h-56">
            <BarChart
              data={topProductsData}
              options={{ responsive: true, maintainAspectRatio: false }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
