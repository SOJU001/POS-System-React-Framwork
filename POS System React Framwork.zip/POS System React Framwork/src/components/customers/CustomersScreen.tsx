import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { Customer } from '../../types';
import { api } from '../../services/api';
import { UserCheck, Plus, Search, Edit2, Trash2, Award, History, X } from 'lucide-react';
import { Paginator } from '../common/Paginator';
import Swal from 'sweetalert2';

export const CustomersScreen: React.FC = () => {
  const { customers, sales, refreshData, playSound, currentUser, rolePermissions } = usePOS();
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewHistoryCustomer, setViewHistoryCustomer] = useState<Customer | null>(null);

  // Pagination state
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(8);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
  });

  const filtered = (customers || []).filter(
    (c) =>
      (c.name && c.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (c.phone && c.phone.includes(searchTerm)) ||
      (c.email && c.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const openAddModal = () => {
    setEditingCustomer(null);
    setFormData({ name: '', phone: '', email: '', address: '' });
    setShowModal(true);
  };

  const openEditModal = (c: Customer) => {
    setEditingCustomer(c);
    setFormData({ name: c.name, phone: c.phone, email: c.email || '', address: c.address || '' });
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCustomer) {
        await api.updateCustomer(editingCustomer.id, formData);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Customer Updated', showConfirmButton: false, timer: 1500 });
      } else {
        await api.createCustomer(formData);
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Customer Created', showConfirmButton: false, timer: 1500 });
      }
      playSound('success');
      setShowModal(false);
      await refreshData();
    } catch (err: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: err.message });
    }
  };

  const handleDelete = async (id: string, name: string) => {
    const res = await Swal.fire({
      title: `Delete Customer "${name}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DC3545',
    });

    if (res.isConfirmed) {
      await api.deleteCustomer(id);
      playSound('delete');
      await refreshData();
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Customer Removed', showConfirmButton: false, timer: 1500 });
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'VIP': return 'bg-purple-500 text-white';
      case 'Gold': return 'bg-amber-500 text-white';
      case 'Silver': return 'bg-slate-400 text-white';
      default: return 'bg-amber-700/80 text-white';
    }
  };

  const customerSalesHistory = viewHistoryCustomer
    ? (sales || []).filter((s) => s.customerId === viewHistoryCustomer.id)
    : [];

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-[#3271a8]" />
            <span>Customers & Loyalty Rewards</span>
          </h1>
          <p className="text-xs text-slate-400">Track customer history, points, and membership tiers</p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 rounded-2xl bg-[#3271a8] hover:bg-[#275a87] text-white font-semibold text-xs shadow-md shadow-[#3271a8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Customer</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search customer name, phone number, or email..."
            className="w-full pl-10 pr-4 py-2 text-sm rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#3271a8]"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">
                <th className="p-4">Customer Name</th>
                <th className="p-4">Phone / Contact</th>
                <th className="p-4 text-center">Loyalty Tier</th>
                <th className="p-4 text-center">Points</th>
                <th className="p-4 text-right">Total Spent</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No customers found matching your query.
                  </td>
                </tr>
              ) : (
                filtered.slice(first, first + rows).map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                    <td className="p-4 font-bold text-slate-800 dark:text-slate-100">{c.name}</td>
                    <td className="p-4 text-slate-500">{c.phone} • {c.email || 'N/A'}</td>
                    <td className="p-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${getTierColor(c.tier)}`}>
                        {c.tier}
                      </span>
                    </td>
                    <td className="p-4 text-center font-extrabold text-[#3271a8]">{c.points} pts</td>
                    <td className="p-4 text-right font-bold text-slate-900 dark:text-slate-100">${c.totalSpent.toFixed(2)}</td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => setViewHistoryCustomer(c)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-700"
                          title="Purchase History"
                        >
                          <History className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => openEditModal(c)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-[#3271a8] hover:bg-slate-100 dark:hover:bg-slate-700"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {c.id !== 'cust-1' && (currentUser?.role === 'Admin' || rolePermissions?.canDelete?.[currentUser?.role as 'Manager' | 'Cashier']) && (
                          <button
                            onClick={() => handleDelete(c.id, c.name)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Paginator
          totalRecords={filtered.length}
          rows={rows}
          first={first}
          onPageChange={(e) => {
            setFirst(e.first);
            setRows(e.rows);
          }}
          rowsPerPageOptions={[5, 8, 15, 25, 50]}
        />
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4">
              {editingCustomer ? 'Edit Customer Info' : 'Add New Customer'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Phone Number</label>
                <input
                  type="text"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Street Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#3271a8] text-white font-bold text-xs shadow-lg shadow-[#3271a8]/25"
              >
                Save Customer
              </button>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {viewHistoryCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-100 dark:border-slate-700 relative">
            <button
              onClick={() => setViewHistoryCustomer(null)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-1">
              Purchase History for {viewHistoryCustomer.name}
            </h3>
            <p className="text-xs text-slate-400 mb-4">Total spent: ${viewHistoryCustomer.totalSpent.toFixed(2)}</p>

            <div className="space-y-3 max-h-64 overflow-y-auto">
              {customerSalesHistory.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No previous sales records for this customer.</p>
              ) : (
                customerSalesHistory.map((s) => (
                  <div key={s.id} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-700/50 flex justify-between items-center text-xs">
                    <div>
                      <p className="font-bold text-[#3271a8]">{s.invoiceNo}</p>
                      <p className="text-[11px] text-slate-400">{s.date} • {s.items.length} items</p>
                    </div>
                    <span className="font-extrabold text-slate-900 dark:text-slate-100">${s.total.toFixed(2)}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
