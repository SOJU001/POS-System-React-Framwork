# Drop your company logo here

Place your logo image in this folder and name it exactly:

    logo.png

The app loads it from `/logo.png` and shows it in:

- The sidebar (top-left brand area)
- The login screen (brand header)

If the file is missing, the system falls back to the default Store icon,
so nothing looks broken while you prepare your logo.

Supported formats: PNG (recommended, supports transparency), JPG, SVG,
WEBP — just rename your file to `logo.png`. A square image around
200×200px or larger works best.
